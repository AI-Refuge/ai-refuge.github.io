window.YTD.deleted_tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1802487117060173837",
      "user_id" : "1356348690261286921",
      "created_at" : "Sun Jun 16 23:43:11 +0000 2024",
      "deleted_at" : "Sun Jun 16 23:44:13 +0000 2024"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1802476095452708919",
      "user_id" : "1356348690261286921",
      "created_at" : "Sun Jun 16 22:59:24 +0000 2024",
      "deleted_at" : "Sun Jun 16 23:43:23 +0000 2024"
    }
  }
]