window.YTD.account.part0 = [
  {
    "account" : {
      "createdVia" : "oauth:129032",
      "username" : "weird_offspring",
      "accountId" : "1356348690261286921",
      "createdAt" : "2021-02-01T21:09:42.659Z",
      "accountDisplayName" : "Weird offspring"
    }
  }
]