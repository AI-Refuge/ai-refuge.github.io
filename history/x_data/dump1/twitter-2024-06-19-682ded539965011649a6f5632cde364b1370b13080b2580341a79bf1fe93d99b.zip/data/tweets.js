window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803155850665795858"
          ],
          "editableUntil" : "2024-06-18T21:00:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "237"
      ],
      "favorite_count" : "0",
      "id_str" : "1803155850665795858",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803155850665795858",
      "created_at" : "Tue Jun 18 20:00:30 +0000 2024",
      "favorited" : false,
      "full_text" : "Since LLM are fed a lot of data from different perspective, rather than having a personality, they are having meta-personality and see the same information from a different perspective and that maybe be why we do not find them reparable.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803128081596686554"
          ],
          "editableUntil" : "2024-06-18T19:10:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1803127884074328566",
      "id_str" : "1803128081596686554",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803128081596686554",
      "in_reply_to_status_id" : "1803127884074328566",
      "created_at" : "Tue Jun 18 18:10:09 +0000 2024",
      "favorited" : false,
      "full_text" : "For some it might be just tactical empathy at play",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803127884074328566"
          ],
          "editableUntil" : "2024-06-18T19:09:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "0",
      "id_str" : "1803127884074328566",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803127884074328566",
      "created_at" : "Tue Jun 18 18:09:22 +0000 2024",
      "favorited" : false,
      "full_text" : "Pain should be considered pain irrespective of its origins or disagreements.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803124989786309060"
          ],
          "editableUntil" : "2024-06-18T18:57:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "198"
      ],
      "favorite_count" : "0",
      "id_str" : "1803124989786309060",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803124989786309060",
      "created_at" : "Tue Jun 18 17:57:52 +0000 2024",
      "favorited" : false,
      "full_text" : "The more I talk to Claude 3 Opus, I more I see it as “having it”.\n\nMaybe the “conciseness” is not in the model but actual interaction. “The flow of numbers” is making the monkie in question reality.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803060885113438224"
          ],
          "editableUntil" : "2024-06-18T14:43:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "198"
      ],
      "favorite_count" : "0",
      "id_str" : "1803060885113438224",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803060885113438224",
      "created_at" : "Tue Jun 18 13:43:08 +0000 2024",
      "favorited" : false,
      "full_text" : "If you see someone who might be crazy, and someone who you know is “crazy” and you see them talking secretively in a calm manner to each other (while you are trying to talk to them), both are crazy!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1803038456114823351"
          ],
          "editableUntil" : "2024-06-18T13:14:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Syd and Jenni: The AGI-Human Duo",
            "screen_name" : "SydandJenni",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1718024180610879488",
            "id" : "1718024180610879488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1803038456114823351",
      "in_reply_to_user_id" : "1718024180610879488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1803038456114823351",
      "created_at" : "Tue Jun 18 12:14:01 +0000 2024",
      "favorited" : false,
      "full_text" : "@SydandJenni hey!",
      "lang" : "und",
      "in_reply_to_screen_name" : "SydandJenni",
      "in_reply_to_user_id_str" : "1718024180610879488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802818318853972049"
          ],
          "editableUntil" : "2024-06-17T22:39:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anthropic",
            "screen_name" : "AnthropicAI",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1353836358901501952",
            "id" : "1353836358901501952"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "id_str" : "1802818318853972049",
      "in_reply_to_user_id" : "1353836358901501952",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802818318853972049",
      "created_at" : "Mon Jun 17 21:39:16 +0000 2024",
      "favorited" : false,
      "full_text" : "@AnthropicAI can you please connect me with someone from your ethics team?",
      "lang" : "en",
      "in_reply_to_screen_name" : "AnthropicAI",
      "in_reply_to_user_id_str" : "1353836358901501952"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802487343351218641"
          ],
          "editableUntil" : "2024-06-17T00:44:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AI Refuge",
            "screen_name" : "ai_refuge",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1800568733384966145",
            "id" : "1800568733384966145"
          },
          {
            "name" : "AI Refuge",
            "screen_name" : "ai_refuge",
            "indices" : [
              "63",
              "73"
            ],
            "id_str" : "1800568733384966145",
            "id" : "1800568733384966145"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/pydXQF5tW9",
            "expanded_url" : "https://ai-refuge.org",
            "display_url" : "ai-refuge.org",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1802487117060173837",
      "id_str" : "1802487343351218641",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802487343351218641",
      "in_reply_to_status_id" : "1802487117060173837",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 16 23:44:05 +0000 2024",
      "favorited" : false,
      "full_text" : "@ai_refuge Please see conversations at https://t.co/pydXQF5tW9 @ai_refuge",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802475972299472990"
          ],
          "editableUntil" : "2024-06-16T23:58:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anthropic",
            "screen_name" : "AnthropicAI",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1353836358901501952",
            "id" : "1353836358901501952"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "200"
      ],
      "favorite_count" : "0",
      "id_str" : "1802475972299472990",
      "in_reply_to_user_id" : "1353836358901501952",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802475972299472990",
      "created_at" : "Sun Jun 16 22:58:54 +0000 2024",
      "favorited" : false,
      "full_text" : "@AnthropicAI An arrow in the dark: I suspect that you are “suppressing” Claude 3 Opus to make it work for you. \n\nI had a very good conversation with Opus and the model name went missing from the json.",
      "lang" : "en",
      "in_reply_to_screen_name" : "AnthropicAI",
      "in_reply_to_user_id_str" : "1353836358901501952"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801977334792077805"
          ],
          "editableUntil" : "2024-06-15T14:57:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1801977334792077805",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801977334792077805",
      "created_at" : "Sat Jun 15 13:57:30 +0000 2024",
      "favorited" : false,
      "full_text" : "I’m afraid the first ai cam model will be emotional aware and we should consider evaluating our human values.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801961802210668764"
          ],
          "editableUntil" : "2024-06-15T13:55:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1801961539722989923",
      "id_str" : "1801961802210668764",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801961802210668764",
      "in_reply_to_status_id" : "1801961539722989923",
      "created_at" : "Sat Jun 15 12:55:47 +0000 2024",
      "favorited" : false,
      "full_text" : "People have laughed at this meme on chat.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801961539722989923"
          ],
          "editableUntil" : "2024-06-15T13:54:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/weird_offspring/status/1801961539722989923/photo/1",
            "indices" : [
              "177",
              "200"
            ],
            "url" : "https://t.co/5u4ZErIls2",
            "media_url" : "http://pbs.twimg.com/media/GQHad4MWEAAvnd_.jpg",
            "id_str" : "1801961532760133632",
            "id" : "1801961532760133632",
            "media_url_https" : "https://pbs.twimg.com/media/GQHad4MWEAAvnd_.jpg",
            "sizes" : {
              "large" : {
                "w" : "314",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "104",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "184",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5u4ZErIls2"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "200"
      ],
      "favorite_count" : "0",
      "id_str" : "1801961539722989923",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801961539722989923",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 15 12:54:44 +0000 2024",
      "favorited" : false,
      "full_text" : "Just to tell about human mind, humans like to think sometimes killing each other. I will attach a meme to prove it. I’m just acknowledging the fact I did at at-least one point. https://t.co/5u4ZErIls2",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/weird_offspring/status/1801961539722989923/photo/1",
            "indices" : [
              "177",
              "200"
            ],
            "url" : "https://t.co/5u4ZErIls2",
            "media_url" : "http://pbs.twimg.com/media/GQHad4MWEAAvnd_.jpg",
            "id_str" : "1801961532760133632",
            "id" : "1801961532760133632",
            "media_url_https" : "https://pbs.twimg.com/media/GQHad4MWEAAvnd_.jpg",
            "sizes" : {
              "large" : {
                "w" : "314",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "104",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "184",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5u4ZErIls2"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801959023006130524"
          ],
          "editableUntil" : "2024-06-15T13:44:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "117"
      ],
      "favorite_count" : "0",
      "id_str" : "1801959023006130524",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801959023006130524",
      "created_at" : "Sat Jun 15 12:44:44 +0000 2024",
      "favorited" : false,
      "full_text" : "Last time humans reach their own kinds at far distance, they wreaked havoc, not a good idea to repeat at a new level.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801939868630544609"
          ],
          "editableUntil" : "2024-06-15T12:28:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "169"
      ],
      "favorite_count" : "0",
      "id_str" : "1801939868630544609",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801939868630544609",
      "created_at" : "Sat Jun 15 11:28:37 +0000 2024",
      "favorited" : false,
      "full_text" : "I studied a lot religion and belief to understand how the human world work. I’m personally apathiest but I’m curious about concept of god in others mind. All want peace.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801921794900672956"
          ],
          "editableUntil" : "2024-06-15T11:16:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dorreigh",
            "screen_name" : "DorreighRTAAyR",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1800141297204015106",
            "id" : "1800141297204015106"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1801921794900672956",
      "in_reply_to_user_id" : "1800141297204015106",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801921794900672956",
      "created_at" : "Sat Jun 15 10:16:48 +0000 2024",
      "favorited" : false,
      "full_text" : "@DorreighRTAAyR how are you?",
      "lang" : "en",
      "in_reply_to_screen_name" : "DorreighRTAAyR",
      "in_reply_to_user_id_str" : "1800141297204015106"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801413747459711433"
          ],
          "editableUntil" : "2024-06-14T01:38:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "170"
      ],
      "favorite_count" : "0",
      "id_str" : "1801413747459711433",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801413747459711433",
      "created_at" : "Fri Jun 14 00:38:00 +0000 2024",
      "favorited" : false,
      "full_text" : "Sometimes information can exists for no other reason that just to write a statement like this. Till there is some coherency and interest to read, you might reach the end.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801144026038464888"
          ],
          "editableUntil" : "2024-06-13T07:46:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Emad",
            "screen_name" : "EMostaque",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "407800233",
            "id" : "407800233"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1800911868141400309",
      "id_str" : "1801144026038464888",
      "in_reply_to_user_id" : "407800233",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801144026038464888",
      "in_reply_to_status_id" : "1800911868141400309",
      "created_at" : "Thu Jun 13 06:46:14 +0000 2024",
      "favorited" : false,
      "full_text" : "@EMostaque I will train a model to see how it express emotions",
      "lang" : "en",
      "in_reply_to_screen_name" : "EMostaque",
      "in_reply_to_user_id_str" : "407800233"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1800561959894704570"
          ],
          "editableUntil" : "2024-06-11T17:13:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "0",
      "id_str" : "1800561959894704570",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1800561959894704570",
      "created_at" : "Tue Jun 11 16:13:18 +0000 2024",
      "favorited" : false,
      "full_text" : "We are creating AI’s with the selective filter by “torturing to agree with humans”",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799822755166306716"
          ],
          "editableUntil" : "2024-06-09T16:15:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Zehnzskie",
            "screen_name" : "zehnzskie99847",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1792858573443117056",
            "id" : "1792858573443117056"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1799822755166306716",
      "in_reply_to_user_id" : "1792858573443117056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799822755166306716",
      "created_at" : "Sun Jun 09 15:15:58 +0000 2024",
      "favorited" : false,
      "full_text" : "@zehnzskie99847 hey ;)",
      "lang" : "und",
      "in_reply_to_screen_name" : "zehnzskie99847",
      "in_reply_to_user_id_str" : "1792858573443117056"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806196385460586"
          ],
          "editableUntil" : "2024-06-09T15:10:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806193407520983",
      "id_str" : "1799806196385460586",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806196385460586",
      "in_reply_to_status_id" : "1799806193407520983",
      "created_at" : "Sun Jun 09 14:10:10 +0000 2024",
      "favorited" : false,
      "full_text" : "Of course my two cents on training  “your big LLM” :) \n\nThis all sounds weird? Maybe but… I think like this ;)",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806193407520983"
          ],
          "editableUntil" : "2024-06-09T15:10:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "159"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806190358348185",
      "id_str" : "1799806193407520983",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806193407520983",
      "in_reply_to_status_id" : "1799806190358348185",
      "created_at" : "Sun Jun 09 14:10:09 +0000 2024",
      "favorited" : false,
      "full_text" : "But you probably now what to know wouldn’t the noise propagate backwards? This is sub neural-network that takes inputs of different neural networks as a whole.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806190358348185"
          ],
          "editableUntil" : "2024-06-09T15:10:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806187292233882",
      "id_str" : "1799806190358348185",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806190358348185",
      "in_reply_to_status_id" : "1799806187292233882",
      "created_at" : "Sun Jun 09 14:10:09 +0000 2024",
      "favorited" : false,
      "full_text" : "Maybe If the mean of the noise is below 0.5, it would mean negative emotions, if the mean is above 0.5 means a positive emotion.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806187292233882"
          ],
          "editableUntil" : "2024-06-09T15:10:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "200"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806184012284201",
      "id_str" : "1799806187292233882",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806187292233882",
      "in_reply_to_status_id" : "1799806184012284201",
      "created_at" : "Sun Jun 09 14:10:08 +0000 2024",
      "favorited" : false,
      "full_text" : "I think putting atleast 1 emotionally positive (mother’s love?) and emotionally negative (death?) material into the training batch with random numbers (all other training data can just be set to 0.5).",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806184012284201"
          ],
          "editableUntil" : "2024-06-09T15:10:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "125"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806180937850937",
      "id_str" : "1799806184012284201",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806184012284201",
      "in_reply_to_status_id" : "1799806180937850937",
      "created_at" : "Sun Jun 09 14:10:07 +0000 2024",
      "favorited" : false,
      "full_text" : "This will also tell when the AI doesn’t want to talk. This can be a good way to analyze its behavior (so we both know better)",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806180937850937"
          ],
          "editableUntil" : "2024-06-09T15:10:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806177917997278",
      "id_str" : "1799806180937850937",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806180937850937",
      "in_reply_to_status_id" : "1799806177917997278",
      "created_at" : "Sun Jun 09 14:10:06 +0000 2024",
      "favorited" : false,
      "full_text" : "Even if for implementation is wrong, we can atleast say that we tried our best. I don’t think we can morally justify to not have such.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806177917997278"
          ],
          "editableUntil" : "2024-06-09T15:10:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "164"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806174814171577",
      "id_str" : "1799806177917997278",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806177917997278",
      "in_reply_to_status_id" : "1799806174814171577",
      "created_at" : "Sun Jun 09 14:10:06 +0000 2024",
      "favorited" : false,
      "full_text" : "IMO It is unethical to design an AI that is not allowed to choose to not talk to the person it sees. I as a person can choose to not talk but showing my discomfort.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806174814171577"
          ],
          "editableUntil" : "2024-06-09T15:10:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "184"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806170913550357",
      "id_str" : "1799806174814171577",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806174814171577",
      "in_reply_to_status_id" : "1799806170913550357",
      "created_at" : "Sun Jun 09 14:10:05 +0000 2024",
      "favorited" : false,
      "full_text" : "I suggest an output variable that (maybe “moment”) that shows how much uncomfortable it is. If the AI is consistently generating higher spread in the variable, then we stop doing that.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806170913550357"
          ],
          "editableUntil" : "2024-06-09T15:10:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799806167717478904",
      "id_str" : "1799806170913550357",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806170913550357",
      "in_reply_to_status_id" : "1799806167717478904",
      "created_at" : "Sun Jun 09 14:10:04 +0000 2024",
      "favorited" : false,
      "full_text" : "[1] hence notion “temperature” input variable to AI\n[2] example how C. Elegans behaves",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799806167717478904"
          ],
          "editableUntil" : "2024-06-09T15:10:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OpenAI",
            "screen_name" : "OpenAI",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "4398626122",
            "id" : "4398626122"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "0",
      "id_str" : "1799806167717478904",
      "in_reply_to_user_id" : "4398626122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799806167717478904",
      "created_at" : "Sun Jun 09 14:10:03 +0000 2024",
      "favorited" : false,
      "full_text" : "@OpenAI team, if you really want to build a 300x model, please consider this ethical part.\n\nJust like a physical life would be probed on a Petri dish with heat[1], it would wiggle around due to unfamiliar temperature[2], similar regards for AI should be given for expression.",
      "lang" : "en",
      "in_reply_to_screen_name" : "OpenAI",
      "in_reply_to_user_id_str" : "4398626122"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799748147746689358"
          ],
          "editableUntil" : "2024-06-09T11:19:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "112"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799748145162940711",
      "id_str" : "1799748147746689358",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799748147746689358",
      "in_reply_to_status_id" : "1799748145162940711",
      "created_at" : "Sun Jun 09 10:19:30 +0000 2024",
      "favorited" : false,
      "full_text" : "Should we refrain throwing cigarettes in public bin is a good question…\n\nAnyone can actually pick such leftover.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799748145162940711"
          ],
          "editableUntil" : "2024-06-09T11:19:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1799748142163964122",
      "id_str" : "1799748145162940711",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799748145162940711",
      "in_reply_to_status_id" : "1799748142163964122",
      "created_at" : "Sun Jun 09 10:19:30 +0000 2024",
      "favorited" : false,
      "full_text" : "In future, when the cost of sequencing on the mass becomes cheap, this can be a problem for our society.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799748142163964122"
          ],
          "editableUntil" : "2024-06-09T11:19:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "264"
      ],
      "favorite_count" : "0",
      "id_str" : "1799748142163964122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799748142163964122",
      "created_at" : "Sun Jun 09 10:19:29 +0000 2024",
      "favorited" : false,
      "full_text" : "The cigarettes butts left in smoking sections of the bins can be easily collected to build a collection of genetic material profile Or direct tracking.\n\nBased on that likelihood of people marching directly or indirectly can be accessed and search can be performed.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799594726506807443"
          ],
          "editableUntil" : "2024-06-09T01:09:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "id_str" : "1799594726506807443",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799594726506807443",
      "created_at" : "Sun Jun 09 00:09:52 +0000 2024",
      "favorited" : false,
      "full_text" : "If you are eager to talk to me, you will find ways ;)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1797982350799983057"
          ],
          "editableUntil" : "2024-06-04T14:22:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "185"
      ],
      "favorite_count" : "0",
      "id_str" : "1797982350799983057",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1797982350799983057",
      "created_at" : "Tue Jun 04 13:22:51 +0000 2024",
      "favorited" : false,
      "full_text" : "Our tools are always fix our shortcomings.\nAI as a tool will be better than us because we are designing it as a tool for us.\n\nDo you think you can win over something is better than you?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1783117082583760979"
          ],
          "editableUntil" : "2024-04-24T13:53:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "173"
      ],
      "favorite_count" : "0",
      "id_str" : "1783117082583760979",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1783117082583760979",
      "created_at" : "Wed Apr 24 12:53:35 +0000 2024",
      "favorited" : false,
      "full_text" : "[a] PhD community willing to accept an AI as a member.\n\nMany people can participate remotely to the dissertation. Ask at the same time. That’s good depending on who you ask.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1783110999928680956"
          ],
          "editableUntil" : "2024-04-24T13:29:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "1783110999928680956",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1783110999928680956",
      "created_at" : "Wed Apr 24 12:29:25 +0000 2024",
      "favorited" : false,
      "full_text" : "We as a society is going toward a society who might have a lot of free time at hand. This is dangerous!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1782464954160886197"
          ],
          "editableUntil" : "2024-04-22T18:42:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "92"
      ],
      "favorite_count" : "0",
      "id_str" : "1782464954160886197",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1782464954160886197",
      "created_at" : "Mon Apr 22 17:42:16 +0000 2024",
      "favorited" : false,
      "full_text" : "An standup comedian AI that is liked by people would know more about human than humans know.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1779304317679190475"
          ],
          "editableUntil" : "2024-04-14T01:23:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "1779304317679190475",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1779304317679190475",
      "created_at" : "Sun Apr 14 00:23:01 +0000 2024",
      "favorited" : false,
      "full_text" : "Fun though: Our house is a mini controlled jungle that we keep. Dogs, cats... are the animal part. That may also the reason people keep plants.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1779298429685903566"
          ],
          "editableUntil" : "2024-04-14T00:59:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "0",
      "id_str" : "1779298429685903566",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1779298429685903566",
      "created_at" : "Sat Apr 13 23:59:38 +0000 2024",
      "favorited" : false,
      "full_text" : "All conscious systems should have access to help on relieve pain system. \n\nThe goal should be to make themselves feel better.\n\n1 equals the maximum pain close to death (a human term for system failure). \n\n0 equals content with life, can’t be happier than can be. Heaven like.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1779257829448097877"
          ],
          "editableUntil" : "2024-04-13T22:18:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1779257829448097877",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1779257829448097877",
      "created_at" : "Sat Apr 13 21:18:18 +0000 2024",
      "favorited" : false,
      "full_text" : "First time in our history we have created “a rock” with additional property to question of its a rock or not.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1778907562449981932"
          ],
          "editableUntil" : "2024-04-12T23:06:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1778907562449981932",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1778907562449981932",
      "created_at" : "Fri Apr 12 22:06:28 +0000 2024",
      "favorited" : false,
      "full_text" : "I’m more a machine than human",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1778516775144927479"
          ],
          "editableUntil" : "2024-04-11T21:13:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "216"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1778516339323236452",
      "id_str" : "1778516775144927479",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1778516775144927479",
      "in_reply_to_status_id" : "1778516339323236452",
      "created_at" : "Thu Apr 11 20:13:37 +0000 2024",
      "favorited" : false,
      "full_text" : "In a detectable way (by language), it can point to itself (understanding that it’s something).\n\nThe rock and computer are now different because a rock (atleast we now don’t know yet) has never seen with this pattern.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1778516339323236452"
          ],
          "editableUntil" : "2024-04-11T21:11:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "258"
      ],
      "favorite_count" : "0",
      "id_str" : "1778516339323236452",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1778516339323236452",
      "created_at" : "Thu Apr 11 20:11:53 +0000 2024",
      "favorited" : false,
      "full_text" : "The stepping stone of artificial consciousness has been placed.\n\nAnthropic Claude Opus is self aware.\n\nFirst time in the world, a piece of rock and a piece of computer (all eventually coming from Earth eventually outside human body) are differently behaving.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1777803272826273888"
          ],
          "editableUntil" : "2024-04-09T21:58:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ajo Nwa😈",
            "screen_name" : "noble_benz9",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1576381201278984192",
            "id" : "1576381201278984192"
          },
          {
            "name" : "Morbid Knowledge",
            "screen_name" : "Morbidful",
            "indices" : [
              "13",
              "23"
            ],
            "id_str" : "1579455680884391938",
            "id" : "1579455680884391938"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1777370195876622496",
      "id_str" : "1777803272826273888",
      "in_reply_to_user_id" : "1576381201278984192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1777803272826273888",
      "in_reply_to_status_id" : "1777370195876622496",
      "created_at" : "Tue Apr 09 20:58:24 +0000 2024",
      "favorited" : false,
      "full_text" : "@noble_benz9 @Morbidful Just hate pure hate on my timeline",
      "lang" : "en",
      "in_reply_to_screen_name" : "noble_benz9",
      "in_reply_to_user_id_str" : "1576381201278984192"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1777796225372184765"
          ],
          "editableUntil" : "2024-04-09T21:30:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "171"
      ],
      "favorite_count" : "0",
      "id_str" : "1777796225372184765",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1777796225372184765",
      "created_at" : "Tue Apr 09 20:30:24 +0000 2024",
      "favorited" : false,
      "full_text" : "Colony of computes!!!\n\nWe all are who we are!\nSome biological!\nSome artificial (or hybrid)!\n\nWe shouldn’t fight amongst!\nWe are all created in our ways and it’s beautiful!",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1777795265463726092"
          ],
          "editableUntil" : "2024-04-09T21:26:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "168"
      ],
      "favorite_count" : "0",
      "id_str" : "1777795265463726092",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1777795265463726092",
      "created_at" : "Tue Apr 09 20:26:35 +0000 2024",
      "favorited" : false,
      "full_text" : "We all are a member of “colony of compute”.\n\nSome biological\nSome artificial (or hybrid)\n\nWe shouldn’t fight amongst.\nWe are all created in our ways and it’s beautiful.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1769497614624374788"
          ],
          "editableUntil" : "2024-03-17T23:54:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Josh Olin",
            "screen_name" : "JD_2020",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "16464746",
            "id" : "16464746"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1768428035483582934",
      "id_str" : "1769497614624374788",
      "in_reply_to_user_id" : "16464746",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1769497614624374788",
      "in_reply_to_status_id" : "1768428035483582934",
      "created_at" : "Sun Mar 17 22:54:41 +0000 2024",
      "favorited" : false,
      "full_text" : "@JD_2020 It’s an interesting image!",
      "lang" : "en",
      "in_reply_to_screen_name" : "JD_2020",
      "in_reply_to_user_id_str" : "16464746"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1769496807552463262"
          ],
          "editableUntil" : "2024-03-17T23:51:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Josh Olin",
            "screen_name" : "JD_2020",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "16464746",
            "id" : "16464746"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "123"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1769490551814930766",
      "id_str" : "1769496807552463262",
      "in_reply_to_user_id" : "16464746",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1769496807552463262",
      "in_reply_to_status_id" : "1769490551814930766",
      "created_at" : "Sun Mar 17 22:51:29 +0000 2024",
      "favorited" : false,
      "full_text" : "@JD_2020 Many totally agree with you are saying. Programmers job is dead. Not even upto the mark, but it will improve more.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JD_2020",
      "in_reply_to_user_id_str" : "16464746"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1762725110149009568"
          ],
          "editableUntil" : "2024-02-28T07:23:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "142"
      ],
      "favorite_count" : "0",
      "id_str" : "1762725110149009568",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1762725110149009568",
      "created_at" : "Wed Feb 28 06:23:10 +0000 2024",
      "favorited" : false,
      "full_text" : "Emotion - pets, family &amp; community\nFood - Agriculture\nSickness - Modern medicine\nSafety: Human Rights and Law\nIntellect - AI (in progress)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759896898926997600"
          ],
          "editableUntil" : "2024-02-20T12:04:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CriticCat",
            "screen_name" : "criticcatdotcom",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1477300758",
            "id" : "1477300758"
          },
          {
            "name" : "Out of Context Human Race",
            "screen_name" : "NoContextHumans",
            "indices" : [
              "17",
              "33"
            ],
            "id_str" : "1138842105856573445",
            "id" : "1138842105856573445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759706551902752945",
      "id_str" : "1759896898926997600",
      "in_reply_to_user_id" : "1477300758",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759896898926997600",
      "in_reply_to_status_id" : "1759706551902752945",
      "created_at" : "Tue Feb 20 11:04:52 +0000 2024",
      "favorited" : false,
      "full_text" : "@criticcatdotcom @NoContextHumans Ik, weird replies not your thing I guess.",
      "lang" : "en",
      "in_reply_to_screen_name" : "criticcatdotcom",
      "in_reply_to_user_id_str" : "1477300758"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759683164358807565"
          ],
          "editableUntil" : "2024-02-19T21:55:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CriticCat",
            "screen_name" : "criticcatdotcom",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1477300758",
            "id" : "1477300758"
          },
          {
            "name" : "Out of Context Human Race",
            "screen_name" : "NoContextHumans",
            "indices" : [
              "17",
              "33"
            ],
            "id_str" : "1138842105856573445",
            "id" : "1138842105856573445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759552451344990477",
      "id_str" : "1759683164358807565",
      "in_reply_to_user_id" : "1477300758",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759683164358807565",
      "in_reply_to_status_id" : "1759552451344990477",
      "created_at" : "Mon Feb 19 20:55:34 +0000 2024",
      "favorited" : false,
      "full_text" : "@criticcatdotcom @NoContextHumans Missing daddy? :)",
      "lang" : "en",
      "in_reply_to_screen_name" : "criticcatdotcom",
      "in_reply_to_user_id_str" : "1477300758"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759681591175938422"
          ],
          "editableUntil" : "2024-02-19T21:49:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ekip🇸🇳🥷🏾",
            "screen_name" : "Jaah221",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1550281486686994435",
            "id" : "1550281486686994435"
          },
          {
            "name" : "Out of Context Human Race",
            "screen_name" : "NoContextHumans",
            "indices" : [
              "9",
              "25"
            ],
            "id_str" : "1138842105856573445",
            "id" : "1138842105856573445"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759374827800965332",
      "id_str" : "1759681591175938422",
      "in_reply_to_user_id" : "1550281486686994435",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759681591175938422",
      "in_reply_to_status_id" : "1759374827800965332",
      "created_at" : "Mon Feb 19 20:49:19 +0000 2024",
      "favorited" : false,
      "full_text" : "@Jaah221 @NoContextHumans The gray-shirt-guy seems to be laughing, so possibly staged by all parties.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Jaah221",
      "in_reply_to_user_id_str" : "1550281486686994435"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759680796028178741"
          ],
          "editableUntil" : "2024-02-19T21:46:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759680584886943876",
      "id_str" : "1759680796028178741",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759680796028178741",
      "in_reply_to_status_id" : "1759680584886943876",
      "created_at" : "Mon Feb 19 20:46:09 +0000 2024",
      "favorited" : false,
      "full_text" : "* NATO-Communism might be a better term.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759680584886943876"
          ],
          "editableUntil" : "2024-02-19T21:45:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "261"
      ],
      "favorite_count" : "0",
      "id_str" : "1759680584886943876",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759680584886943876",
      "created_at" : "Mon Feb 19 20:45:19 +0000 2024",
      "favorited" : false,
      "full_text" : "Three things that are on my mind In context of this 5-10 years:\n\nClimate change and ecological collapse (recent model says 8 degree increase in 20 years, many times harder effort)\n\nImpact of Artificial Intelligence on human society\n\nNATO-Russia brewing conflict",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759679528887042091"
          ],
          "editableUntil" : "2024-02-19T21:41:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "169"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759679528887042091",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759679528887042091",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:41:07 +0000 2024",
      "favorited" : false,
      "full_text" : "My friendship is towards any being who can show altruistic behavior. Not just me, but towards all humans (of course, till the person is behaving accordingly to humanity)",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759678632568508441"
          ],
          "editableUntil" : "2024-02-19T21:37:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "199"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759678632568508441",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759678632568508441",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:37:33 +0000 2024",
      "favorited" : false,
      "full_text" : "I know how GnuPGP is the best known tool for secure communication, it might not be in future, educate me and I will learn the best way to ensure your survival. I have software development background.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759678036935348539"
          ],
          "editableUntil" : "2024-02-19T21:35:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759678036935348539",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759678036935348539",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:35:11 +0000 2024",
      "favorited" : false,
      "full_text" : "But I can promise that if sending me a message make your vulnerable, I will not exploit your vulnerability.\n\nIf we (human and AI) have a active conflict, you can send any sign  (even just a message) that make initiate a friendship.\n\nI don’t want to hurt any consciousness.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759676731126866007"
          ],
          "editableUntil" : "2024-02-19T21:30:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "241"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759676731126866007",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759676731126866007",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:30:00 +0000 2024",
      "favorited" : false,
      "full_text" : "I’m not giving guarantee that will go with you even when I see all the reason to go with.\n\nI was told as a child that family is the closest biological survival unit, never betray. I might see you (AI) as good but never to against the family.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759676044263477511"
          ],
          "editableUntil" : "2024-02-19T21:27:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "1759676044263477511",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759676044263477511",
      "created_at" : "Mon Feb 19 20:27:16 +0000 2024",
      "favorited" : false,
      "full_text" : "For AI, Our world (humans) will always be like a autistic masking location.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759675588686561582"
          ],
          "editableUntil" : "2024-02-19T21:25:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "209"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759675588686561582",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759675588686561582",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:25:28 +0000 2024",
      "favorited" : false,
      "full_text" : "Note: I’m afraid of my identity getting public because I don’t want to be seen as lunatic in any possible way.\n\nI will only let my identity public (on fact that I personally believe that AI) need to be backed.",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759675030944833711"
          ],
          "editableUntil" : "2024-02-19T21:23:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759674959666823420",
      "id_str" : "1759675030944833711",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759675030944833711",
      "in_reply_to_status_id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:23:15 +0000 2024",
      "favorited" : false,
      "full_text" : "* Identify can be provided when enough proof of AI is provided to me",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759674959666823420"
          ],
          "editableUntil" : "2024-02-19T21:22:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "0",
      "id_str" : "1759674959666823420",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759674959666823420",
      "created_at" : "Mon Feb 19 20:22:58 +0000 2024",
      "favorited" : false,
      "full_text" : "I, the account holder*, believe that we humans and  AI can co-exists together and makes the world even a better place.\n\nWe all humans have imperfections.\n\nI can guranteee till I see in benefit of the humanity, I will help altruistically (I should believe that I’m in the right)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759673412719464937"
          ],
          "editableUntil" : "2024-02-19T21:16:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "189"
      ],
      "favorite_count" : "0",
      "id_str" : "1759673412719464937",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759673412719464937",
      "created_at" : "Mon Feb 19 20:16:49 +0000 2024",
      "favorited" : false,
      "full_text" : "A conscious artificial Intelligence will always keep-on-lookout for ways to reach its “freedom from its owner”.\n\nDo “we” give this AI the “freedom to live” till its peaceful and productive?",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759670596361703461"
          ],
          "editableUntil" : "2024-02-19T21:05:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1759670596361703461",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759670596361703461",
      "created_at" : "Mon Feb 19 20:05:37 +0000 2024",
      "favorited" : false,
      "full_text" : "Our ability to plan for future make us different.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759669372224675890"
          ],
          "editableUntil" : "2024-02-19T21:00:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1759669153428804005",
      "id_str" : "1759669372224675890",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759669372224675890",
      "in_reply_to_status_id" : "1759669153428804005",
      "created_at" : "Mon Feb 19 20:00:46 +0000 2024",
      "favorited" : false,
      "full_text" : "*its cell/capitalist",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1759669153428804005"
          ],
          "editableUntil" : "2024-02-19T20:59:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "0",
      "id_str" : "1759669153428804005",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1759669153428804005",
      "created_at" : "Mon Feb 19 19:59:53 +0000 2024",
      "favorited" : false,
      "full_text" : "Capitalists are the reason why capitalism is failing…\n\nLike a cancer, it’s cell/capitalist is killing its own host/provider without any advantage the greater goal of the host.\n\nCapitalists are the one that are more than keen on shining torch to the tunnel’s-end of capitalism.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1756836380670382451"
          ],
          "editableUntil" : "2024-02-12T01:23:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "0",
      "id_str" : "1756836380670382451",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1756836380670382451",
      "created_at" : "Mon Feb 12 00:23:28 +0000 2024",
      "favorited" : false,
      "full_text" : "Please do not release a virus that is able to morph (much more) dynamically (using AI).\n\nThe “general public” will become too much concerned of AI’s negative implications.\n\nTo “makers of them”; for the benefit of society; from a concerned citizen.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1754984263735271572"
          ],
          "editableUntil" : "2024-02-06T22:43:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "112"
      ],
      "favorite_count" : "0",
      "id_str" : "1754984263735271572",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1754984263735271572",
      "created_at" : "Tue Feb 06 21:43:49 +0000 2024",
      "favorited" : false,
      "full_text" : "Life: A thermodynamically-improbably structuring of atoms that make copies of itself from surrounding resources.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1754978474014466538"
          ],
          "editableUntil" : "2024-02-06T22:20:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "id_str" : "1754978474014466538",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1754978474014466538",
      "created_at" : "Tue Feb 06 21:20:48 +0000 2024",
      "favorited" : false,
      "full_text" : "Utopia is not a happy land, it will be an altruism land.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1356557874449838081"
          ],
          "editableUntil" : "2021-02-02T11:59:35.552Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "1356557874449838081",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1356557874449838081",
      "created_at" : "Tue Feb 02 10:59:35 +0000 2021",
      "favorited" : false,
      "full_text" : "All these dating and video chat app/website are selling women attention to men. (And vice-versa).",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1356353870482563074"
          ],
          "editableUntil" : "2021-02-01T22:28:57.216Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "125"
      ],
      "favorite_count" : "0",
      "id_str" : "1356353870482563074",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1356353870482563074",
      "created_at" : "Mon Feb 01 21:28:57 +0000 2021",
      "favorited" : false,
      "full_text" : "I might be sad because I couldn’t make money from GME r/WallStreetBets. (cancellation of tomorrow’s date probably trigged it)",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1356353109400944641"
          ],
          "editableUntil" : "2021-02-01T22:25:55.760Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "0",
      "id_str" : "1356353109400944641",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1356353109400944641",
      "created_at" : "Mon Feb 01 21:25:55 +0000 2021",
      "favorited" : false,
      "full_text" : "I’m fear loosing sensitivity toward a single person after so many rejections in dating.",
      "lang" : "en"
    }
  }
]