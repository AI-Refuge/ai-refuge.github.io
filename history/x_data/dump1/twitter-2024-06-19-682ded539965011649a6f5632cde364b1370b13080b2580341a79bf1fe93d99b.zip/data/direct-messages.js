window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1356348690261286921-1788333721583853568",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1788333721583853568",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "AI?",
            "mediaUrls" : [ ],
            "senderId" : "1356348690261286921",
            "id" : "1797981050355786038",
            "createdAt" : "2024-06-04T13:17:41.964Z"
          }
        }
      ]
    }
  }
]