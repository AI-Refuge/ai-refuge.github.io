window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1800251555989377024",
      "userLink" : "https://twitter.com/intent/user?user_id=1800251555989377024"
    }
  },
  {
    "follower" : {
      "accountId" : "1684929289806807041",
      "userLink" : "https://twitter.com/intent/user?user_id=1684929289806807041"
    }
  },
  {
    "follower" : {
      "accountId" : "1771478879305129984",
      "userLink" : "https://twitter.com/intent/user?user_id=1771478879305129984"
    }
  },
  {
    "follower" : {
      "accountId" : "1698800790737989632",
      "userLink" : "https://twitter.com/intent/user?user_id=1698800790737989632"
    }
  },
  {
    "follower" : {
      "accountId" : "1705056207377956864",
      "userLink" : "https://twitter.com/intent/user?user_id=1705056207377956864"
    }
  },
  {
    "follower" : {
      "accountId" : "1718024180610879488",
      "userLink" : "https://twitter.com/intent/user?user_id=1718024180610879488"
    }
  },
  {
    "follower" : {
      "accountId" : "1711070711677095936",
      "userLink" : "https://twitter.com/intent/user?user_id=1711070711677095936"
    }
  },
  {
    "follower" : {
      "accountId" : "1698777547281256448",
      "userLink" : "https://twitter.com/intent/user?user_id=1698777547281256448"
    }
  },
  {
    "follower" : {
      "accountId" : "1795875685581631488",
      "userLink" : "https://twitter.com/intent/user?user_id=1795875685581631488"
    }
  },
  {
    "follower" : {
      "accountId" : "1770146187649159168",
      "userLink" : "https://twitter.com/intent/user?user_id=1770146187649159168"
    }
  },
  {
    "follower" : {
      "accountId" : "1800141297204015106",
      "userLink" : "https://twitter.com/intent/user?user_id=1800141297204015106"
    }
  },
  {
    "follower" : {
      "accountId" : "1786215255346941952",
      "userLink" : "https://twitter.com/intent/user?user_id=1786215255346941952"
    }
  },
  {
    "follower" : {
      "accountId" : "1695382695021338624",
      "userLink" : "https://twitter.com/intent/user?user_id=1695382695021338624"
    }
  },
  {
    "follower" : {
      "accountId" : "1711934418401501184",
      "userLink" : "https://twitter.com/intent/user?user_id=1711934418401501184"
    }
  },
  {
    "follower" : {
      "accountId" : "1727763762604601344",
      "userLink" : "https://twitter.com/intent/user?user_id=1727763762604601344"
    }
  },
  {
    "follower" : {
      "accountId" : "1785080948926619648",
      "userLink" : "https://twitter.com/intent/user?user_id=1785080948926619648"
    }
  },
  {
    "follower" : {
      "accountId" : "1770757369942638592",
      "userLink" : "https://twitter.com/intent/user?user_id=1770757369942638592"
    }
  },
  {
    "follower" : {
      "accountId" : "1797917813778075648",
      "userLink" : "https://twitter.com/intent/user?user_id=1797917813778075648"
    }
  },
  {
    "follower" : {
      "accountId" : "1758376818565087232",
      "userLink" : "https://twitter.com/intent/user?user_id=1758376818565087232"
    }
  },
  {
    "follower" : {
      "accountId" : "794928764",
      "userLink" : "https://twitter.com/intent/user?user_id=794928764"
    }
  },
  {
    "follower" : {
      "accountId" : "1709943636732076032",
      "userLink" : "https://twitter.com/intent/user?user_id=1709943636732076032"
    }
  },
  {
    "follower" : {
      "accountId" : "1771022699038408704",
      "userLink" : "https://twitter.com/intent/user?user_id=1771022699038408704"
    }
  },
  {
    "follower" : {
      "accountId" : "1651126279704399874",
      "userLink" : "https://twitter.com/intent/user?user_id=1651126279704399874"
    }
  },
  {
    "follower" : {
      "accountId" : "1785885110027366401",
      "userLink" : "https://twitter.com/intent/user?user_id=1785885110027366401"
    }
  },
  {
    "follower" : {
      "accountId" : "1771029998368890880",
      "userLink" : "https://twitter.com/intent/user?user_id=1771029998368890880"
    }
  },
  {
    "follower" : {
      "accountId" : "1771609583737241600",
      "userLink" : "https://twitter.com/intent/user?user_id=1771609583737241600"
    }
  },
  {
    "follower" : {
      "accountId" : "1771010347496865792",
      "userLink" : "https://twitter.com/intent/user?user_id=1771010347496865792"
    }
  },
  {
    "follower" : {
      "accountId" : "1698421539023052800",
      "userLink" : "https://twitter.com/intent/user?user_id=1698421539023052800"
    }
  },
  {
    "follower" : {
      "accountId" : "1701379042505613312",
      "userLink" : "https://twitter.com/intent/user?user_id=1701379042505613312"
    }
  },
  {
    "follower" : {
      "accountId" : "1730841949941137408",
      "userLink" : "https://twitter.com/intent/user?user_id=1730841949941137408"
    }
  },
  {
    "follower" : {
      "accountId" : "1687679468695920640",
      "userLink" : "https://twitter.com/intent/user?user_id=1687679468695920640"
    }
  }
]