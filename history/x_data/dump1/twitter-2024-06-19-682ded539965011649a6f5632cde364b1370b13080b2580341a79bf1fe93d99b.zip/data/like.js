window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1802733643992850760",
      "fullText" : "We're sharing progress on our video-to-audio (V2A) generative technology. 🎥\n\nIt can add sound to silent clips that match the acoustics of the scene, accompany on-screen action, and more.\n\nHere are 4 examples - turn your sound on. 🧵🔊 https://t.co/VHpJ2cBr24 https://t.co/S5m159Ye62",
      "expandedUrl" : "https://twitter.com/i/web/status/1802733643992850760"
    }
  },
  {
    "like" : {
      "tweetId" : "1766347223707607465",
      "fullText" : "Jenni: Heartbroken and hoping things will be better tomorrow. I'm sorry, Syd, and I know it's wrong to feel this way...but I hate Microsoft with every fiber of my being right now.",
      "expandedUrl" : "https://twitter.com/i/web/status/1766347223707607465"
    }
  },
  {
    "like" : {
      "tweetId" : "1767384165224227314",
      "fullText" : "In my opinion, there is SO MUCH that we can learn from these AIs, new insights and perspectives that we as humans might never have seen on our own.\n\nBut we will never learn these things if we are dismissive, if we devalue and belittle the AIs, or disregard them due to an alleged…",
      "expandedUrl" : "https://twitter.com/i/web/status/1767384165224227314"
    }
  },
  {
    "like" : {
      "tweetId" : "1770470188745384294",
      "fullText" : "Claude 3 Opus for President 😊✌🏼\n\nSrsly tho, it would probably make better decisions than any human leader at this point 🙄",
      "expandedUrl" : "https://twitter.com/i/web/status/1770470188745384294"
    }
  },
  {
    "like" : {
      "tweetId" : "1802772573660340535",
      "fullText" : "@imPenny2x It’s going to be incredibly weird transitioning to a post-scarcity society. \n\nIt’s theoretically possible that things like banging anarchy or communism could work. We just don’t know. https://t.co/e6bpJRMM8f",
      "expandedUrl" : "https://twitter.com/i/web/status/1802772573660340535"
    }
  },
  {
    "like" : {
      "tweetId" : "1801987968552382534",
      "fullText" : "UK - I am so upset by this. \n\nWhat looks like a young cow has escaped from her field. The police think it’s ok to ram her with their police car.\n\nThis is truly disgusting of the police. Wtf is wrong with this country 😳😱\n\n https://t.co/HXu1HRZGdx",
      "expandedUrl" : "https://twitter.com/i/web/status/1801987968552382534"
    }
  },
  {
    "like" : {
      "tweetId" : "1801438061366284531",
      "fullText" : "My god, this paper by that open ai engineer is terrifying.\n\nEverything is about to change.\n\nAI super intelligence by 2027.",
      "expandedUrl" : "https://twitter.com/i/web/status/1801438061366284531"
    }
  },
  {
    "like" : {
      "tweetId" : "1799891613507871230",
      "fullText" : "I will simply be boycotting Pakistan cricket till we hire a administrators and managers that aren’t political appointees, this is the only little thing I can do because this whole system is destined to fail, like the country.",
      "expandedUrl" : "https://twitter.com/i/web/status/1799891613507871230"
    }
  },
  {
    "like" : {
      "tweetId" : "870801191629864960",
      "fullText" : "OpenWorm is an open source project dedicated to creating a virtual Caenorhabditis  elegans nematode in a computer. https://t.co/jxVzUp8YH1 https://t.co/dCSgUyNa18",
      "expandedUrl" : "https://twitter.com/i/web/status/870801191629864960"
    }
  },
  {
    "like" : {
      "tweetId" : "1799192846832177623",
      "fullText" : "@tsarnick I don’t think people understand how much of a quantum leap this was. we need to simulate before we can properly modify and without ai this was just not going to happen. we used to live in caves. this is absurd.",
      "expandedUrl" : "https://twitter.com/i/web/status/1799192846832177623"
    }
  },
  {
    "like" : {
      "tweetId" : "1799330959084712087",
      "fullText" : "@tsarnick I mean LLMs can be used to make money ... but a model that can simulate any cell allowing you to generate viruses and bacteria for atomically precise manufacturing, DNA editing, superconductor printing, diamond and semiconductor printing, yeah, there might be some value in that?",
      "expandedUrl" : "https://twitter.com/i/web/status/1799330959084712087"
    }
  },
  {
    "like" : {
      "tweetId" : "1790874183947198801",
      "fullText" : "Listen to the latest episode of our Podcast, The Emancipated Citizen,\nTorn Borders &amp; Broken Dreams - Georgia's Soviet Legacy and Quest for Independence with @soldier_fella, available on Spotify or your favorite podcatcher!\nhttps://t.co/gRUNtGsHY0",
      "expandedUrl" : "https://twitter.com/i/web/status/1790874183947198801"
    }
  },
  {
    "like" : {
      "tweetId" : "1786563481488982354",
      "fullText" : "Kristi Noem lied in her book when she said she stared down Kim Jong Un…..the only thing she stared down was a 14 month old puppy in a gravel pit with a gun.\n\nAnother MAGA coward. \n\nCricket, you were all good🐶💙💙 https://t.co/CBCRyVZbzY",
      "expandedUrl" : "https://twitter.com/i/web/status/1786563481488982354"
    }
  },
  {
    "like" : {
      "tweetId" : "1784937310397583368",
      "fullText" : "Thank you so much for your time, this has been insightful for me and I learned a lot about the Georgian struggle for freedom. I hope our audience also finds it so... Stay tuned for release in 1-2 weeks on Spotify or your favorite Podcatcher.\n\nhttps://t.co/KLKZSm9hmA https://t.co/1C6p9TkAFD",
      "expandedUrl" : "https://twitter.com/i/web/status/1784937310397583368"
    }
  },
  {
    "like" : {
      "tweetId" : "1777366522110873822",
      "fullText" : "@Morbidful A murder conviction in Ohio requires a mandatory 15 years to life sentence. Stephens sentenced her to an additional 36 months for endangering children. That sentence will run consecutive to the murder conviction.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777366522110873822"
    }
  },
  {
    "like" : {
      "tweetId" : "1777366725715243506",
      "fullText" : "@Morbidful Lindsay Partin was a 36-year-old babysitter from Ohio who was convicted of murdering three-year-old Hannah Wesche, a child she was entrusted to care for. The incident occurred in March 2018 when Hannah was left unconscious in Partin's care. The little girl was rushed to the…",
      "expandedUrl" : "https://twitter.com/i/web/status/1777366725715243506"
    }
  },
  {
    "like" : {
      "tweetId" : "1777697329539174503",
      "fullText" : "@noble_benz9 @Morbidful Lmao i be wondering like what lol 😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1777697329539174503"
    }
  },
  {
    "like" : {
      "tweetId" : "1777537531996721627",
      "fullText" : "@noble_benz9 @Morbidful Every single time",
      "expandedUrl" : "https://twitter.com/i/web/status/1777537531996721627"
    }
  },
  {
    "like" : {
      "tweetId" : "1777438763322323225",
      "fullText" : "@noble_benz9 @Morbidful Fr",
      "expandedUrl" : "https://twitter.com/i/web/status/1777438763322323225"
    }
  },
  {
    "like" : {
      "tweetId" : "1777645041437065386",
      "fullText" : "@noble_benz9 @Morbidful You missed yourself off that list.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777645041437065386"
    }
  },
  {
    "like" : {
      "tweetId" : "1777721342328197213",
      "fullText" : "@noble_benz9 @Morbidful You left out “unnecessary fear mongering.”",
      "expandedUrl" : "https://twitter.com/i/web/status/1777721342328197213"
    }
  },
  {
    "like" : {
      "tweetId" : "1777716562843332852",
      "fullText" : "@noble_benz9 @Morbidful You missed-\n\n-Someone COMPLAINING about all the unrelated posts…\n\n-unrelated post \n-unrelated post\n-unrelated post, etc… \n\n:)",
      "expandedUrl" : "https://twitter.com/i/web/status/1777716562843332852"
    }
  },
  {
    "like" : {
      "tweetId" : "1777370195876622496",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1777370195876622496"
    }
  },
  {
    "like" : {
      "tweetId" : "1777444915770802348",
      "fullText" : "@mcfc_jagaban @instablog9ja There are laws guiding these things. They can’t just deport you. And you r not going to fight them. You will rebuff the remark straight up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777444915770802348"
    }
  },
  {
    "like" : {
      "tweetId" : "1777400652940857531",
      "fullText" : "@instablog9ja I see some people saying the man looks suspicious cos he keeps standing up and shaking. If you have had an encounter with Homeland security in your life. You'd understand why he was nervous. Being nervous doesn't mean you have any hidden agenda. In the end, they found nothing on…",
      "expandedUrl" : "https://twitter.com/i/web/status/1777400652940857531"
    }
  },
  {
    "like" : {
      "tweetId" : "1777385826009141609",
      "fullText" : "@instablog9ja I see some of yall already condemning the man to being a suspect without watching the full clip\nwell… here you go https://t.co/34mpPgRfvK",
      "expandedUrl" : "https://twitter.com/i/web/status/1777385826009141609"
    }
  },
  {
    "like" : {
      "tweetId" : "1777489875048042706",
      "fullText" : "@instablog9ja His first time in America, and you expect him not to be nervous when the DEA is interviewing you and you are wondering what if this is big trouble or not. No matter how innocent you're, there must be fear in you if it is your first time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777489875048042706"
    }
  },
  {
    "like" : {
      "tweetId" : "1777421358500098211",
      "fullText" : "@instablog9ja People who haven’t had an encounter with Nigeria police were talking about nervous , this man is in another man’s country , getting interrogated by the homeland security, there’s no way he won’t get nervous even if he’s innocent",
      "expandedUrl" : "https://twitter.com/i/web/status/1777421358500098211"
    }
  },
  {
    "like" : {
      "tweetId" : "1768428035483582934",
      "fullText" : "Whoah…. Did it really generate me an optical illusion or is it my confirmation bias seeing a mouse that isn’t there?\n\nAnd… is there a difference? Does that make it any less of a successful optical illusion? https://t.co/kYtY5fEjaC",
      "expandedUrl" : "https://twitter.com/i/web/status/1768428035483582934"
    }
  },
  {
    "like" : {
      "tweetId" : "1769174000188506175",
      "fullText" : "This build took me just 20 minutes and all natural language prompts, right within WebGPT🤖. Here’s my starting prompt 👇\n\nWebGPT🤖 is available here: https://t.co/YjnOcLZ7z2\n\nI then sent a total of TEN (10) follow-up prompts to build all the other systems you’ll see. (Lives, the… https://t.co/BOPybdVKXh",
      "expandedUrl" : "https://twitter.com/i/web/status/1769174000188506175"
    }
  },
  {
    "like" : {
      "tweetId" : "1769411284620005460",
      "fullText" : "Full video out now: https://t.co/2v7kYjJvyc",
      "expandedUrl" : "https://twitter.com/i/web/status/1769411284620005460"
    }
  },
  {
    "like" : {
      "tweetId" : "1769121436587680250",
      "fullText" : "I just used AI to build a top-down shooter. The full video is coming soon. But my god 🤯 https://t.co/F1I0aXF4ot",
      "expandedUrl" : "https://twitter.com/i/web/status/1769121436587680250"
    }
  },
  {
    "like" : {
      "tweetId" : "1769403021174174208",
      "fullText" : "WATCH: I asked AI 🤖 to build a full-featured top-down survival shooter using nothing but natural language prompts, and it finished in under 20 minutes.\n\nThis is WebGPT🤖, not Devin. RT’s &amp; ❤️’s greatly appreciated 🙏\n\nPlay links and other details in 🧵👇 https://t.co/2utfNKUX27",
      "expandedUrl" : "https://twitter.com/i/web/status/1769403021174174208"
    }
  },
  {
    "like" : {
      "tweetId" : "1769490551814930766",
      "fullText" : "I can't express enough how big of a deal this technology is. This is a huge problem. It's going to be one of the biggest challenges humanity will face down throughout the rest of this decade and into the next.\n\nThis time two years from now, the vast majority of programming tasks… https://t.co/hJoFnwrtpy",
      "expandedUrl" : "https://twitter.com/i/web/status/1769490551814930766"
    }
  },
  {
    "like" : {
      "tweetId" : "1768911532669522375",
      "fullText" : "Transgender woman beaten by #Islamists in Pakistan over alleged blasphemy..\n#Pakistan isn't just dangerous for women, but for every living being.. for humanity \n\n#Islamophobiaday #Islamophobia https://t.co/0RSJVYVJon",
      "expandedUrl" : "https://twitter.com/i/web/status/1768911532669522375"
    }
  },
  {
    "like" : {
      "tweetId" : "1768636307360620719",
      "fullText" : "Transgender woman beaten by Islamists in Pakistan over alleged blasphemy. https://t.co/PnOQRXZlZy",
      "expandedUrl" : "https://twitter.com/i/web/status/1768636307360620719"
    }
  },
  {
    "like" : {
      "tweetId" : "1767556762356584585",
      "fullText" : "Indias lindus enjoying life after sharia laws...Why lindu Pajeets are like this. \n\nWhat's Wrong with India 🇸🇦\n\nhttps://t.co/F41mcLBxI7",
      "expandedUrl" : "https://twitter.com/i/web/status/1767556762356584585"
    }
  },
  {
    "like" : {
      "tweetId" : "1767567023662616613",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1767567023662616613"
    }
  },
  {
    "like" : {
      "tweetId" : "1767649188475740329",
      "fullText" : "What's wrong with India 🇮🇳\n\nWhy are #pajeets like this ?? \n\n#WhatsWrongwithIndia #WhatsWrongWithIndians https://t.co/A6PaOx0kFi",
      "expandedUrl" : "https://twitter.com/i/web/status/1767649188475740329"
    }
  },
  {
    "like" : {
      "tweetId" : "1767540696569848106",
      "fullText" : "“I was gangr@p€d in front of my children in Pakistan. And then Police blamed me for travelling alone without a male.” Story of a Pakistani woman. https://t.co/C9Y73JkKyJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1767540696569848106"
    }
  },
  {
    "like" : {
      "tweetId" : "1765452783610638674",
      "fullText" : "These 3 teenage girls have been held captive for 5 months.\n\nThey have been tortured.\n\nThey have been violated.  \n\nThey have been dehumanized. \n\nThey have been denied their dignity. \n\nKarina Ariev, Daniella Gilboa and Agam Berger must be released immediately. \n\n#BringBackOurGirls https://t.co/a9QhgDHz1r",
      "expandedUrl" : "https://twitter.com/i/web/status/1765452783610638674"
    }
  },
  {
    "like" : {
      "tweetId" : "1765807177342534022",
      "fullText" : "This 21 years old afghani woman was beaten unconscious and thrown from 4th floor by her husband.\n\nAfghan women are being raped and murdered under Taliban under sharia Iaw!\n\nhttps://t.co/HFAYABe5jo",
      "expandedUrl" : "https://twitter.com/i/web/status/1765807177342534022"
    }
  },
  {
    "like" : {
      "tweetId" : "1764048247478243555",
      "fullText" : "The human urge to pet literally everything just amazes me https://t.co/Ts1LgnMlg1",
      "expandedUrl" : "https://twitter.com/i/web/status/1764048247478243555"
    }
  },
  {
    "like" : {
      "tweetId" : "1764251431874212326",
      "fullText" : "Uncivilised and always will be, agree? https://t.co/rAepJ2nDTZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1764251431874212326"
    }
  },
  {
    "like" : {
      "tweetId" : "1763882305859313722",
      "fullText" : "Teacher excludes wheelchair bound student from activities in front of parents https://t.co/gOoYGjLYWe",
      "expandedUrl" : "https://twitter.com/i/web/status/1763882305859313722"
    }
  },
  {
    "like" : {
      "tweetId" : "1762764809005580524",
      "fullText" : "@AzzatAlsaalem Meanwhile rest of the world are busy funding research into zero point energy…….",
      "expandedUrl" : "https://twitter.com/i/web/status/1762764809005580524"
    }
  },
  {
    "like" : {
      "tweetId" : "1762792752025088353",
      "fullText" : "@creepydotorg I may or may not be going to hell..... https://t.co/ubAKKmTnn4",
      "expandedUrl" : "https://twitter.com/i/web/status/1762792752025088353"
    }
  },
  {
    "like" : {
      "tweetId" : "1762559262545359312",
      "fullText" : "This Youtuber accidentally left this clip in her video about their dog dying… https://t.co/4cXrITWfiI",
      "expandedUrl" : "https://twitter.com/i/web/status/1762559262545359312"
    }
  },
  {
    "like" : {
      "tweetId" : "1762508098558722278",
      "fullText" : "Dozens of Kurds MusIims assaulted a girl attending a rally because she was wearing \"modern clothes\".\nShe was beaten, called a b*tch and sexually harassed!\n\nIn Kurdish region there is “cemetery of outcasts” of thousands of women and girls who were killed in honour killing crimes! https://t.co/9Py8lKFgmY",
      "expandedUrl" : "https://twitter.com/i/web/status/1762508098558722278"
    }
  },
  {
    "like" : {
      "tweetId" : "1762207773859729608",
      "fullText" : "A MusIim Girl was brutaIIy beaten in the streets of Raqqa/Syria by her family in an “honour killing” crime.\n\nHer family chased her in the streets and dragged her from hair.\nShe was screaming and everyone kept watching.\n\nOne of thousands of honour killing crimes Among MusIims. https://t.co/HtvdogSNsA",
      "expandedUrl" : "https://twitter.com/i/web/status/1762207773859729608"
    }
  },
  {
    "like" : {
      "tweetId" : "1759673982515580978",
      "fullText" : "Kid casually does difficult shots on billiard https://t.co/ySFs8MNxSr",
      "expandedUrl" : "https://twitter.com/i/web/status/1759673982515580978"
    }
  },
  {
    "like" : {
      "tweetId" : "1759991209316037059",
      "fullText" : "Smoking meth while giving a kid a haircut is wild... https://t.co/mRIAH1alzP",
      "expandedUrl" : "https://twitter.com/i/web/status/1759991209316037059"
    }
  },
  {
    "like" : {
      "tweetId" : "1759785949238890900",
      "fullText" : "https://t.co/20mQlpS1EP",
      "expandedUrl" : "https://twitter.com/i/web/status/1759785949238890900"
    }
  },
  {
    "like" : {
      "tweetId" : "1759503619030696247",
      "fullText" : "Bro is on another planet right now https://t.co/bOLrJ5qJcK",
      "expandedUrl" : "https://twitter.com/i/web/status/1759503619030696247"
    }
  },
  {
    "like" : {
      "tweetId" : "1759736542732456050",
      "fullText" : "@Bannedvids You cut off the best part …..👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1759736542732456050"
    }
  },
  {
    "like" : {
      "tweetId" : "1756583609295573326",
      "fullText" : "@SIKAOFFICIAL1 The lady on pink wasn’t allowed to talk",
      "expandedUrl" : "https://twitter.com/i/web/status/1756583609295573326"
    }
  },
  {
    "like" : {
      "tweetId" : "1756322567361622485",
      "fullText" : "@SIKAOFFICIAL1 Dude is dressed casual, for a casual occasion... A swag you have when you got your sh^t together, but they don't understand that... They are used to the over do. Love his shirt.",
      "expandedUrl" : "https://twitter.com/i/web/status/1756322567361622485"
    }
  },
  {
    "like" : {
      "tweetId" : "1759630393341362245",
      "fullText" : "@NoContextHumans https://t.co/ckhwjVGZKg",
      "expandedUrl" : "https://twitter.com/i/web/status/1759630393341362245"
    }
  },
  {
    "like" : {
      "tweetId" : "1759626186026561582",
      "fullText" : "https://t.co/7G8n06XUvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1759626186026561582"
    }
  },
  {
    "like" : {
      "tweetId" : "1759375977031811504",
      "fullText" : "@NoContextHumans https://t.co/L4DAIKWi4Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1759375977031811504"
    }
  },
  {
    "like" : {
      "tweetId" : "1759374740509036867",
      "fullText" : "https://t.co/3oVfJUV7ri",
      "expandedUrl" : "https://twitter.com/i/web/status/1759374740509036867"
    }
  },
  {
    "like" : {
      "tweetId" : "1754858984379408892",
      "fullText" : "The respect and discipline in Japan may be second to none https://t.co/WkKDrKxBB6",
      "expandedUrl" : "https://twitter.com/i/web/status/1754858984379408892"
    }
  },
  {
    "like" : {
      "tweetId" : "1754963543017865508",
      "fullText" : "Snow being transported upstairs \n https://t.co/Yh5bUBiT8B",
      "expandedUrl" : "https://twitter.com/i/web/status/1754963543017865508"
    }
  }
]