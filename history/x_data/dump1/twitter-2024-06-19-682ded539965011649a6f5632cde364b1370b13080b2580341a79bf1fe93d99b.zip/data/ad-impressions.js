window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Consummate Technologies",
                "screenName" : "@Consummate92446"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 10:23:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767558098237956412",
                "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟 https://t.co/7Zpt0vwfGR",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/7Zpt0vwfGR"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "rieker_official",
                "screenName" : "@riekerofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "NBA basketball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sports"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Skiing"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 10:22:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Worst Gron",
                "screenName" : "@WorstG6700"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-21 11:27:10"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571600084533541",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-21 12:52:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "breezypinescabin",
                "screenName" : "@breezypine9"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 12:56:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-21 12:53:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770080407306043684",
                "tweetText" : "Entwickelt für Menschen, die Probleme mit Fressattacken haben. 🍕\n\nDieser Hypnosekurs erleichtert das Gewichtsmanagement. 💆‍♂️\n\nVor allem müssen Sie sich nicht anstrengen:\n\n🎧 Setzen Sie Ihre Kopfhörer auf;\n🧘‍♂️ Hören Sie Hypnosesitzungen;\n✨ Erleben Sie sofortige Ergebnisse.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hypnozio",
                "screenName" : "@hypnozio"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-21 12:57:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1753438110623383583",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 12:57:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Andreia",
                "screenName" : "@andreiashelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 12:52:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 12:57:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259118682121",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-21 13:04:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-21 13:05:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768563022551732609",
                "tweetText" : "The #EU has approved a new #MigrationPact last year. It was meant to be the bloc's comprehensive reform, but some unanswered questions remained, like #outsourcing and #migrationdeals with third countries.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FactRefuge",
                "screenName" : "@FactRefuge"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political News"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political issues"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Politics"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-21 13:06:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320967221375",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-21 13:01:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765649021958488118",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-21 13:01:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Kentucky Derby & Sports Memorabilia",
                "screenName" : "@dsportmemorabil"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 13:06:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829111439966252",
                "tweetText" : "Erstaunlich oft tauchen Jugendliche ab. Schuld ist eine paradoxe Mischung aus Hybris und Selbstzweifeln. Aber wo sind sie – und wie holen wir sie zurück?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-21 13:05:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770057712312676627",
                "tweetText" : "💼 Starting a business in ~30min? It's faster than ordering pizza!\n☕ Running it from your favourite coffee shop? Just don't spill your latte on your laptop!\n🧙‍♂️ Benefits? Oh, just 24/7 remote access, no paper cuts, and a squad of business wizards at your fingertips!\n#eResidency https://t.co/j4PEbKsvVX",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/j4PEbKsvVX"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "e-Residency: Estonia",
                "screenName" : "@e_Residents"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-26 12:18:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254603639230582",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:18:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700128166152",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:15:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-26 12:15:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Vital Technology Solutions",
                "screenName" : "@VitalTechn59566"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:07:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-26 12:16:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Mnombo Tato",
                "screenName" : "@abuti_dot"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-26 12:14:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-26 12:14:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765649139633987682",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-26 12:10:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:06:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1772206416645796168",
                "tweetText" : "Ein geheimes Projekt hat das Licht der Welt erblickt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "hotelcasavelas",
                "screenName" : "@hotelcasav19714"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:09:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519551843779006",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/AzNtalyE3U",
                "urls" : [
                  "https://t.co/AzNtalyE3U"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:15:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1772209866154635505",
                "tweetText" : "Der irrtümliche Tweet lüftete das größte Geheimnis des Jahres",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Cafe Sould Oyles Town",
                "screenName" : "@CafeOyles51650"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-26 12:08:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Charming Dallas Flowers",
                "screenName" : "@charmingda2383"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:10:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Vital Technology Solutions",
                "screenName" : "@VitalTechn59566"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-26 12:08:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-26 12:07:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Mnombo Tato",
                "screenName" : "@abuti_dot"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-26 12:09:44"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-27 00:34:38"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768255759530500433",
                "tweetText" : "Spare 300 € auf Babbel Lifetime! Sprich an jedem Tag der Woche eine andere Sprache. 🧡 Erhalte unbegrenzt Zugang zu allen 14 Sprachen mit Babbel Lifetime.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-27 14:02:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Computer Concepts USA",
                "screenName" : "@computerconcep"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-27 20:34:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1772995688206418107",
                "tweetText" : "Wat staat het programma in de toekomst te wachten en of de feiten zijn bevestigd!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nashville Production and Design",
                "screenName" : "@nashvilleprodu"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-27 17:00:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-27 17:00:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1772939975912243580",
                "tweetText" : "Last chance to get iPhone Photo Academy for an incredibly low price! 😲📱📸\n\nSo if you want to take stunning iPhone photos that leave everyone speechless...\n\nThen now is the perfect time to get this course!\n\nSign up now before the 80% discount ends:\n\nhttps://t.co/FuwvLBXVam",
                "urls" : [
                  "https://t.co/FuwvLBXVam"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "iPhone Photography School",
                "screenName" : "@iPhone_PS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-27 13:49:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-28 08:36:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-28 08:36:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829110508999137",
                "tweetText" : "Narzissten wollen immer heller strahlen als ihr Gegenüber. Dafür ist ihnen meist jedes Mittel recht: Manipulation, Beschimpfungen und dreiste Lügen. Woran merkt man, dass einem das in der eigenen Beziehung widerfährt – und wie geht man damit um?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-28 11:29:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Charming Dallas Flowers",
                "screenName" : "@charmingda2383"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-29 13:37:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-29 13:34:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765647718620524860",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 13:36:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752669916849963397",
                "tweetText" : "RT @fever_gl: Frida Kahlo erleben, hören, fühlen! Kunst wird erlebbar 🤲🎶",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 13:33:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1772956168136118728",
                "tweetText" : "Noura Islam, Destination Development Manager at Red Sea Global, is creating authentic guest experiences at The Red Sea. Her role supports the #PIFstrategy of driving industries such as tourism by creating new destinations. \n\n#InvestedInBetter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Public Investment Fund",
                "screenName" : "@PIF_en"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Leadership"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-29 13:35:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773233102120468630",
                "tweetText" : "Das FlexiArm Design™ mit ausfahrbarer Seitenbürste ermöglicht eine 100%ige Abdeckung der Ecken und Kanten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roborock",
                "screenName" : "@roborockglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Family and life stages"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Pets"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-29 13:34:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-29 21:52:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 21:51:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773233102120468630",
                "tweetText" : "Das FlexiArm Design™ mit ausfahrbarer Seitenbürste ermöglicht eine 100%ige Abdeckung der Ecken und Kanten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roborock",
                "screenName" : "@roborockglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Family and life stages"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Pets"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-29 21:53:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 21:53:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-29 21:53:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 18:49:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-29 18:49:52"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-30 20:00:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-30 15:07:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765647321499574443",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-31 08:15:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-31 08:18:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167787384973",
                "tweetText" : "💪 Eine neue Sprache zu lernen ist super.\n🥇 Ein halbes Jahr kostenlos zu lernen ist noch besser!\n\nBabbel, die Sprachlern-App mit über 500.000 ⭐️⭐️⭐️⭐️⭐️-Bewertungen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-31 08:16:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320967221375",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-31 08:15:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773233102120468630",
                "tweetText" : "Das FlexiArm Design™ mit ausfahrbarer Seitenbürste ermöglicht eine 100%ige Abdeckung der Ecken und Kanten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roborock",
                "screenName" : "@roborockglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Family and life stages"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Pets"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-31 08:16:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-31 08:14:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752636087082905961",
                "tweetText" : "\"A young blonde woman with blue eyes and wavy hair\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-31 08:13:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1760864029239582919",
                "tweetText" : "😍 Perfect Electronic Foot File, Dual-Speed Callus Remover ✅\n\n🛒 SHOP NOW 👉 https://t.co/GYacFXEqFf https://t.co/bENYaAgwjt",
                "urls" : [
                  "https://t.co/GYacFXEqFf"
                ],
                "mediaUrls" : [
                  "https://t.co/bENYaAgwjt"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "cartesso",
                "screenName" : "@CartessoUs"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "apps"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "online"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "friends"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "life"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "training"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-31 08:13:53"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765648439055196521",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-31 12:15:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-31 12:16:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-03-31 12:17:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-31 12:15:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-31 12:14:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773235489119850810",
                "tweetText" : "Erlebe ultimativen Komfort mit dem Nachfüll- und Entleerungssystem. Vergiss mühsames Nachfüllen und schmutziges leeren.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Roborock",
                "screenName" : "@roborockglobal"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Family and life stages"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Pets"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-31 12:16:55"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-01 06:31:09"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-01 23:30:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729737452137730259",
                "tweetText" : "\"A realistic photo of a Zebra\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-01 23:30:38"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-22 07:12:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Lorraine Ford",
                "screenName" : "@LorraFordPHOTO"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 07:25:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254339435819357",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 07:22:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-22 07:12:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599337935192",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-22 07:13:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320518431070",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 07:15:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765114591707635917",
                "tweetText" : "Save money and speed up your CI with Nx Cloud Pro.\n\nConnect your repo in minutes. Sign up for a free 2-month trial by the end of March to double your free credits!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nx",
                "screenName" : "@NxDevTools"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-22 07:26:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770329491585331324",
                "tweetText" : "🌷 ECOVACS #springcleaning deals await! \n🛒 https://t.co/TFVZExYy7D\n\n🎁 Plus, 𝘄𝗶𝗻 𝗮 $𝟮𝟬𝟬 𝗔𝗺𝗮𝘇𝗼𝗻 𝗰𝗼𝘂𝗽𝗼𝗻 for your ECOVACS purchase! To enter:\n1. Follow us.\n2. Quote RT &amp; share your ECOVACS story.\nRules: https://t.co/bN1F6o0q5p\n\n⏰ Winner announced Mar 27! https://t.co/Y9fQ5Pu8rE",
                "urls" : [
                  "https://t.co/TFVZExYy7D",
                  "https://t.co/bN1F6o0q5p"
                ],
                "mediaUrls" : [
                  "https://t.co/Y9fQ5Pu8rE"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ECOVACS ROBOTICS",
                "screenName" : "@ecovacsrobotics"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "At home"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 07:22:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Playground Sound",
                "screenName" : "@PlaygroundSoun"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 07:25:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700333695313",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 07:14:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 07:19:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603063760158907",
                "tweetText" : "Intelligenter Ausgeben, Versenden und Sparen? Probiere Revolut. Registriere dich und verwalte deine Finanzen wie ein Profi 💪",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 07:22:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763591300400476399",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 07:16:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Playground Sound",
                "screenName" : "@PlaygroundSoun"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 07:13:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259785580981",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 07:21:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765649139633987682",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-22 06:09:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770837772636738000",
                "tweetText" : "Online Geld verzockt?\nDann mach jetzt unseren kostenlosen Online-Check und hol deine Spiel- und Wettverluste vollständig und risikofrei zurück.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Goldenstein Rechtsanwälte",
                "screenName" : "@goldenstein_ra"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:01:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254603639230582",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:11:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1770643347805499631",
                "tweetText" : "Unleash the power of Turkey Tail mushrooms! Boost your immune system &amp; fight cancer with PSK &amp; PSP. Watch our short clip now for a healthier tomorrow! #TurkeyTail",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Mushroom Rise",
                "screenName" : "@MushroomRise"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 06:06:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-22 06:01:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321072087552",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:03:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764855857584410957",
                "tweetText" : "No tradeoffs! Both faster and cheaper CI with Nx Cloud Pro for Startups. Connect your repo in minutes to get started with a free 2-month trial today!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nx",
                "screenName" : "@NxDevTools"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:09:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603554460098765",
                "tweetText" : "Intelligenter Ausgeben, Versenden und Sparen? Probiere Revolut. Registriere dich und verwalte deine Finanzen wie ein Profi 💪",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-22 06:08:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1628646801875038208",
                "tweetText" : "Hüter der münzen und werte. Aus dir wird ein professioneller geldsammler!🪙",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "CoinSnap",
                "screenName" : "@CoinSnap_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "hundreds"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "portable"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "light"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 06:09:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770837772976193653",
                "tweetText" : "Online Geld verzockt?\nDann mach jetzt unseren kostenlosen Online-Check und hol deine Spiel- und Wettverluste vollständig und risikofrei zurück.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Goldenstein Rechtsanwälte",
                "screenName" : "@goldenstein_ra"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 06:05:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770470688945578117",
                "tweetText" : "Video: MajorTech zeigt die neuen Clients der 3CX V20\n\nDie neue 3CX V20 ist seit kurzem verfügbar. Der Youtuber MajorTech führt in dem folgenden Video durch die Telefoniefunktionen der 3CX Clients.\n\nMehr hier:\nhttps://t.co/mWWpSHgzWu\n\n#3CX #majortech https://t.co/qdNDIFilko",
                "urls" : [
                  "https://t.co/mWWpSHgzWu"
                ],
                "mediaUrls" : [
                  "https://t.co/qdNDIFilko"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "3CX DACH",
                "screenName" : "@3CX_DACH"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:10:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768011651192947035",
                "tweetText" : "🔝Explore leading cloud connectivity in LatAm! Join now &amp; get up to $200 credit. ☁️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "EdgeUno",
                "screenName" : "@EdgeUno"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 06:02:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770091332289085455",
                "tweetText" : "Sichern Sie sich spannende Unterhaltung für den Ostertisch: Entdecken Sie Ihren Rabatt für «NZZ Digital» mit einem Klick.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Neue Zürcher Zeitung Deutschland",
                "screenName" : "@NZZde"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Foodie news and general info"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-22 06:02:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765114591707635917",
                "tweetText" : "Save money and speed up your CI with Nx Cloud Pro.\n\nConnect your repo in minutes. Sign up for a free 2-month trial by the end of March to double your free credits!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nx",
                "screenName" : "@NxDevTools"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 06:08:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:05:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762847785269788730",
                "tweetText" : "🔥 To get in shape isn’t as hard as it sounds!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UniMeal",
                "screenName" : "@UnimealPlans"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : " Purchase GTM"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-22 06:07:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-22 06:05:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603379725467831",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:10:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747956520149791176",
                "tweetText" : "Create videos within ChatGPT 🪄 \nTry our VideoMaker on the GPT Store &gt;&gt;\n\nChatGPT Plus required ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "invideo",
                "screenName" : "@invideoOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 06:05:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-22 05:57:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Andreia",
                "screenName" : "@andreiashelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 05:56:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "thetechcompany",
                "screenName" : "@thetechcompan"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 05:57:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599337935192",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-22 05:57:50"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1726914591123493023",
                "tweetText" : "RT @fever_gl: Viva Frida Kahlo Berlin - jetzt Tickets für ein einmaliges Erlebnis sichern!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fever US",
                "screenName" : "@fever_us"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-03 13:38:42"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1733013539034710254",
                "tweetText" : "\"A woman wearing a black A-line dress with a sweetheart neckline and delicate lace detailing\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-04 11:51:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729070939894079970",
                "tweetText" : "Jetzt Ferienlager und Feriencamps für 2024 buchen: Online unter https://t.co/BKINaMa7JY auf der Seite des jeweils gewünschten Projektes: Angeln, Reiten, Englisch, Forscher- und Survival, Fußball und Erlebnis.",
                "urls" : [
                  "https://t.co/BKINaMa7JY"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-04 11:52:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-04 11:45:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1772833170964226513",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-04 11:47:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-04 11:50:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1774919674787922171",
                "tweetText" : "Jährlich sind Millionen Nutzer von Datenpannen betroffen. Auch Du? Dann hast Du eventuell Anspruch auf Entschädigung! Finde mit nur wenigen Klicks heraus, ob Dir eine Erstattung zusteht. Der Check ist unverbindlich und kostenlos.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SMA",
                "screenName" : "@socialmedia_sma"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-04 11:49:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747956520363638870",
                "tweetText" : "Create videos within ChatGPT 🪄 \nTry our VideoMaker on the GPT Store &gt;&gt;\n\nChatGPT Plus required ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "invideo",
                "screenName" : "@invideoOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@openai"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-04 11:51:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732312922724995093",
                "tweetText" : "\"Girl standing outside wearing a white crop top\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-04 11:51:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-04 11:46:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-04 11:53:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476341206401380",
                "tweetText" : "Der legendäre Style des Hauses Versace. #VersaceMedusa95\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-04 11:47:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167787384973",
                "tweetText" : "💪 Eine neue Sprache zu lernen ist super.\n🥇 Ein halbes Jahr kostenlos zu lernen ist noch besser!\n\nBabbel, die Sprachlern-App mit über 500.000 ⭐️⭐️⭐️⭐️⭐️-Bewertungen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-05 06:49:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-05 06:53:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730797712122282139",
                "tweetText" : "\"Beautiful brunette girl in the ocean with cliffs in the background\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-05 06:51:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731057148027699467",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-05 06:53:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Right_Livin",
                "screenName" : "@right_livin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-05 06:51:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-05 06:50:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Lezano",
                "screenName" : "@LezanoSt"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-05 06:49:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476341206401380",
                "tweetText" : "Der legendäre Style des Hauses Versace. #VersaceMedusa95\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-05 06:52:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-05 06:53:37"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1774919674787922171",
                "tweetText" : "Jährlich sind Millionen Nutzer von Datenpannen betroffen. Auch Du? Dann hast Du eventuell Anspruch auf Entschädigung! Finde mit nur wenigen Klicks heraus, ob Dir eine Erstattung zusteht. Der Check ist unverbindlich und kostenlos.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SMA",
                "screenName" : "@socialmedia_sma"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                }
              ],
              "impressionTime" : "2024-04-07 17:16:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603709351620995",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-07 17:16:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-07 17:13:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763558329597530238",
                "tweetText" : "📢 Elevate your crypto game at Crypto Expo Dubai 2024!🚀✨ Don't miss your chance to be a part of the biggest crypto event of 2024! \n\n🌍 Get ready to dive into the world of blockchain, cryptocurrencies, and decentralized finance at Crypto Expo Dubai 2024! 💼💰",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto Expo",
                "screenName" : "@TheCryptoExpo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 17:17:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1776213192672182419",
                "tweetText" : "Kleine Schritte, große Erfolge. Erhalte 60 % Rabatt auf Babbel und sprich eine neue Sprache selbstbewusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 17:16:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 17:16:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 17:14:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476090420576353",
                "tweetText" : "Cillian Murphy präsentiert die erste #VersaceIcons Kollektion für Herren.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-07 17:17:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-07 17:14:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729070939894079970",
                "tweetText" : "Jetzt Ferienlager und Feriencamps für 2024 buchen: Online unter https://t.co/BKINaMa7JY auf der Seite des jeweils gewünschten Projektes: Angeln, Reiten, Englisch, Forscher- und Survival, Fußball und Erlebnis.",
                "urls" : [
                  "https://t.co/BKINaMa7JY"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-07 17:14:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770837772636738000",
                "tweetText" : "Online Geld verzockt?\nDann mach jetzt unseren kostenlosen Online-Check und hol deine Spiel- und Wettverluste vollständig und risikofrei zurück.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Goldenstein Rechtsanwälte",
                "screenName" : "@goldenstein_ra"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 17:14:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770837772976193653",
                "tweetText" : "Online Geld verzockt?\nDann mach jetzt unseren kostenlosen Online-Check und hol deine Spiel- und Wettverluste vollständig und risikofrei zurück.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Goldenstein Rechtsanwälte",
                "screenName" : "@goldenstein_ra"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-07 17:18:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519557359042568",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/aa0aJMYhIa",
                "urls" : [
                  "https://t.co/aa0aJMYhIa"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 17:17:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476674510954931",
                "tweetText" : "Anne Hathaway präsentiert die neue #VersaceIcons Kollektion.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-07 20:25:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519557359042568",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/aa0aJMYhIa",
                "urls" : [
                  "https://t.co/aa0aJMYhIa"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 22:22:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762290802372571539",
                "tweetText" : "Dancing with the fam on IMVU&lt;3",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IMVU",
                "screenName" : "@IMVU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: Social Chat & Avatar app ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "11.22>7.23 Exclusion List"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Sign up IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 22:22:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700128166152",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                }
              ],
              "impressionTime" : "2024-04-07 22:21:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773323401572098318",
                "tweetText" : "📢 Elevate your crypto game at Crypto Expo Dubai 2024!🚀✨ Don't miss your chance to be a part of the biggest crypto event of 2024! \n\n🌍 Get ready to dive into the world of blockchain, cryptocurrencies, and decentralized finance at Crypto Expo Dubai 2024! 💼💰",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto Expo",
                "screenName" : "@TheCryptoExpo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-07 22:26:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1767553252734668923",
                "tweetText" : "Welcome https://t.co/z1IZ9j1hQ0: Ahrefs / Semrush without the price.\n\nFor those who want to improve the traffic of their site with SEO, without paying $99 per month.\n\nCamelRank pricing starts at $4 / month.",
                "urls" : [
                  "https://t.co/z1IZ9j1hQ0"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Neoseed.io",
                "screenName" : "@neoseed_io"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "business"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-07 22:31:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-07 22:21:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731057148027699467",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 22:23:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 22:22:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768602351667929341",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 22:21:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-07 22:24:45"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731057148027699467",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 06:12:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765647951538565455",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 06:13:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700128166152",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 06:13:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775198827303014603",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 06:13:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829110844276946",
                "tweetText" : "Wie viel Geld ist wohl genug? Das ist wie vieles relativ. Meist ist materieller Erfolg ohnehin purer Zufall. Hinter Finanzfragen verbergen sich oft genug andere Schwierigkeiten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-08 06:15:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476674510954931",
                "tweetText" : "Anne Hathaway präsentiert die neue #VersaceIcons Kollektion.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-08 06:15:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 06:11:59"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 13:21:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476674510954931",
                "tweetText" : "Anne Hathaway präsentiert die neue #VersaceIcons Kollektion.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-08 14:35:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829112425574809",
                "tweetText" : "Im Bett ist heutzutage fast alles erlaubt. Nur wer keine Lust hat, bekommt schnell ein Problem. Eine Sexualtherapeutin findet: Man muss es auch lassen dürfen. Und hält wenig von „Gnadensex“ in einer Beziehung.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-08 14:40:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-08 14:34:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732313174198882414",
                "tweetText" : "\"A woman with black hair and a white dress standing in a lake\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 14:42:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765648439055196521",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 14:36:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762290802372571539",
                "tweetText" : "Dancing with the fam on IMVU&lt;3",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IMVU",
                "screenName" : "@IMVU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: Social Chat & Avatar app ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "11.22>7.23 Exclusion List"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Sign up IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 14:40:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731057148027699467",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 14:44:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775766604451651925",
                "tweetText" : "Sie haben in #Berlin eine #Immobilie?! Sie überlegen ernsthaft diese jetzt besser zu verkaufen? Das Ergebnis wird Sie überraschen. https://t.co/nJypLCQVrK https://t.co/XYCdo83FCg",
                "urls" : [
                  "https://t.co/nJypLCQVrK"
                ],
                "mediaUrls" : [
                  "https://t.co/XYCdo83FCg"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buhlig Immobilien",
                "screenName" : "@BuhligImmobili1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-08 14:43:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1758489174435356821",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-08 14:42:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321642483966",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-08 14:43:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1758489174435356821",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-08 15:08:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1776213192638669038",
                "tweetText" : "14 Sprachen, lebenslanger Zugang … Worauf wartest du also noch? Spare heute 60 % auf Babbel Lifetime.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-08 15:07:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-08 15:03:26"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 07:00:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-09 07:01:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775198827303014603",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:40:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742320364372255016",
                "tweetText" : "\"Hedgehogs riding unicycles racing down a hill\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:46:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-09 05:44:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519557359042568",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/aa0aJMYhIa",
                "urls" : [
                  "https://t.co/aa0aJMYhIa"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:41:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476090420576353",
                "tweetText" : "Cillian Murphy präsentiert die erste #VersaceIcons Kollektion für Herren.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-09 05:42:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767553252734668923",
                "tweetText" : "Welcome https://t.co/z1IZ9j1hQ0: Ahrefs / Semrush without the price.\n\nFor those who want to improve the traffic of their site with SEO, without paying $99 per month.\n\nCamelRank pricing starts at $4 / month.",
                "urls" : [
                  "https://t.co/z1IZ9j1hQ0"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Neoseed.io",
                "screenName" : "@neoseed_io"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "innovation"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-09 05:44:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731057148027699467",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:41:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:40:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:44:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732313174198882414",
                "tweetText" : "\"A woman with black hair and a white dress standing in a lake\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 05:40:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Right_Livin",
                "screenName" : "@right_livin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-09 05:42:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-09 05:39:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775199052310720758",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-09 05:44:58"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1745637319154004216",
                "tweetText" : "Scannen Sie beliebige Dokumente und konvertieren Sie sie in bearbeitbare Word-Dateien. 👍 Jetzt kostenlos herunterladen, nicht verpassen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Mobile Scanner",
                "screenName" : "@scanner_mobile"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "-"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 20:57:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777653541936795652",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-09 20:49:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1772833422530285823",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 20:59:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259118682121",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-09 20:46:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1731060922775732513",
                "tweetText" : "\"Girl with blonde hair wearing a backpack in a train\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-09 20:57:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765648540590850117",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-09 20:59:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-09 20:41:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777299098028343640",
                "tweetText" : "In «Zmittag» erzählt Deutschlands mächtigste Bankerin Bettina Orlopp über ihre aufregende Zeit bei der lange kriselnden Commerzbank und ihre Begeisterung für einen Schweizer Schriftsteller.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Neue Zürcher Zeitung Deutschland",
                "screenName" : "@NZZde"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-09 20:52:36"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-11 06:34:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321361506309",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-11 06:37:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1732494619852829047",
                "tweetText" : "\"Girl wearing a bear hat with a bear in the background\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-11 06:37:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829117157048517",
                "tweetText" : "Sparbuch, Girokonto und Aktiendepot? Kinder und Jugendliche erhalten hierzulande kaum Finanzbildung. Was junge Erwachsene wirklich brauchen – und ihre Eltern etwa beim Schenken mit Nießbrauch beachten sollten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-11 06:36:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647718620524860",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-11 06:35:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730797712277471501",
                "tweetText" : "\"Young woman standing on a beach\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-11 06:35:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1777664922647920640",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-11 06:36:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-11 06:37:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771758022903349500",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-11 06:34:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1729070939894079970",
                "tweetText" : "Jetzt Ferienlager und Feriencamps für 2024 buchen: Online unter https://t.co/BKINaMa7JY auf der Seite des jeweils gewünschten Projektes: Angeln, Reiten, Englisch, Forscher- und Survival, Fußball und Erlebnis.",
                "urls" : [
                  "https://t.co/BKINaMa7JY"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-11 06:36:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763591300400476399",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-11 06:35:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775198827303014603",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-11 06:38:05"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321072087552",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-11 20:11:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-11 20:11:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-11 20:08:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599337935192",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-03-22 19:51:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 19:55:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 19:58:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 19:48:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254603639230582",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-22 19:55:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259118682121",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 19:57:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-22 19:50:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700333695313",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                }
              ],
              "impressionTime" : "2024-03-22 19:49:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321072087552",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 19:59:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765648540590850117",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 19:50:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1769736332245406016",
                "tweetText" : "Fly to Delhi and Mumbai from Frankfurt! \nReturn fares starting from EUR 599 all-in.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Vistara",
                "screenName" : "@airvistara"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 19:55:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771137624608006230",
                "tweetText" : "Biotechnology opens up new horizons in healthcare",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Annabelle Bosworth",
                "screenName" : "@AnnbeBosworth"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 19:53:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764855857584410957",
                "tweetText" : "No tradeoffs! Both faster and cheaper CI with Nx Cloud Pro for Startups. Connect your repo in minutes to get started with a free 2-month trial today!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nx",
                "screenName" : "@NxDevTools"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-22 19:56:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603063760158907",
                "tweetText" : "Intelligenter Ausgeben, Versenden und Sparen? Probiere Revolut. Registriere dich und verwalte deine Finanzen wie ein Profi 💪",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 19:57:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-22 19:49:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 19:54:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1767585520593379470",
                "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "rieker_official",
                "screenName" : "@riekerofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "NBA basketball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sports"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 20:17:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1621507993258057728",
                "tweetText" : "Etwas ✨Abwechslung✨ für den Beziehungsalltag gefällig? Unsere Zweisamkeit-Box ist genau das Richtige! 💯\n✅ lustige Challenges\n✅ ein kulinarischer Abend\n✅ ein Monat voller Zweisamkeit &amp; schönen Momenten💝\nBestell jetzt eine begehrte &amp; nachhaltige Zweisamkeit-Box für Paare!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Deine Zweisamkeit",
                "screenName" : "@DZweisamkeit"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:00:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1770459907952685253",
                "tweetText" : "Sogar seriöse Leute haben begonnen, es zu benutzen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bea Attwood",
                "screenName" : "@attwoodPHOTO"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 15.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 20:13:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1770824298107658655",
                "tweetText" : "You can be the best Draven player or simply BE Draven 🤔\n\n@Subway_DE #SKWIN #SKnights https://t.co/zsUCvUYEPE",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/zsUCvUYEPE"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SK Gaming League of Legends",
                "screenName" : "@SKGamingLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:13:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1763217568322539795",
                "tweetText" : "Save energy to be better on the pitch.\n\nHisense Washing Machine with Autodosing functionality shares the same values with the @PSG_inside players to achieve optimal results!\n\n#GoTopAndBeyond | #PSG | #Hisense",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hisense Sports",
                "screenName" : "@HisenseSports"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:05:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259785580981",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 20:12:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1758174346399359053",
                "tweetText" : "The Lenovo Legion Go is taking the industry by storm and giving you a chance to really make the most out of @XboxGamePass! Learn more: https://t.co/NzWXT7q7t6 https://t.co/a0DDXijbGn",
                "urls" : [
                  "https://t.co/NzWXT7q7t6"
                ],
                "mediaUrls" : [
                  "https://t.co/a0DDXijbGn"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lenovo Legion",
                "screenName" : "@LenovoLegion"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-03-22 20:02:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765648540590850117",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:03:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Playground Sound",
                "screenName" : "@PlaygroundSoun"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 20:03:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1767585520593379470",
                "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "rieker_official",
                "screenName" : "@riekerofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "NBA basketball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sports"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 20:07:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730797712277471501",
                "tweetText" : "\"Young woman standing on a beach\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:03:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1769736332245406016",
                "tweetText" : "Fly to Delhi and Mumbai from Frankfurt! \nReturn fares starting from EUR 599 all-in.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Vistara",
                "screenName" : "@airvistara"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                }
              ],
              "impressionTime" : "2024-03-22 20:12:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1763217568322539795",
                "tweetText" : "Save energy to be better on the pitch.\n\nHisense Washing Machine with Autodosing functionality shares the same values with the @PSG_inside players to achieve optimal results!\n\n#GoTopAndBeyond | #PSG | #Hisense",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Hisense Sports",
                "screenName" : "@HisenseSports"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:17:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1749412156225843431",
                "tweetText" : "Discover the hidden power of your iPhone &amp; Apple Watch! Analyze heart rate, stress, sleep, log BP &amp; increase productivity with next-level analytics! Safe &amp; secure.\nBonus: Sync seamlessly with 140 apps!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Welltory. The Wellness Laboratory",
                "screenName" : "@welltory"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 16.2 and above"
                }
              ],
              "impressionTime" : "2024-03-22 20:02:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1679145345584885760",
                "tweetText" : "Die letzte medizinische Erfindung für einen gesunden Bauch",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ProCombo - probiotic + prebiotic",
                "screenName" : "@ProCombo_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-22 20:00:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771221215299981479",
                "tweetText" : "Entfliehen Sie mit Ihrem Liebsten ins Paradies! \n\nBuchen Sie jetzt einen romantischen Urlaub und schaffen Sie unvergessliche Momente mit unseren First-Minute-Angeboten. \n\nGreifen Sie jetzt zu! #Kroatien",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "bluesunhotels",
                "screenName" : "@bluesunhotels"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel Actions"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-22 20:01:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1770907860416790879",
                "tweetText" : "#anotherguess #somethingeasy #series Be the 1st https://t.co/nIv2sJ7qkj",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/nIv2sJ7qkj"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Chris M.",
                "screenName" : "@Ciupanezul"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-22 20:05:11"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-12 01:02:33"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610321642483966",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-12 12:14:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778354804999471504",
                "tweetText" : "😀 Free training course for #ELT teachers:  Managing learners and resources. To sign-up: 👉 https://t.co/UGyh1XAvWC\n\nLearn how to manage resources, groupings and differentiation to help build positive relationships with learners in your classroom.\n\nCourse runs until 31 May.",
                "urls" : [
                  "https://t.co/UGyh1XAvWC"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "TeachingEnglish",
                "screenName" : "@TeachingEnglish"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "teacher"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-04-12 12:14:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1754671104944464362",
                "tweetText" : "Bestie dance the Vu 💕👯 Join us on IMVU",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IMVU",
                "screenName" : "@IMVU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: Social Chat & Avatar app ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "11.22>7.23 Exclusion List"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Sign up IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-12 12:14:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-12 12:12:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-12 12:09:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1730797712122282139",
                "tweetText" : "\"Beautiful brunette girl in the ocean with cliffs in the background\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-12 12:14:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1777646628096327758",
                "tweetText" : "FREE PAYPAL CASE STUDY: \n\nHow I PREVENTED holds and bans while processing 0-800k in 7 days on Shopify PAYPAL\n\nGet Your FREE A-Z Paypal Processing  “HACK” Today Only!👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ZEFI AGENCY",
                "screenName" : "@zefiagency"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-12 12:09:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770476090420576353",
                "tweetText" : "Cillian Murphy präsentiert die erste #VersaceIcons Kollektion für Herren.\n\n#Versace",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "VERSACE",
                "screenName" : "@Versace"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion accessories"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion events"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Fashion Brand"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Fashion"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-12 12:14:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763591300400476399",
                "tweetText" : "Deine Finanzen – ohne den Stress. Mit Revolut ist Geldmanagement so einfach, dass es Spaß macht 🙌 Registriere dich jetzt",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-12 12:13:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778743464315728169",
                "tweetText" : "🌿 100% Natürlich\n💯 Keine Nebenwirkungen\n🔥 Bis zu 20 Stunden vollstes Vergnügen\n🚚 Heute bestellen = Morgen zu Hause\n📦 Diskrete Lieferung #stayhard",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "MrStiff.Official",
                "screenName" : "@MrStiffOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-12 12:10:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771069593920151649",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-12 12:08:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-12 12:08:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1776213192672182419",
                "tweetText" : "Kleine Schritte, große Erfolge. Erhalte 60 % Rabatt auf Babbel und sprich eine neue Sprache selbstbewusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-12 12:12:30"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773084386373570563",
                "tweetText" : "🎮 Building a web3 game? Launch on Solana with GameShift!\n\n✅ Mint &amp; manage game assets\n✅ Non-custodial wallets\n✅ Branded in-game marketplace\n✅ Global credit card payments\n✅ Fiat Payouts\n\nAll with just one API and no blockchain coding.\n\nStart building now 👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Solana Labs",
                "screenName" : "@solanalabs"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-13 23:22:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752636087107833992",
                "tweetText" : "\"A Viking warrior cat\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-13 23:59:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519557359042568",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/aa0aJMYhIa",
                "urls" : [
                  "https://t.co/aa0aJMYhIa"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-13 21:57:17"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647321499574443",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 00:23:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778128392392446218",
                "tweetText" : "Spiele die Closed Beta\nJetzt Sea of Thieves auf PlayStation 5 vorbestellen, um an der Closed Beta vom 12. bis 15. April teilzunehmen.🏴‍☠️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 00:23:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603709351620995",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 00:23:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778128411493310969",
                "tweetText" : "Spiele die Closed Beta\nJetzt Sea of Thieves auf PlayStation 5 vorbestellen, um an der Closed Beta vom 12. bis 15. April teilzunehmen.🏴‍☠️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 11:53:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1777653541936795652",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 11:52:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647718620524860",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 11:52:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167493713982",
                "tweetText" : "Spare jetzt 50% auf Babbel Lifetime!\n\n✅ 1 Zahlung\n✅ 14 Sprachen\n✅ Unbegrenzter Zugang",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 11:52:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777653541936795652",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 11:52:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647951538565455",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-14 11:53:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-14 07:19:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1742320364372255016",
                "tweetText" : "\"Hedgehogs riding unicycles racing down a hill\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 07:17:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1777653541936795652",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 07:15:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752636087107833992",
                "tweetText" : "\"A Viking warrior cat\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 07:19:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-14 07:17:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-14 07:15:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829110844276946",
                "tweetText" : "Wie viel Geld ist wohl genug? Das ist wie vieles relativ. Meist ist materieller Erfolg ohnehin purer Zufall. Hinter Finanzfragen verbergen sich oft genug andere Schwierigkeiten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 07:17:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603709351620995",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-04-14 07:16:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1778737170976575779",
                "tweetText" : "Experience the exotic allure of Saudi Dates - a tantalizing taste straight from the heart of Arabia! 🌴✨ #TasteOfArabia #SaudiDates https://t.co/pncgan2fn8",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/pncgan2fn8"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "المركز الوطني للنخيل والتمور",
                "screenName" : "@NCPD_SA"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-14 10:22:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700128166152",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                }
              ],
              "impressionTime" : "2024-04-14 10:21:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1774119055328448984",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-14 10:17:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732512741296919019",
                "tweetText" : "\"Spiderwoman in an avant-garde suit standing in a chaotic modern metropolis\".\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 10:22:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1730797712277471501",
                "tweetText" : "\"Young woman standing on a beach\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 10:22:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778128411493310969",
                "tweetText" : "Spiele die Closed Beta\nJetzt Sea of Thieves auf PlayStation 5 vorbestellen, um an der Closed Beta vom 12. bis 15. April teilzunehmen.🏴‍☠️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-14 10:20:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647718620524860",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 10:18:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778743464303169738",
                "tweetText" : "🌿 100% Natürlich\n💯 Keine Nebenwirkungen\n🔥 Bis zu 20 Stunden vollstes Vergnügen\n🚚 Heute bestellen = Morgen zu Hause\n📦 Diskrete Lieferung #stayhard",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "MrStiff.Official",
                "screenName" : "@MrStiffOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 10:21:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603709351620995",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-14 10:19:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1778737170976575779",
                "tweetText" : "Experience the exotic allure of Saudi Dates - a tantalizing taste straight from the heart of Arabia! 🌴✨ #TasteOfArabia #SaudiDates https://t.co/pncgan2fn8",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/pncgan2fn8"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "المركز الوطني للنخيل والتمور",
                "screenName" : "@NCPD_SA"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-14 10:22:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1779420379443761227",
                "tweetText" : "✅Just received my $11,715 back from gas spent. Thank you for this opportunity!⤵️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burak",
                "screenName" : "@akkayabrk"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "bone"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2024-04-14 10:19:28"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778128411493310969",
                "tweetText" : "Spiele die Closed Beta\nJetzt Sea of Thieves auf PlayStation 5 vorbestellen, um an der Closed Beta vom 12. bis 15. April teilzunehmen.🏴‍☠️",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-04-14 22:46:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1774118324408131721",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 22:47:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1763883353437069518",
                "tweetText" : "⚡️🌿 Join the energy revolution with MyVolt! Our upcoming platform will empower you to trade clean energy directly using the power of blockchain! \n\n✅ Follow us to stay charged with the latest updates and become part of a community!\n\nWeb: https://t.co/3NUNEgLDL7\n\n#MyVolt #Polygon https://t.co/xqSdJwjzpc",
                "urls" : [
                  "https://t.co/3NUNEgLDL7"
                ],
                "mediaUrls" : [
                  "https://t.co/xqSdJwjzpc"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "MyVolt Official",
                "screenName" : "@myvoltofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-14 22:47:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1772277383543808232",
                "tweetText" : "Abstract submissions are still open for #ISOQOL 2024! Want to help spread the word? Share this flyer with your colleagues and students: https://t.co/9pehpNFl04\n\nLearn more about abstract submissions: https://t.co/AJBD4A3bxl https://t.co/BzRCdRtlRp",
                "urls" : [
                  "https://t.co/9pehpNFl04",
                  "https://t.co/AJBD4A3bxl"
                ],
                "mediaUrls" : [
                  "https://t.co/BzRCdRtlRp"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ISOQOL",
                "screenName" : "@ISOQOL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-14 22:50:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1775879391723020483",
                "tweetText" : "#Alphabet (#Google) is considering charging for an #AI-assisted search tier as the stock jumped in pre-market #trading.\n\nGet the latest news on your favourite #stocks and #crypto with Delta's Why is it Moving and out-of-hours trade data, so you never miss a move! https://t.co/66xQoDW6bf",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/66xQoDW6bf"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Delta Investment Tracker",
                "screenName" : "@getdelta"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Delta Investment Tracker IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Delta Investment Tracker ANDROID All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Delta Investment Tracker ANDROID 30 Day"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-14 22:47:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1777947625259430344",
                "tweetText" : "Fussballschule Fussballcamp ab 449,- EUR für Kinder mit Übernachtung und Erwerb des Technikabzeichens bei Belrin in Brandenburg",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-14 22:46:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1771223816569778325",
                "tweetText" : "Overcome scientific jargon with simple explanations.\n\nSummarize long sections of texts instantly.\n\nAsk any question and get citation-backed answers.\n\nIt's time you start reading research papers with SciSpace.\n\nFollow us to learn more. https://t.co/FbAnjwAbIE",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/FbAnjwAbIE"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SciSpace",
                "screenName" : "@scispace_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2024-04-14 22:47:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "ProfileTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1777397244951474683",
                "tweetText" : "Follow these accounts to level up:\n\nSports: @WOLF_Sportz\nFinance: @WOLF_Financial\nSuccess: @SelfTSuccess\nBusiness: @GavBlaxberg\nSystems: @CharlieMark_\nWisdom: @WiseWisdomWins\nPodcasts: @WOLF_Podcasts",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "WOLF",
                "screenName" : "@WOLF_Financial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-14 23:11:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "SearchTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1767943451180761284",
                "tweetText" : "Spare 300 € auf Babbel Lifetime! Sprich an jedem Tag der Woche eine andere Sprache. 🧡 Erhalte unbegrenzt Zugang zu allen 14 Sprachen mit Babbel Lifetime.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-14 23:11:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1775106399695200416",
                "tweetText" : "If you want to MASTER chatGPT; Learn prompt engineering.\n\nHere are 5 prompt frameworks that will help you UNLOCK the full potential of chatGPT:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zain Kahn",
                "screenName" : "@heykahn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-04-16 05:58:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771069593920151649",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-16 05:56:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1778467229350211955",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-16 05:57:03"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778175147616190760",
                "tweetText" : "https://t.co/CnFH5e5QLV",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/CnFH5e5QLV"
                ]
              },
              "publisherInfo" : {
                "publisherName" : "DAZN DE",
                "screenName" : "@DAZN_DE"
              },
              "advertiserInfo" : {
                "advertiserName" : "bet365 DE",
                "screenName" : "@bet365DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-16 16:33:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419385143752",
                "tweetText" : "⚡ Free Guide for ML Teams: How to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-16 16:33:20"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780200165598544248",
                "tweetText" : "Getting ready to embark on your next adventure? Don’t forget your trusty companion — Saily eSIM app. Get a flexible data plan anywhere you go and stay connected no matter what!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saily",
                "screenName" : "@sailyworld"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "All Visitors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Device models",
                  "targetingValue" : "iPhone 11 Pro"
                }
              ],
              "impressionTime" : "2024-04-16 16:34:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-16 16:33:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Maktaba beltoon",
                "screenName" : "@beltoon_ar"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Arabic"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-04-16 16:33:38"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-17 08:30:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1780496933532127280",
                "tweetText" : "Even of there is rise of radicals the EU will not divert from enlargement\n#EuStrategicAgenda 🇪🇺\n🎧 New episode of the @VisegradInsight Podcast with @MSimeonova11 @ecfr @ECFRWiderEurope\n👇\n https://t.co/Zwd1OHh3m4\nRecorded yesterday at #EuropeFutureForum in Warsaw 🫶🇵🇱\n@PolandMFA",
                "urls" : [
                  "https://t.co/Zwd1OHh3m4"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wojciech Przybylski",
                "screenName" : "@wprzybylski"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-17 08:28:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747898084632437242",
                "tweetText" : "In unserer HOME COLLECTION findest du noch mehr Wohnaccessoires, die du lieben wirst\nKostenloser Versand auf deine 1. Bestellung",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SHEIN",
                "screenName" : "@SHEIN_Official"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install SHEIN - Shopping Online IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                }
              ],
              "impressionTime" : "2024-04-17 08:30:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-17 08:30:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770023900807655816",
                "tweetText" : "Sollen illegale Einwanderer Sozialleistungen erhalten dürfen? Nehmen Sie an unserer Abstimmung teil!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Epoch Times Deutsch",
                "screenName" : "@EpochTimesDE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "List"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-17 08:30:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780476787098853692",
                "tweetText" : "The only ChatGPT prompting sheet you'll ever need.\n\nSave 100s of hours &amp; get more done.\n\nSign up to Superhuman AI &amp; get more AI resources like this for free.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zain Kahn",
                "screenName" : "@heykahn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-04-17 08:30:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778175147616190760",
                "tweetText" : "https://t.co/CnFH5e5QLV",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/CnFH5e5QLV"
                ]
              },
              "publisherInfo" : {
                "publisherName" : "DAZN DE",
                "screenName" : "@DAZN_DE"
              },
              "advertiserInfo" : {
                "advertiserName" : "bet365 DE",
                "screenName" : "@bet365DE"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "German"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-17 08:27:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771069593920151649",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-17 08:27:37"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763988390482194488",
                "tweetText" : "Join 500,000+ readers and learn how to make AI work for you in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 09:35:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780476787103093183",
                "tweetText" : "If you want to MASTER chatGPT; Learn prompt engineering.\n\nHere are 5 prompt frameworks that will help you UNLOCK the full potential of chatGPT:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zain Kahn",
                "screenName" : "@heykahn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-04-23 09:35:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771758022903349500",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-23 09:36:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782463376758579421",
                "tweetText" : "⚡ Learn how some of the world's most 🚀 sophisticated ML teams are using W&amp;B Launch to 📊 improve GPU utilization.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-23 09:36:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276571950571921",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-23 09:36:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763988390482194488",
                "tweetText" : "Join 500,000+ readers and learn how to make AI work for you in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 09:02:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780520323479490968",
                "tweetText" : "Ja, richtig gehört – wir schenken dir 6 Extramonate gratis, wenn du jetzt ein 6-Monatsabo abschließt!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 09:35:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780520323479490968",
                "tweetText" : "Ja, richtig gehört – wir schenken dir 6 Extramonate gratis, wenn du jetzt ein 6-Monatsabo abschließt!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-23 08:19:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780476787103093183",
                "tweetText" : "If you want to MASTER chatGPT; Learn prompt engineering.\n\nHere are 5 prompt frameworks that will help you UNLOCK the full potential of chatGPT:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zain Kahn",
                "screenName" : "@heykahn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-04-23 08:18:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782462118375325766",
                "tweetText" : "⚡ Read the practical guide to LLM fine-tuning types (RLHF, DPO, etc.) and prompting, plus how to choose between them for different scenarios.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-23 08:17:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771758022903349500",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 08:19:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780626452444045659",
                "tweetText" : "Mach alle Finanzen mit Revolut zu einem Kinderspiel. Lade die App noch heute herunter.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-23 08:22:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-23 08:20:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763988390482194488",
                "tweetText" : "Join 500,000+ readers and learn how to make AI work for you in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 08:18:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 08:18:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-23 08:19:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763988390482194488",
                "tweetText" : "Join 500,000+ readers and learn how to make AI work for you in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 08:20:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-23 21:54:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 21:55:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780476787103093183",
                "tweetText" : "If you want to MASTER chatGPT; Learn prompt engineering.\n\nHere are 5 prompt frameworks that will help you UNLOCK the full potential of chatGPT:",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zain Kahn",
                "screenName" : "@heykahn"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 21:54:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780520323479490968",
                "tweetText" : "Ja, richtig gehört – wir schenken dir 6 Extramonate gratis, wenn du jetzt ein 6-Monatsabo abschließt!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 21:54:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771758022903349500",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-23 23:31:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-23 23:31:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603709351620995",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-23 23:32:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781867198241268082",
                "tweetText" : "If you're not learning AI in 2024, you're falling behind.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-23 23:32:32"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-23 08:59:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "ts1apartment",
                "screenName" : "@t1apartments"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-23 08:59:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 08:56:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 08:57:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-23 08:56:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "ts1apartment",
                "screenName" : "@t1apartments"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 08:58:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 08:54:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "High On Art and Coffee",
                "screenName" : "@highonartandcfe"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-23 08:59:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571600084533541",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-03-23 08:59:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765649021958488118",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 09:02:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "breezypinescabin",
                "screenName" : "@breezypine9"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 09:02:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254813106950615",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-23 09:02:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254339435819357",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-23 09:00:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763519551843779006",
                "tweetText" : "🚴‍♂️Jeder kann problemlos ein E-Bike fahren. \nDie Tretunterstützung hilft Ihnen, Ihr Ziel in bester Stimmung zu erreichen, ohne sich Gedanken über das Gelände machen zu müssen. Außerdem schont es die Gelenke beim Training. \nJetzt bestellen 👉 https://t.co/AzNtalyE3U",
                "urls" : [
                  "https://t.co/AzNtalyE3U"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Buybestgear",
                "screenName" : "@buybestgear"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Outdoors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 09:01:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 09:00:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254813106950615",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-23 11:37:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599702802660",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-03-23 11:36:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603554460098765",
                "tweetText" : "Intelligenter Ausgeben, Versenden und Sparen? Probiere Revolut. Registriere dich und verwalte deine Finanzen wie ein Profi 💪",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 11:37:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-23 11:37:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599702802660",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 11:58:56"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-24 22:49:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:52:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782060742809993226",
                "tweetText" : "RT @Make_orgDE: Schließe dich dem Kampf gegen Fakes an! Bürgerinnen und Bürger haben Ideen gegen Desinformation entwickelt. Jetzt bist du g…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:51:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1774119055328448984",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:50:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1774118324408131721",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:50:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419385143752",
                "tweetText" : "⚡ Free Guide for ML Teams: How to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:52:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782462118387908772",
                "tweetText" : "⚡ Read the practical guide to LLM fine-tuning types (RLHF, DPO, etc.) and prompting, plus how to choose between them for different scenarios.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-24 22:51:02"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780520323479490968",
                "tweetText" : "Ja, richtig gehört – wir schenken dir 6 Extramonate gratis, wenn du jetzt ein 6-Monatsabo abschließt!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-26 00:20:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1783508010737807761",
                "tweetText" : "Muttertag ist die Zeit, beschenkt zu werden – aber auch die Zeit, sich selbst etwas Gutes zu tun: Profitieren Sie zu Ihrem Ehrentag, sichern Sie sich Ihr NZZ-Probeabo für nur 1 Euro und geniessen Sie alle Vorteile, die hochklassiger Journalismus bietet.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Neue Zürcher Zeitung Deutschland",
                "screenName" : "@NZZde"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-26 00:22:35"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771758022903349500",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-29 11:41:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771069593920151649",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Easy, fun, and super addictive🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-29 11:40:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1731366687721558061",
                "tweetText" : "\"A french girl with brown hair wearing a red leotard\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-29 11:41:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1781288266651607251",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-29 11:39:54"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1784516612684755033",
                "tweetText" : "🌟 Hewoo Steam boys \n🌟 Wanna be the Ruler of the Birdmen? \n🐦 Check out this game! \n🌳 Free Playtest on Steam now! 🚀💖\n🎮 Guardians of the Sanctree \n\nSteam page 👇\nhttps://t.co/17jWZwUS8i",
                "urls" : [
                  "https://t.co/17jWZwUS8i"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Guardians of the Sanctree-Play Demo Now!",
                "screenName" : "@Sanctree"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming news"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming news"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-29 20:06:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1778456158874849763",
                "tweetText" : "🚀 Transform your Shopify store's customer experience with Skyla! Boost engagement, increase sales, and enjoy a seamless integration. Try it now and see the difference! 💡✨ Visit https://t.co/3nDM826jwu #Shopify #eCommerce #AI #chatGPT",
                "urls" : [
                  "https://t.co/3nDM826jwu"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Skyla Chat",
                "screenName" : "@skylachat"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-29 20:01:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777949805911605761",
                "tweetText" : "Englischcamp für Kinder bei Berlin in Brandenburg ab 469,- EUR mit 6 Übernachtungen, prof. Englischunterricht und englischsprachigen Freizeitprogramm",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-29 20:04:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419385143752",
                "tweetText" : "⚡ Free Guide for ML Teams: How to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-29 20:04:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1784533265895850040",
                "tweetText" : "🚀 Embark on an Epic Adventure!  \n🌐 Discover the hidden wonders of the underground and forge a grand birdmen empire in Guardians of the Sanctree!  \n🐦 Watch our new trailer and experience the free playtest on Steam now!✨\n\nSteam page 👇\nhttps://t.co/17jWZwUS8i",
                "urls" : [
                  "https://t.co/17jWZwUS8i"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Guardians of the Sanctree-Play Demo Now!",
                "screenName" : "@Sanctree"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming news"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PC gaming"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Gaming news"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-29 20:07:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1731365680966967564",
                "tweetText" : "\"A french girl with brown hair wearing a red leotard\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-29 20:06:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1763988390482194488",
                "tweetText" : "Join 500,000+ readers and learn how to make AI work for you in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-29 20:04:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1780015763790651576",
                "tweetText" : "The world can savor the authentic taste of Saudi dates! 🌴✨ #TasteOfArabia #SaudiDates https://t.co/xBoYCvklPT",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/xBoYCvklPT"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "المركز الوطني للنخيل والتمور",
                "screenName" : "@NCPD_SA"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-04-29 20:05:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1774118324408131721",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Community notes - United States"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login Last War:Survival IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion: Community note users - United States - 02-2024"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-29 20:04:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276571950571921",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-04-29 20:05:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-04-29 20:03:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780520323412361541",
                "tweetText" : "Wir sind uns so sicher, dass du in 12 Monaten große Fortschritte machst, dass wir dir anbieten, nur die Hälfte zu zahlen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-29 20:04:51"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785072856641999245",
                "tweetText" : "Bring neuen Nervenkitzel und neue Taktiken auf deine Reisen mit der waghalsigen Auswahl an Waffen und Werkzeugen in Sea of Thieves Season 12, die du ab dem 30. April einsetzen kannst!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 36220695"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-30 23:43:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1749411836791791962",
                "tweetText" : "Discover the hidden power of your iPhone &amp; Apple Watch! Analyze heart rate, stress, sleep, log BP &amp; increase productivity with next-level analytics! Safe &amp; secure.\nBonus: Sync seamlessly with 140 apps!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Welltory. The Wellness Laboratory",
                "screenName" : "@welltory"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 16.2 and above"
                },
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-30 23:45:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782657891381481966",
                "tweetText" : "Scannen Sie beliebige Dokumente, konvertieren Sie Bilder in Text, PDF-Dateien usw.👍",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Mobile Scanner",
                "screenName" : "@scanner_mobile"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-30 23:45:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782462873551229366",
                "tweetText" : "⚡ Read the practical guide to making 🔥 Machine Learning (MLOps) 💪 work for you.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-04-30 23:43:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785288586012573939",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Excusion: Bot/negative engagers - Global - 04-2024"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-04-30 23:45:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1784970093698617752",
                "tweetText" : "Escape the stress💨 💨 💨  \n\nUnlock a world of relaxation with game - your ultimate stress-reliever!🌟😌\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-04-30 23:43:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1673740222369239040",
                "tweetText" : "Echte Nerds tanzen Funktionen statt Namen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "getDigital Team",
                "screenName" : "@getDigital_de"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-04-30 23:45:53"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1786119299779711352",
                "tweetText" : "🚨Block Magic, a Chainlink hackathon, is open for registration 🚨\n\n• Compete for $500K+ in prizes\n• Attend expert-run workshops\n• Connect with the best in blockchain\n\nSign up to build the next generation of dApps👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Chainlink",
                "screenName" : "@chainlink"
              },
              "impressionTime" : "2024-05-04 02:26:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785202428528218532",
                "tweetText" : "AI won't replace you, but a person using AI will.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 02:27:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782745737299628237",
                "tweetText" : "تعلن #جامعة_رياض_العلم \nعن بدء القبول في برامج البكالوريوس لجميع التخصصات في الفصل الدراسي الأول للعام 1445 - 2024\n\nللتسجيل والمزيد من المعلومات يرجى زيارة موقعنا الإلكتروني \nhttps://t.co/BcSt6ONAtR\nاو التواصل على الرقم 0112100000 https://t.co/GEvd28ef5u",
                "urls" : [
                  "https://t.co/BcSt6ONAtR"
                ],
                "mediaUrls" : [
                  "https://t.co/GEvd28ef5u"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "جامعة رياض العلم",
                "screenName" : "@RiyadhElmU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-04 02:26:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785072856641999245",
                "tweetText" : "Bring neuen Nervenkitzel und neue Taktiken auf deine Reisen mit der waghalsigen Auswahl an Waffen und Werkzeugen in Sea of Thieves Season 12, die du ab dem 30. April einsetzen kannst!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 36220695"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-05-04 02:17:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1755170164021121254",
                "tweetText" : "The game is on!🎟EVs are taking on supercars and giving them a run for their money! The secret? Battery pack innovations! Check out the video to see how #CATL's CTP (Cell-to-Pack) 3.0 technology brings you a lighter and faster EV that challenges supercars for the ultimate thrill! https://t.co/BE1cBhC9SK",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/BE1cBhC9SK"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "CATL",
                "screenName" : "@catl_official"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 07:52:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Vqpxb",
                "screenName" : "@VqpxbUS"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 07:52:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785072856641999245",
                "tweetText" : "Bring neuen Nervenkitzel und neue Taktiken auf deine Reisen mit der waghalsigen Auswahl an Waffen und Werkzeugen in Sea of Thieves Season 12, die du ab dem 30. April einsetzen kannst!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 36220695"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-05-04 07:51:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-04 07:51:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1785288585970696300",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Excusion: Bot/negative engagers - Global - 04-2024"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 07:53:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1786404636645024065",
                "tweetText" : "Exclusive: Dive into the Future with Northrop Grumman's Game-Changing Underwater Drone, The Manta Ray!\n\nIn this video, we’re taking a closer look at Northrop Grumman’s latest advancement in uncrewed underwater vehicles, providing an initial glimpse into the capabilities and… https://t.co/6NtxGA3PmR",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/6NtxGA3PmR"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Defence Central",
                "screenName" : "@Defence_Central"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 07:57:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1774118324408131721",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-05-04 08:00:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1782439217647260094",
                "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "rieker_official",
                "screenName" : "@riekerofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "NBA basketball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sports"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-04 08:04:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1752636087204536723",
                "tweetText" : "\"A young woman with crimson hair standing outside\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-04 08:01:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "MediaViewer",
              "promotedTweetInfo" : {
                "tweetId" : "1780958768328749210",
                "tweetText" : "\"Die fühlen sich einfach anders an\" \n\nCesc Fabregas ist mit dabei und erklärt euch, wie Enterprise-Rent-A-Car die Fans auf ihren alltäglichen Missionen und bei dem Engagement, das sie an den Donnerstagabenden zeigen, unterstützt.\n\n#AllRoadsLeadToThursday",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "GOAL Deutschland",
                "screenName" : "@GoalDeutschland"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-04 08:03:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771223816569778325",
                "tweetText" : "Overcome scientific jargon with simple explanations.\n\nSummarize long sections of texts instantly.\n\nAsk any question and get citation-backed answers.\n\nIt's time you start reading research papers with SciSpace.\n\nFollow us to learn more. https://t.co/FbAnjwAbIE",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/FbAnjwAbIE"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "SciSpace",
                "screenName" : "@scispace_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                }
              ],
              "impressionTime" : "2024-05-05 10:39:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785704006666657930",
                "tweetText" : "Did you know 61% of respondents in our 2024 AI Readiness Report cite infrastructure and tooling challenges as pain points? Learn how to optimize your generative AI deployments by downloading your free copy of the report today.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Scale AI",
                "screenName" : "@scale_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HelloSurgeAI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-05 10:34:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1679145345584885760",
                "tweetText" : "Die letzte medizinische Erfindung für einen gesunden Bauch",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "ProCombo - probiotic + prebiotic",
                "screenName" : "@ProCombo_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-05 10:36:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785202429862039628",
                "tweetText" : "If you're not learning AI in 2024, you're falling behind.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:31:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785288585941299590",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Excusion: Bot/negative engagers - Global - 04-2024"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-05 10:37:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1784960839604400315",
                "tweetText" : "💕 Happy Mother's Day!\n\nShower Mom with Love and Savings.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "BT21",
                "screenName" : "@BT21_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-05-05 10:37:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781087343182778842",
                "tweetText" : "Come dress me on IMVU 💋",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IMVU",
                "screenName" : "@IMVU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion audience: followers IMVU - Global - 04-2024"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: Social Chat & Avatar app ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "11.22>7.23 Exclusion List"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Sign up IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:33:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-05 10:32:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1774118324408131721",
                "tweetText" : "Escape the stress💨 💨 💨  \nPlay our fun and easy game now. Simple, fun, and a great way to kill time🥰\n\n#lastwar #game #strategy",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Last War: Survival Game",
                "screenName" : "@lastwarsurvival"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation 5"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "PlayStation"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:31:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768525994019721598",
                "tweetText" : "Discover the hidden power of your iPhone &amp; Apple Watch! Analyze heart rate, stress, sleep, log BP &amp; increase productivity with next-level analytics! Safe &amp; secure.\nBonus: Sync seamlessly with 140 apps!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Welltory. The Wellness Laboratory",
                "screenName" : "@welltory"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Unknown",
                  "targetingValue" : "Unknown: 1"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 16.2 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-05 10:35:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1786401273547231352",
                "tweetText" : "We built the first self-custodial VISA Card.\n\nYou can now spend your crypto in the real world. \n\nAnd we can't wait to see you try it.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Gnosis Pay 🦉💳",
                "screenName" : "@gnosispay"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-05 10:37:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782763110006136990",
                "tweetText" : "👉 Think you’re more intelligent than the average? Put your mind into challenge with our certified IQ Test and see how intelligent you really are!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IQ Institute",
                "screenName" : "@iqinstituteok"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:36:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1731366687616999467",
                "tweetText" : "\"A smiling young woman with blonde hair in a bun standing outside\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-05 10:40:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747956520149791176",
                "tweetText" : "Create videos within ChatGPT 🪄 \nTry our VideoMaker on the GPT Store &gt;&gt;\n\nChatGPT Plus required ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "invideo",
                "screenName" : "@invideoOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@openai"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:34:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782060739001499758",
                "tweetText" : "RT @Make_orgDE: Schließe dich dem Kampf gegen Fakes an! Bürgerinnen und Bürger haben Ideen gegen Desinformation entwickelt. Jetzt bist du g…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:32:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785072858785329465",
                "tweetText" : "Bring neuen Nervenkitzel und neue Taktiken auf deine Reisen mit der waghalsigen Auswahl an Waffen und Werkzeugen in Sea of Thieves Season 12, die du ab dem 30. April einsetzen kannst!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sea of Thieves",
                "screenName" : "@SeaOfThieves"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 36220695"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-05-05 10:31:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-05 10:31:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1656581914784825344",
                "tweetText" : "Take your #PDF processing to the next level with Aspose.PDF for C++ API! #Generate, #manipulate, and #optimize PDF documents with ease using advanced features like annotations, bookmarks, and more. Boost your productivity and streamline your workflow today. \n\n#AsposePDF #CPP",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Aspose",
                "screenName" : "@aspose"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AskYourPdf"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "All Visitors"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:38:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-05-05 10:36:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1773419256509534350",
                "tweetText" : "Wondering about the best GPUs for training and inference? Get insights on NVIDIA®'s V100, A100, and H100 GPUs. \nFill out the form to access our review.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Nebius",
                "screenName" : "@nebiusofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-05 10:37:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785591586388115531",
                "tweetText" : "https://t.co/Z748hSRzsZ provides news and exclusive content for competitive gaming. Start your journey into the world of esports! https://t.co/iqv8MTV3wo",
                "urls" : [
                  "https://t.co/Z748hSRzsZ"
                ],
                "mediaUrls" : [
                  "https://t.co/iqv8MTV3wo"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fragster.com",
                "screenName" : "@FragsterEN"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:38:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1784937932220178844",
                "tweetText" : "🎉Countdown is On: Reserve Your Spot at Crypto Expo Dubai 2024 Today - Limited Tickets Remaining!🎉\n\nDon't Miss Out! Biggest Savings of the Year : Last Chance to Grab 20% Extra Discounts on Crypto Expo Dubai 2024 Tickets!\n\n#CryptoExpoDubai #BullRun #EarnMoney\"",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Crypto Expo",
                "screenName" : "@TheCryptoExpo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-05 10:34:31"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785051804944015754",
                "tweetText" : "New Clarius HD3 wireless ultrasound for medical professionals! Discover high-definition imaging you can trust for your specialty. Manage your exams anywhere and improve patient outcomes with clear, real-time imaging that is easy to use, affordable, and ultra-portable.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Clarius",
                "screenName" : "@clariusmhealth"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-11 21:52:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788496389124550737",
                "tweetText" : "🟢The European Commission has launched a TV magazine in cooperation with Euronews. The programme explores how various aspects of the European Green Deal are taking shape on the ground.\nhttps://t.co/I9NU5yx5r6",
                "urls" : [
                  "https://t.co/I9NU5yx5r6"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fit for 55 - Explained",
                "screenName" : "@fitfor55info"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-05-11 21:51:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762290802372571539",
                "tweetText" : "Dancing with the fam on IMVU&lt;3",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "IMVU",
                "screenName" : "@IMVU"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion audience: followers IMVU - Global - 04-2024"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: Social Chat & Avatar app ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "11.22>7.23 Exclusion List"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS 30 Day"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Login IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "App open IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Sign up IMVU: 3D Avatar Creator & Chat IOS All"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-11 21:52:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785704006339510703",
                "tweetText" : "Get insights from over 1,800 AI/ML executives and practitioners on the latest trends, challenges, and best practices in building, applying, and evaluating generative AI in our 2024 AI Readiness Report.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Scale AI",
                "screenName" : "@scale_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HelloSurgeAI"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-11 21:52:22"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1766372849240191059",
                "tweetText" : "It's so cool, a different phone case, it's protecting the life of my phone, no one knows when the accident will come, let the phone wear armor\nGRAB YOURS👉https://t.co/MYs8Aa7bkd https://t.co/4XrvKuE6Y8",
                "urls" : [
                  "https://t.co/MYs8Aa7bkd"
                ],
                "mediaUrls" : [
                  "https://t.co/4XrvKuE6Y8"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bracay_store",
                "screenName" : "@Bracay_store"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-13 04:39:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1784510910817603585",
                "tweetText" : "😎This New Design Aluminum Magnesium Men Polarized Sunglasses is so cool🕶\nGET YOURS NOW👉https://t.co/hVX8y2fNai https://t.co/mlsJSdQVSH",
                "urls" : [
                  "https://t.co/hVX8y2fNai"
                ],
                "mediaUrls" : [
                  "https://t.co/mlsJSdQVSH"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lazzaco",
                "screenName" : "@Lazza_Homelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-13 04:39:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829111439966252",
                "tweetText" : "Erstaunlich oft tauchen Jugendliche ab. Schuld ist eine paradoxe Mischung aus Hybris und Selbstzweifeln. Aber wo sind sie – und wie holen wir sie zurück?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-13 04:40:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788863936084738149",
                "tweetText" : "Explore Flo's articles to improve your health knowledge, love life, and communication.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo App",
                "screenName" : "@flotracker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-05-13 04:38:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780514783361409301",
                "tweetText" : "For a trip that lasts a week, you don’t need a monthly data plan, right? With Saily, you can pick a weekly eSIM service option that best fits your travel needs. And it only takes a couple of clicks!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saily",
                "screenName" : "@sailyworld"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Saily Purchasers"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Device models",
                  "targetingValue" : "iPhone 11 Pro"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-13 04:40:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-13 09:47:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788488678001594813",
                "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-05-13 09:46:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1747956520363638870",
                "tweetText" : "Create videos within ChatGPT 🪄 \nTry our VideoMaker on the GPT Store &gt;&gt;\n\nChatGPT Plus required ✨",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "invideo",
                "screenName" : "@invideoOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt plus"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "chatgpt"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "custom gpt"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "@openai"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-13 09:48:14"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780199828619735088",
                "tweetText" : "Getting a local SIM card at the airport will either cost you an arm and a leg or be next to impossible to do. Avoid scammers, queues, and complicated instructions in foreign languages — get an eSIM!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saily",
                "screenName" : "@sailyworld"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List",
                  "targetingValue" : "Saily Purchasers"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "All Visitors"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Device models",
                  "targetingValue" : "iPhone 11 Pro"
                }
              ],
              "impressionTime" : "2024-05-13 09:48:27"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790028230910464153",
                "tweetText" : "⏰ Last chance to get your early adopter ticket for #Web3Summit 2024!⏰\nJoin us in Berlin, August 19-21 to explore the forefront of decentralization. \n\n 🎫💻  https://t.co/cLKqb6TaLM \n#Web3Summit #DecentralizedWorld #Blockchain",
                "urls" : [
                  "https://t.co/cLKqb6TaLM"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Web3 Summit 2024",
                "screenName" : "@Web3summit"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                }
              ],
              "impressionTime" : "2024-05-14 16:14:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790031575041663333",
                "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kettner Edelmetalle",
                "screenName" : "@KettnerGold"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-14 16:11:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1787902717823959448",
                "tweetText" : "🏆 1KOMMA5° ist Testsieger im Photovoltaik-Vergleichstest 2024 von EFAHRER aus 13 Solaranbietern!\n\n✅ Solaranlage + Stromspeicher vom Testsieger\n\n✅ Inklusive Planung, Installation und Zählerwechsel\n\nNur bei 1KOMMA5°. \nJetzt kostenlos und unverbindlich beraten lassen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "1KOMMA5GRAD",
                "screenName" : "@1KOMMA5GRAD"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-14 16:11:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790079566645428587",
                "tweetText" : "Befehlige deine Flotte von galaktischen Kriegsschiffen, während du nach Antworten auf ein galaktisches Geheimnis suchst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Homeworld",
                "screenName" : "@HomeworldGame"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:10:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780881556124450884",
                "tweetText" : "Slash your Web3 infra costs with Moralis! We’re now launching Moralis Nodes, adding high-performance RPC nodes to our suite of world-class data APIs. Sign up now to take advantage of our exclusive nodes launch discount! Only available for the first 250 signups!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Moralis | Crypto Data APIs",
                "screenName" : "@MoralisWeb3"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Web3"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:14:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781276559313154364",
                "tweetText" : "Feiern Sie mit uns 75 Jahre Qualitäts­journalismus und lesen Sie FAZ+ 7 Monate für nur 5 €.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-14 16:15:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1781867198287688055",
                "tweetText" : "AI won't replace you, but a person using AI will.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Rundown AI",
                "screenName" : "@TheRundownAI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aisolopreneur"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@character_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@OfficialLoganK"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@labenz"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@MeetGamma"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@elevenlabsio"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WonderDynamics"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dr_cintas"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@youneedarobot"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hasantoxr"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nonmayorpete"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@itsPaulAi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@perplexity_ai"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LeonardoAi_"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Dec.20 Full Email Sub List"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:11:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1786885263664599222",
                "tweetText" : "Verdienen Sie mit Staking bis zu 10% Krypto-Rewards auf Coinbase. Jetzt Loslegen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Coinbase 🛡️",
                "screenName" : "@coinbase"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-14 16:13:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1781312606008918343",
                "tweetText" : "Leistungsstarke Formel mit 20 % Vitamin C für eine strahlende und makellose Haut!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "The Ceel",
                "screenName" : "@theceel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-05-14 16:14:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782462873551229366",
                "tweetText" : "⚡ Read the practical guide to making 🔥 Machine Learning (MLOps) 💪 work for you.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:11:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1790311504002085188",
                "tweetText" : "Es ist Zeit für das nächste große Ding: Am 16.05.2024 ist es so weit! \n\nDiesmal ist unser Ziel größer als je zuvor. Unsere heutige Mission: Dem Irrsinn in Deutschland und der Welt ein Ende zu bereiten! https://t.co/vrpzbp9NO5",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/vrpzbp9NO5"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Alex Fischer",
                "screenName" : "@Alex_Fischer_D"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:12:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1780200165598544248",
                "tweetText" : "Getting ready to embark on your next adventure? Don’t forget your trusty companion — Saily eSIM app. Get a flexible data plan anywhere you go and stay connected no matter what!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saily",
                "screenName" : "@sailyworld"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "List",
                  "targetingValue" : "Saily Purchasers"
                },
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "All Visitors"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Device models",
                  "targetingValue" : "iPhone 11 Pro"
                }
              ],
              "impressionTime" : "2024-05-14 16:12:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785051804944015754",
                "tweetText" : "New Clarius HD3 wireless ultrasound for medical professionals! Discover high-definition imaging you can trust for your specialty. Manage your exams anywhere and improve patient outcomes with clear, real-time imaging that is easy to use, affordable, and ultra-portable.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Clarius",
                "screenName" : "@clariusmhealth"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 16:12:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785704006490403144",
                "tweetText" : "Download our free AI Readiness Report to uncover critical insights, including how 71% of respondents are planning to increase investments in commercial closed-source models over the next three years.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Scale AI",
                "screenName" : "@scale_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HelloSurgeAI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-14 16:15:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788864764497502316",
                "tweetText" : "Explore Flo's articles to improve your health knowledge, love life, and communication.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo App",
                "screenName" : "@flotracker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-05-14 18:40:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788864764497502316",
                "tweetText" : "Explore Flo's articles to improve your health knowledge, love life, and communication.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo App",
                "screenName" : "@flotracker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-14 12:06:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790277266208964857",
                "tweetText" : "Test: Sind diese bekannten Reizdarm-Produkte ihr Geld wert? Unsere Experten haben 5 beliebte Präparate auf Herz und Nieren getestet! \nWelchem Hersteller man wirklich vertrauen kann und welche Fehler viele Reizdarm-Betroffene machen, erfahren Sie hier.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Gesundheits Vergleich",
                "screenName" : "@GesundheitsVgl"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-14 12:04:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320870703467",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 23:44:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 23:42:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-03-23 23:43:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1765647718620524860",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 15:31:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770723268611416488",
                "tweetText" : "#Greece is being pressured from two sides: new emerging #migration routes and legally inept assistance.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FactRefuge",
                "screenName" : "@FactRefuge"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political News"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political issues"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Politics"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-03-23 15:30:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 15:24:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1677319433558151168",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-03-23 15:29:05"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-23 15:28:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599337935192",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 15:28:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254339435819357",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 15:29:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603063760158907",
                "tweetText" : "Intelligenter Ausgeben, Versenden und Sparen? Probiere Revolut. Registriere dich und verwalte deine Finanzen wie ein Profi 💪",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-03-23 15:26:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 15:23:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "breezypinescabin",
                "screenName" : "@breezypine9"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 15:25:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829110844276946",
                "tweetText" : "Wie viel Geld ist wohl genug? Das ist wie vieles relativ. Meist ist materieller Erfolg ohnehin purer Zufall. Hinter Finanzfragen verbergen sich oft genug andere Schwierigkeiten.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:04:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-23 12:06:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "breezypinescabin",
                "screenName" : "@breezypine9"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:05:23"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768255759530500433",
                "tweetText" : "Spare 300 € auf Babbel Lifetime! Sprich an jedem Tag der Woche eine andere Sprache. 🧡 Erhalte unbegrenzt Zugang zu allen 14 Sprachen mit Babbel Lifetime.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:03:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1760283259785580981",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:03:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770019884522479829",
                "tweetText" : "The connection between the #Heart and #Kidney is sometimes overlooked but it's extremely special. Without one, the other cannot efficiently function.\n\nSo, when thinking about #HeartHealth, it’s important to reflect on the kidneys at the same time.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kidney Disease Forum",
                "screenName" : "@KidneyDiseaseFm"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:07:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599702802660",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-23 12:10:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768603944169705527",
                "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 12:04:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767253137562239192",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:03:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829113105064040",
                "tweetText" : "In manchen Beziehungen kommt es regelmäßig zu Streit, der sich auch an ganz banalen Alltagsgesprächen entzünden kann. Das kann daran liegen, dass einer der Partner eine große unbewusste Wut mit sich herumträgt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-23 12:06:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771221215299981479",
                "tweetText" : "Entfliehen Sie mit Ihrem Liebsten ins Paradies! \n\nBuchen Sie jetzt einen romantischen Urlaub und schaffen Sie unvergessliche Momente mit unseren First-Minute-Angeboten. \n\nGreifen Sie jetzt zu! #Kroatien",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "bluesunhotels",
                "screenName" : "@bluesunhotels"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel Actions"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 12:07:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765646820351602796",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:04:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1771150518192140336",
                "tweetText" : "Smartphones have become indispensable companions in our daily lives",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Patrick Walker",
                "screenName" : "@ParWalker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-23 12:05:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1771219300130394355",
                "tweetText" : "Nehmen Sie Ihre Kinder mit auf einen Urlaub, den sie für immer in Erinnerung behalten werden! \n\nBuchen Sie jetzt und sparen Sie mit First-Minute-Rabatten. \n\nNur für begrenzte Zeit! \n\n#Familienurlaub",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "bluesunhotels",
                "screenName" : "@bluesunhotels"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel Actions"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Adventure travel"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Air travel"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 12:05:36"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1732313174198882414",
                "tweetText" : "\"A woman with black hair and a white dress standing in a lake\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-23 12:11:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767558098237956412",
                "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟 https://t.co/7Zpt0vwfGR",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/7Zpt0vwfGR"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "rieker_official",
                "screenName" : "@riekerofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "NBA basketball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Sports"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Skiing"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:08:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "littlecharm",
                "screenName" : "@littlecharmCo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "china"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "support"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "remember"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "car"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "people"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "food"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "beautiful"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "children"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "question"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-23 12:04:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254813106950615",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-23 12:03:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788863771605193035",
                "tweetText" : "Explore Flo's articles to improve your health knowledge, love life, and communication.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo App",
                "screenName" : "@flotracker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-05-16 00:38:18"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Zijov",
                "screenName" : "@Zijovofficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-20 07:58:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788864764497502316",
                "tweetText" : "Explore Flo's articles to improve your health knowledge, love life, and communication.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Flo App",
                "screenName" : "@flotracker"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-20 07:57:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1733293383114768873",
                "tweetText" : "\"A woman with blonde hair dressed in battle armor\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-20 07:59:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777948741669974288",
                "tweetText" : "Angelcamp für Kinder bei Berlin in Brandenburg ab 459,- EUR mit 6 Übernachtungen und Erwerb des Jugendfischereischeines",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-05-20 08:02:04"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1792461003491623422",
                "tweetText" : "Forgot to close #Topheroes\nMy heroes solo level up in my phone\n\n1 hours later - 👶LV5\n5 hours later - 👨‍🎓LV20\n10 hours later - 🧙‍♂️LV99\n\nSuper easy to play, Thrilling to win\n 🤩 ✨ Get started today to receive an exclusive limited-time offer!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Top Heroes",
                "screenName" : "@TopHeroes_"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-24 08:01:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1759203633202151812",
                "tweetText" : "Großartiges Trading erfordert großartige Tools 📈",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "eToro",
                "screenName" : "@eToro"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business news"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Personal finance"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "101_AllRegistrations_4mfqsb"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "110_Depositors_4mfqsb"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-24 08:00:14"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610618831548608",
                "tweetText" : "30 Tage lang 30% Rabatt auf alle Bestellungen mit dem Code HEY30. Jetzt bestellen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-24 06:26:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700333695313",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-24 06:26:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571600084533541",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 06:25:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599337935192",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 06:22:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-24 06:26:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Aarya Claus",
                "screenName" : "@AaryaClaus"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-03-24 06:22:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320887533686",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-24 06:24:43"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571599702802660",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-24 13:39:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1770459907952685253",
                "tweetText" : "Sogar seriöse Leute haben begonnen, es zu benutzen.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bea Attwood",
                "screenName" : "@attwoodPHOTO"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 15.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:00:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-24 13:00:50"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767571598918426990",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Falschinformationen! Über 100.000 Menschen haben sich bisher beim Forum gegen Fakes beteiligt. Was hältst…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Women's History Month"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Motherhood"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:01:37"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-24 13:01:21"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-24 13:02:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "advertiserInfo" : {
                "advertiserName" : "Right_Livin",
                "screenName" : "@right_livin"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:06:10"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254339435819357",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:41:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762847785269788730",
                "tweetText" : "🔥 To get in shape isn’t as hard as it sounds!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UniMeal",
                "screenName" : "@UnimealPlans"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : " Purchase GTM"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:05:03"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768255759530500433",
                "tweetText" : "Spare 300 € auf Babbel Lifetime! Sprich an jedem Tag der Woche eine andere Sprache. 🧡 Erhalte unbegrenzt Zugang zu allen 14 Sprachen mit Babbel Lifetime.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-24 13:41:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1770723268611416488",
                "tweetText" : "#Greece is being pressured from two sides: new emerging #migration routes and legally inept assistance.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FactRefuge",
                "screenName" : "@FactRefuge"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political News"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Political issues"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Politics"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-03-24 13:05:32"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768610320870703467",
                "tweetText" : "Over 2 million users can't be wrong. \nChoose BURGA for unparalleled style and phone protection.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Burga",
                "screenName" : "@BurgaOfficial"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                }
              ],
              "impressionTime" : "2024-03-24 13:03:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767253137562239192",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:03:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1765647951538565455",
                "tweetText" : "Kostenlose 3000 aufeinanderfolgende Ziehungen und 1777 Diamanten",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Legend of Mushroom",
                "screenName" : "@legendofmush"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-24 13:04:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1762848056368632156",
                "tweetText" : "Prägen Sie NFTs wie ein Profi! Umgehen Sie Blockchain-Konfigurationen, Tokens und mühsame Recherchen.🤝\n\n✅Konzentrieren Sie sich auf Kreativität, während wir die technischen Details übernehmen.\n\nBeginnen Sie jetzt mit dem Erstellen👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Apillon ⧓",
                "screenName" : "@Apillon"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2024-03-24 13:05:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1748033637163872506",
                "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-03-24 12:57:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1760658700333695313",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-03-24 12:59:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1767254603639230582",
                "tweetText" : "Gewinne auf Expedia Live mit etwas Glück zwei Tickets fürs Viertelfinale der UEFA Champions League. Dabei sein ist alles. Es gelten die AGB.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "UEFA Champions League",
                "screenName" : "@ChampionsLeague"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                }
              ],
              "impressionTime" : "2024-03-24 17:30:39"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Andreia",
                "screenName" : "@andreiashelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-25 10:27:13"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-25 10:26:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Aarya Claus",
                "screenName" : "@AaryaClaus"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-25 10:27:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1764020167665734054",
                "tweetText" : "Verbessere dein Englisch quickly. ⚡Erhalte 50 % Rabatt und starte noch heute.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Babbel",
                "screenName" : "@babbel"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Website Activity",
                  "targetingValue" : "Purchase"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-25 10:26:20"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "advertiserInfo" : {
                "advertiserName" : "Andreia",
                "screenName" : "@andreiashelife"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-03-25 12:11:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-03-25 12:09:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610756446630052",
                "tweetText" : "Dein Lieblingsessen geliefert. Nutze den Code HEY30 &amp; erhalte 30 Tage lang 30% Rabatt.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-03-25 20:11:39"
            }
          ]
        }
      }
    }
  }
]