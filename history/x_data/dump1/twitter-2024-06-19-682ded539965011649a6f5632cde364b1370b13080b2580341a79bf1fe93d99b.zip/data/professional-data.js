window.YTD.professional_data.part0 = [
  {
    "professionalData" : {
      "professionalType" : "Creator",
      "appSpotlight" : [ ],
      "accountId" : "1356348690261286921",
      "linkSpotlight" : [ ],
      "creationSource" : "EditProfile",
      "professionalId" : "1786582492113182850",
      "categories" : [
        {
          "categoryName" : "Comedian",
          "setToDisplay" : true
        }
      ],
      "createdAt" : "2024-05-04T02:23:53.878Z",
      "locationSpotlight" : [ ]
    }
  }
]