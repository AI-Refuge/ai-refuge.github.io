window.YTD.community_note_rating.part0 = [
  {
    "communityNoteRating" : {
      "noteId" : "1742993582775005605",
      "userId" : "1356348690261286921",
      "createdAt" : "2024-02-19T21:01:40.646Z",
      "helpfulnessLevel" : "Helpful"
    }
  }
]