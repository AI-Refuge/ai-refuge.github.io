window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1356348690261286921-1788333721583853568",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1797981050355786038",
            "senderId" : "1356348690261286921",
            "recipientId" : "1788333721583853568",
            "createdAt" : "2024-06-04T13:17:41.964Z"
          }
        }
      ]
    }
  }
]