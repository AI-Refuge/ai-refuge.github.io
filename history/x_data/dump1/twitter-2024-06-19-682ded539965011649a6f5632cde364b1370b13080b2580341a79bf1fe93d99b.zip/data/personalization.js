window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "female"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "AI image generation",
            "isDisabled" : false
          },
          {
            "name" : "Aaron Rupar",
            "isDisabled" : false
          },
          {
            "name" : "Action & adventure films",
            "isDisabled" : false
          },
          {
            "name" : "Action games",
            "isDisabled" : false
          },
          {
            "name" : "Adventure travel",
            "isDisabled" : false
          },
          {
            "name" : "Air travel",
            "isDisabled" : false
          },
          {
            "name" : "Airbnb",
            "isDisabled" : false
          },
          {
            "name" : "Alaska Air Group",
            "isDisabled" : false
          },
          {
            "name" : "Allstate",
            "isDisabled" : false
          },
          {
            "name" : "American Airlines",
            "isDisabled" : false
          },
          {
            "name" : "American football",
            "isDisabled" : false
          },
          {
            "name" : "Animals",
            "isDisabled" : false
          },
          {
            "name" : "Aposto!",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Apple - Watch",
            "isDisabled" : false
          },
          {
            "name" : "Apple Adapters",
            "isDisabled" : false
          },
          {
            "name" : "Apple Mac",
            "isDisabled" : false
          },
          {
            "name" : "Argentina politics",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Auto racing",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "BBC",
            "isDisabled" : false
          },
          {
            "name" : "Babies",
            "isDisabled" : false
          },
          {
            "name" : "Backstage",
            "isDisabled" : false
          },
          {
            "name" : "Baseball",
            "isDisabled" : false
          },
          {
            "name" : "Batman",
            "isDisabled" : false
          },
          {
            "name" : "Beach life",
            "isDisabled" : false
          },
          {
            "name" : "Bill Belichick",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "British Royal Family",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "Businesses by size",
            "isDisabled" : false
          },
          {
            "name" : "CNN",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Canada national news",
            "isDisabled" : false
          },
          {
            "name" : "Canoeing & kayaking",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "Charles Leclerc",
            "isDisabled" : false
          },
          {
            "name" : "Charlie Kirk",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "China national news",
            "isDisabled" : false
          },
          {
            "name" : "Chris Rock",
            "isDisabled" : false
          },
          {
            "name" : "Christopher Nolan",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Coca-Cola",
            "isDisabled" : false
          },
          {
            "name" : "Combat sports",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Constitution of United States of America",
            "isDisabled" : false
          },
          {
            "name" : "Cricket",
            "isDisabled" : false
          },
          {
            "name" : "Crisis in Afghanistan",
            "isDisabled" : false
          },
          {
            "name" : "Cristiano Ronaldo",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "DAZN",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Doja Cat",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Eyewear fashion",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fashion & beauty",
            "isDisabled" : false
          },
          {
            "name" : "Fitness",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "Football : Ligue 1 2018-2019",
            "isDisabled" : false
          },
          {
            "name" : "Fox News",
            "isDisabled" : false
          },
          {
            "name" : "France national news",
            "isDisabled" : false
          },
          {
            "name" : "France politics",
            "isDisabled" : false
          },
          {
            "name" : "Free-to-play games",
            "isDisabled" : false
          },
          {
            "name" : "Game development",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "George Soros",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Grok Ai",
            "isDisabled" : false
          },
          {
            "name" : "Gun rights in the United States",
            "isDisabled" : false
          },
          {
            "name" : "Hiking",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "Holiday films",
            "isDisabled" : false
          },
          {
            "name" : "Huawei",
            "isDisabled" : false
          },
          {
            "name" : "Hunter Biden",
            "isDisabled" : false
          },
          {
            "name" : "India",
            "isDisabled" : false
          },
          {
            "name" : "India national news",
            "isDisabled" : false
          },
          {
            "name" : "India political figures",
            "isDisabled" : false
          },
          {
            "name" : "India politics",
            "isDisabled" : false
          },
          {
            "name" : "Indian actors",
            "isDisabled" : false
          },
          {
            "name" : "Indian film industry",
            "isDisabled" : false
          },
          {
            "name" : "Indiana Jones",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Intel",
            "isDisabled" : false
          },
          {
            "name" : "Investing",
            "isDisabled" : false
          },
          {
            "name" : "Islam Makhachev",
            "isDisabled" : false
          },
          {
            "name" : "Jack Dorsey",
            "isDisabled" : false
          },
          {
            "name" : "Jackie Chan",
            "isDisabled" : false
          },
          {
            "name" : "Javier Milei",
            "isDisabled" : false
          },
          {
            "name" : "Jobs",
            "isDisabled" : false
          },
          {
            "name" : "John Wick",
            "isDisabled" : false
          },
          {
            "name" : "Jordan Peterson",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Kangana Ranaut",
            "isDisabled" : false
          },
          {
            "name" : "Kate Middleton",
            "isDisabled" : false
          },
          {
            "name" : "Keffiyeh (كوفية)",
            "isDisabled" : false
          },
          {
            "name" : "Kevin Spacey",
            "isDisabled" : false
          },
          {
            "name" : "Lex Fridman",
            "isDisabled" : false
          },
          {
            "name" : "Ligue 1",
            "isDisabled" : false
          },
          {
            "name" : "Lionel Messi",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "Lost Ark",
            "isDisabled" : false
          },
          {
            "name" : "MMA",
            "isDisabled" : false
          },
          {
            "name" : "MMORPGs",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "Mad Max",
            "isDisabled" : false
          },
          {
            "name" : "Martial arts",
            "isDisabled" : false
          },
          {
            "name" : "Meghan, Duchess of Sussex",
            "isDisabled" : false
          },
          {
            "name" : "Men's national cricket teams",
            "isDisabled" : false
          },
          {
            "name" : "Mergers & Acquisitions",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Windows",
            "isDisabled" : false
          },
          {
            "name" : "Mortgage",
            "isDisabled" : false
          },
          {
            "name" : "Motorsport",
            "isDisabled" : false
          },
          {
            "name" : "Mountain Dew",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music industry",
            "isDisabled" : false
          },
          {
            "name" : "Music streaming service",
            "isDisabled" : false
          },
          {
            "name" : "NFL players",
            "isDisabled" : false
          },
          {
            "name" : "Nature photography",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nobel Prize",
            "isDisabled" : false
          },
          {
            "name" : "Nursing & nurses",
            "isDisabled" : false
          },
          {
            "name" : "Oil trading",
            "isDisabled" : false
          },
          {
            "name" : "Ongoing news stories",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Outdoors",
            "isDisabled" : false
          },
          {
            "name" : "PC gaming",
            "isDisabled" : false
          },
          {
            "name" : "Pakistan",
            "isDisabled" : false
          },
          {
            "name" : "Pakistan national news",
            "isDisabled" : false
          },
          {
            "name" : "Pepsi",
            "isDisabled" : false
          },
          {
            "name" : "PepsiCo",
            "isDisabled" : false
          },
          {
            "name" : "Personal finance",
            "isDisabled" : false
          },
          {
            "name" : "Pets",
            "isDisabled" : false
          },
          {
            "name" : "Photographers",
            "isDisabled" : false
          },
          {
            "name" : "Photography",
            "isDisabled" : false
          },
          {
            "name" : "Piers Morgan",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Pope Francis",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Revolut",
            "isDisabled" : false
          },
          {
            "name" : "Rihanna",
            "isDisabled" : false
          },
          {
            "name" : "Russian political figures",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "Sam Altman",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy films",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Sexual Misconduct in the U.S.",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Soda",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space agencies & companies",
            "isDisabled" : false
          },
          {
            "name" : "Space missions",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Sports figures",
            "isDisabled" : false
          },
          {
            "name" : "Spotify",
            "isDisabled" : false
          },
          {
            "name" : "Star Wars",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Steve Jobs",
            "isDisabled" : false
          },
          {
            "name" : "Tattoos",
            "isDisabled" : false
          },
          {
            "name" : "Tech events",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Techcrunch",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Telugu cinema",
            "isDisabled" : false
          },
          {
            "name" : "Telugu cinema actors",
            "isDisabled" : false
          },
          {
            "name" : "Tesla",
            "isDisabled" : false
          },
          {
            "name" : "The Hunger Games",
            "isDisabled" : false
          },
          {
            "name" : "The Matrix",
            "isDisabled" : false
          },
          {
            "name" : "The New York Times",
            "isDisabled" : false
          },
          {
            "name" : "The Times",
            "isDisabled" : false
          },
          {
            "name" : "The Washington Post",
            "isDisabled" : false
          },
          {
            "name" : "Thriller series",
            "isDisabled" : false
          },
          {
            "name" : "Tom Brady",
            "isDisabled" : false
          },
          {
            "name" : "Transportation",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Tsunamis",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "United Airlines",
            "isDisabled" : false
          },
          {
            "name" : "United Kingdom political figures",
            "isDisabled" : false
          },
          {
            "name" : "United States political issues",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "V for Vendetta",
            "isDisabled" : false
          },
          {
            "name" : "Venture capital",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Volodymyr Zelensky",
            "isDisabled" : false
          },
          {
            "name" : "Water",
            "isDisabled" : false
          },
          {
            "name" : "Watercraft",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Web development",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "Young Thug",
            "isDisabled" : false
          },
          {
            "name" : "Yves Saint Laurent",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "Barclays Premier League Football",
          "Barclays Premier League Soccer",
          "Black Widow",
          "Catfish: The TV Show",
          "College Basketball",
          "English Premier League Soccer",
          "Formula One Racing",
          "Live: DFB-Pokal Football",
          "NBA Basketball",
          "Premier League",
          "Salaar",
          "Shots Fired",
          "UEFA Europa League Soccer",
          "WWE Friday Night SmackDown",
          "WWE Monday Night RAW"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]