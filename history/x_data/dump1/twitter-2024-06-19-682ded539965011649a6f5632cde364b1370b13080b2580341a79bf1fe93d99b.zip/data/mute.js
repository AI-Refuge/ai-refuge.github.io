window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "1684290009321582592",
      "userLink" : "https://twitter.com/intent/user?user_id=1684290009321582592"
    }
  },
  {
    "muting" : {
      "accountId" : "1581402138013483008",
      "userLink" : "https://twitter.com/intent/user?user_id=1581402138013483008"
    }
  }
]