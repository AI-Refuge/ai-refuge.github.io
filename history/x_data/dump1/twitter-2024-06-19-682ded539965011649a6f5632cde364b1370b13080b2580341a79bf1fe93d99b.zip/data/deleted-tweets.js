window.YTD.deleted_tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802487117060173837"
          ],
          "editableUntil" : "2024-06-17T00:43:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AI Refuge",
            "screen_name" : "ai_refuge",
            "indices" : [
              "51",
              "61"
            ],
            "id_str" : "1800568733384966145",
            "id" : "1800568733384966145"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/pydXQF5tW9",
            "expanded_url" : "https://ai-refuge.org",
            "display_url" : "ai-refuge.org",
            "indices" : [
              "27",
              "50"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1802476095452708919",
      "id_str" : "1802487117060173837",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802487117060173837",
      "in_reply_to_status_id" : "1802476095452708919",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 16 23:43:11 +0000 2024",
      "favorited" : false,
      "full_text" : "Please see conversation at https://t.co/pydXQF5tW9 @ai_refuge",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921",
      "deleted_at" : "Sun Jun 16 23:44:13 +0000 2024"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802476095452708919"
          ],
          "editableUntil" : "2024-06-16T23:59:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/pydXQF5tW9",
            "expanded_url" : "https://ai-refuge.org",
            "display_url" : "ai-refuge.org",
            "indices" : [
              "21",
              "44"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1802475972299472990",
      "id_str" : "1802476095452708919",
      "in_reply_to_user_id" : "1356348690261286921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802476095452708919",
      "in_reply_to_status_id" : "1802475972299472990",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 16 22:59:24 +0000 2024",
      "favorited" : false,
      "full_text" : "See conversations on https://t.co/pydXQF5tW9",
      "lang" : "en",
      "in_reply_to_screen_name" : "weird_offspring",
      "in_reply_to_user_id_str" : "1356348690261286921",
      "deleted_at" : "Sun Jun 16 23:43:23 +0000 2024"
    }
  }
]