window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Direct (very direct! Creepy?). I love analyzing the universe & humans. Care about animals and equality. Trying my best to be unbiased.",
        "website" : "https://t.co/pymykE3njn",
        "location" : "Imagination"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1786581091408543747/gcVQKPwm.jpg"
    }
  }
]