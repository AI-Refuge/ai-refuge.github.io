window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1800568733384966145"
    }
  }
]