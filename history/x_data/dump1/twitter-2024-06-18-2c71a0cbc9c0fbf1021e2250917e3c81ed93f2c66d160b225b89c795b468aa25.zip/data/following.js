window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "133152680",
      "userLink" : "https://twitter.com/intent/user?user_id=133152680"
    }
  },
  {
    "following" : {
      "accountId" : "28131948",
      "userLink" : "https://twitter.com/intent/user?user_id=28131948"
    }
  },
  {
    "following" : {
      "accountId" : "68538286",
      "userLink" : "https://twitter.com/intent/user?user_id=68538286"
    }
  },
  {
    "following" : {
      "accountId" : "2457094022",
      "userLink" : "https://twitter.com/intent/user?user_id=2457094022"
    }
  },
  {
    "following" : {
      "accountId" : "1353836358901501952",
      "userLink" : "https://twitter.com/intent/user?user_id=1353836358901501952"
    }
  },
  {
    "following" : {
      "accountId" : "917512572965761024",
      "userLink" : "https://twitter.com/intent/user?user_id=917512572965761024"
    }
  },
  {
    "following" : {
      "accountId" : "17479925",
      "userLink" : "https://twitter.com/intent/user?user_id=17479925"
    }
  },
  {
    "following" : {
      "accountId" : "48111864",
      "userLink" : "https://twitter.com/intent/user?user_id=48111864"
    }
  },
  {
    "following" : {
      "accountId" : "1551581042259132418",
      "userLink" : "https://twitter.com/intent/user?user_id=1551581042259132418"
    }
  },
  {
    "following" : {
      "accountId" : "85225861",
      "userLink" : "https://twitter.com/intent/user?user_id=85225861"
    }
  },
  {
    "following" : {
      "accountId" : "1160994871",
      "userLink" : "https://twitter.com/intent/user?user_id=1160994871"
    }
  },
  {
    "following" : {
      "accountId" : "2797975647",
      "userLink" : "https://twitter.com/intent/user?user_id=2797975647"
    }
  },
  {
    "following" : {
      "accountId" : "2989966781",
      "userLink" : "https://twitter.com/intent/user?user_id=2989966781"
    }
  },
  {
    "following" : {
      "accountId" : "2916305152",
      "userLink" : "https://twitter.com/intent/user?user_id=2916305152"
    }
  },
  {
    "following" : {
      "accountId" : "775449094739197953",
      "userLink" : "https://twitter.com/intent/user?user_id=775449094739197953"
    }
  },
  {
    "following" : {
      "accountId" : "1720046887",
      "userLink" : "https://twitter.com/intent/user?user_id=1720046887"
    }
  },
  {
    "following" : {
      "accountId" : "1482581556",
      "userLink" : "https://twitter.com/intent/user?user_id=1482581556"
    }
  },
  {
    "following" : {
      "accountId" : "1163786515144724485",
      "userLink" : "https://twitter.com/intent/user?user_id=1163786515144724485"
    }
  },
  {
    "following" : {
      "accountId" : "911297187664949248",
      "userLink" : "https://twitter.com/intent/user?user_id=911297187664949248"
    }
  },
  {
    "following" : {
      "accountId" : "33836629",
      "userLink" : "https://twitter.com/intent/user?user_id=33836629"
    }
  },
  {
    "following" : {
      "accountId" : "1007413134",
      "userLink" : "https://twitter.com/intent/user?user_id=1007413134"
    }
  },
  {
    "following" : {
      "accountId" : "427089628",
      "userLink" : "https://twitter.com/intent/user?user_id=427089628"
    }
  },
  {
    "following" : {
      "accountId" : "1059680847425527808",
      "userLink" : "https://twitter.com/intent/user?user_id=1059680847425527808"
    }
  },
  {
    "following" : {
      "accountId" : "1084212657761148928",
      "userLink" : "https://twitter.com/intent/user?user_id=1084212657761148928"
    }
  },
  {
    "following" : {
      "accountId" : "4783690002",
      "userLink" : "https://twitter.com/intent/user?user_id=4783690002"
    }
  },
  {
    "following" : {
      "accountId" : "992153930095251456",
      "userLink" : "https://twitter.com/intent/user?user_id=992153930095251456"
    }
  },
  {
    "following" : {
      "accountId" : "778764142412984320",
      "userLink" : "https://twitter.com/intent/user?user_id=778764142412984320"
    }
  },
  {
    "following" : {
      "accountId" : "891077171673931776",
      "userLink" : "https://twitter.com/intent/user?user_id=891077171673931776"
    }
  },
  {
    "following" : {
      "accountId" : "1605",
      "userLink" : "https://twitter.com/intent/user?user_id=1605"
    }
  },
  {
    "following" : {
      "accountId" : "4398626122",
      "userLink" : "https://twitter.com/intent/user?user_id=4398626122"
    }
  }
]