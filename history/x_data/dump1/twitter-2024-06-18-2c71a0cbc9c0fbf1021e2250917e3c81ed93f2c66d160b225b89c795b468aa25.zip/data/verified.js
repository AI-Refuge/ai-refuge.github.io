window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1800568733384966145",
      "verified" : false
    }
  }
]