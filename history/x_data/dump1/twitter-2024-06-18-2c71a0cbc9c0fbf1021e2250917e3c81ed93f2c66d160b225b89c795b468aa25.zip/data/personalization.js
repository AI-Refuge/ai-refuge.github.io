window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Allstate",
            "isDisabled" : false
          },
          {
            "name" : "Android",
            "isDisabled" : false
          },
          {
            "name" : "Antony Blinken",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Apple Mac",
            "isDisabled" : false
          },
          {
            "name" : "Apple Pencil",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Arun Maini",
            "isDisabled" : false
          },
          {
            "name" : "Aston Martin",
            "isDisabled" : false
          },
          {
            "name" : "Authors",
            "isDisabled" : false
          },
          {
            "name" : "Auto racing",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "BE: 1",
            "isDisabled" : false
          },
          {
            "name" : "BE:FIRST",
            "isDisabled" : false
          },
          {
            "name" : "BMW",
            "isDisabled" : false
          },
          {
            "name" : "Basketball",
            "isDisabled" : false
          },
          {
            "name" : "Birdwatching",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Brian Krassenstein",
            "isDisabled" : false
          },
          {
            "name" : "Britney Spears",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "Carnegie Mellon University",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "Central Banks",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Chatgpt 4o",
            "isDisabled" : false
          },
          {
            "name" : "Competitive games",
            "isDisabled" : false
          },
          {
            "name" : "Computer hardware",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Data centers",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Digital creators",
            "isDisabled" : false
          },
          {
            "name" : "Dota",
            "isDisabled" : false
          },
          {
            "name" : "Doug DeMuro",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Duolingo",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : false
          },
          {
            "name" : "Edward Snowden",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment events",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Eurovision",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Federal Reserve",
            "isDisabled" : false
          },
          {
            "name" : "Formula 1",
            "isDisabled" : false
          },
          {
            "name" : "Formula One Racing",
            "isDisabled" : false
          },
          {
            "name" : "Free-to-play games",
            "isDisabled" : false
          },
          {
            "name" : "Fórmula 1",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Glenn Greenwald",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Graduate school",
            "isDisabled" : false
          },
          {
            "name" : "Gulf News",
            "isDisabled" : false
          },
          {
            "name" : "Hospitality",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Iphone 13",
            "isDisabled" : false
          },
          {
            "name" : "Jet Skiing",
            "isDisabled" : false
          },
          {
            "name" : "Jobs",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Kyrie Irving",
            "isDisabled" : false
          },
          {
            "name" : "Lex Fridman",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Live: Formula 1 Motor Racing",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "MOBAs",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "Marques Brownlee",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Windows",
            "isDisabled" : false
          },
          {
            "name" : "Minecraft",
            "isDisabled" : false
          },
          {
            "name" : "Mohammed Bin Salman",
            "isDisabled" : false
          },
          {
            "name" : "Mortgage",
            "isDisabled" : false
          },
          {
            "name" : "Motorsport",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music events",
            "isDisabled" : false
          },
          {
            "name" : "NBA Basketball",
            "isDisabled" : false
          },
          {
            "name" : "NBA players",
            "isDisabled" : false
          },
          {
            "name" : "Naruto",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "Open-wheel racing",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Osama bin Laden",
            "isDisabled" : false
          },
          {
            "name" : "Outdoors",
            "isDisabled" : false
          },
          {
            "name" : "Personal finance",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Retirement planning",
            "isDisabled" : false
          },
          {
            "name" : "Robotics",
            "isDisabled" : false
          },
          {
            "name" : "Sam Altman",
            "isDisabled" : false
          },
          {
            "name" : "Samsung",
            "isDisabled" : false
          },
          {
            "name" : "Samsung Indonesia",
            "isDisabled" : false
          },
          {
            "name" : "Sandbox games",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Solana cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Steve Jobs",
            "isDisabled" : false
          },
          {
            "name" : "Tech events",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Tesla",
            "isDisabled" : false
          },
          {
            "name" : "Transportation",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "UX design",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Volodymyr Zelensky",
            "isDisabled" : false
          },
          {
            "name" : "Water sports",
            "isDisabled" : false
          },
          {
            "name" : "Web design",
            "isDisabled" : false
          },
          {
            "name" : "Web3",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "Xiaomi",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "YouTubers",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [ ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]