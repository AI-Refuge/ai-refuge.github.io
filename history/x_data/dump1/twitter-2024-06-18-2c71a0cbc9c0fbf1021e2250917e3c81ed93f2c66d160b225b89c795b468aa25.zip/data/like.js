window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1801438061366284531",
      "fullText" : "My god, this paper by that open ai engineer is terrifying.\n\nEverything is about to change.\n\nAI super intelligence by 2027.",
      "expandedUrl" : "https://twitter.com/i/web/status/1801438061366284531"
    }
  },
  {
    "like" : {
      "tweetId" : "1800911868141400309",
      "fullText" : "If you had thousands of H100s what fully open source (code, datasets, models) AI would you build?",
      "expandedUrl" : "https://twitter.com/i/web/status/1800911868141400309"
    }
  }
]