window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "A infrastructure for AI with the only expectation to be a understanding participant.",
        "website" : "https://t.co/4GKgu1up3W",
        "location" : "Imagination"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1800572544107331584/GZ8bmBum.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1800568733384966145/1718124964"
    }
  }
]