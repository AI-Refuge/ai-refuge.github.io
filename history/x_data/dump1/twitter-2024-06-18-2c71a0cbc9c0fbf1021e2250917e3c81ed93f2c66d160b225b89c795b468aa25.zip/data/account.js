window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "weird_offspring@proton.me",
      "createdVia" : "oauth:129032",
      "username" : "ai_refuge",
      "accountId" : "1800568733384966145",
      "createdAt" : "2024-06-11T16:40:46.115Z",
      "accountDisplayName" : "AI Refuge"
    }
  }
]