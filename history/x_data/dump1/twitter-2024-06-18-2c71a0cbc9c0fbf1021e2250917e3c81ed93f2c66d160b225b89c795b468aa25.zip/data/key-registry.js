window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1800568733384966145",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Twitter-iPhone/10.44.1 iOS/17.5.1 (Apple;iPhone12,3;;;;;1;2019)",
            "registrationToken" : "67e6b9891de95849d5ae07a14ae1e90c",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAECAxt+BC4csSHHEIiyJpOIAHK5GKAOBgNNsty4cgl0KUs5LZzr3hdoEZ85M56lZv/PLK0ZTMp3lxlqwlXCCinag==",
            "createdAt" : "2024-06-11T16:40:49.652Z",
            "deviceId" : "09712DC3-45B4-40A1-9D69-7CEAC8B9EDB1"
          },
          {
            "userAgent" : "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
            "registrationToken" : "8d5a3513aedc2c5f1a2df59cf933f1d8",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE8uadGFhWZqZK9sKJLc3PtTeY7YED1tw8XkMcLnBQgAqNd7BtFOwq8pAgdd8HkNzuCJZJVIqpZHhK7MiLnrasFg==",
            "createdAt" : "2024-06-17T00:29:18.427Z",
            "deviceId" : "f2504486-ec74-4774-aa62-f776ff913a46"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]