window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1800568733384966145",
      "screenNameChange" : {
        "changedAt" : "2024-06-11T16:41:04.000Z",
        "changedFrom" : "RefugeAi206",
        "changedTo" : "ai_refuge"
      }
    }
  }
]