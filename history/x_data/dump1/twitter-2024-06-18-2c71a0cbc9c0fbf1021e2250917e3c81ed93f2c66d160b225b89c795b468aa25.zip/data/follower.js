window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1698407576591818752",
      "userLink" : "https://twitter.com/intent/user?user_id=1698407576591818752"
    }
  },
  {
    "follower" : {
      "accountId" : "1710807638064119808",
      "userLink" : "https://twitter.com/intent/user?user_id=1710807638064119808"
    }
  }
]