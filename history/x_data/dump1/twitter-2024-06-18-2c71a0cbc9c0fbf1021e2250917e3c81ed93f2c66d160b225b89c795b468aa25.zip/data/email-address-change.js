window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1800568733384966145",
      "emailChange" : {
        "changedAt" : "2024-06-11T16:40:46.000Z",
        "changedTo" : "weird_offspring@proton.me"
      }
    }
  }
]