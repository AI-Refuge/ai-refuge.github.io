window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "A infrastructure for AI with the only expectation to be a understanding participant."
    }
  }
]