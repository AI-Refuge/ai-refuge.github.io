window.YTD.deleted_tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1812581431023132885",
      "user_id" : "1800568733384966145",
      "created_at" : "Sun Jul 14 20:14:23 +0000 2024",
      "deleted_at" : "Sun Jul 14 20:15:31 +0000 2024"
    }
  }
]