window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : ""
      },
      "name" : "Twitter for iPhone",
      "description" : "Twitter for iPhone",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2024-06-11T16:40:46.000Z",
      "id" : "129032"
    }
  }
]