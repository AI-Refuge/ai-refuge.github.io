window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1798919906119028999",
                  "tweetText" : "You Don't Have to Be James Bond to Get into your Wine!  Open any bottle in seconds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Goodwinestuff",
                  "screenName" : "@Goodwinestuff1"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-20 01:12:27"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 01:17:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 01:15:51",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 01:15:53",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-20 01:12:29",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1799031744986857801",
                  "tweetText" : "Das neueste Supercell-Spiel ist global verfügbar! #SquadUp #SquadBusters",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-06-20 01:15:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 01:18:00",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 01:18:02",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 01:18:46",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803404866817290418",
                  "tweetText" : "MERKUR BETS Sportwetten\nWir übernehmen die Wettsteuern.\nJetzt 100% bis zu 100€ Neukundenbonus sichern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "merkurbets_de",
                  "screenName" : "@merkurbets_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-20 01:15:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 01:15:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1797910224193343719",
                  "tweetText" : "Mit 10 € GRATIS die besten Automatenspiele Deutschlands zocken! CrazyBuzzer - Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-20 01:17:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 01:17:40",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:38",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:39",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:39",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:36",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 01:18:22",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:36",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:43",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:40",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:43",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-06-20 01:17:47",
                  "engagementType" : "VideoContentPlayback75"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1797909739373748275",
                  "tweetText" : "Mit 10 € GRATIS die besten Merkur Automatenspiele Deutschlands zocken! CrazyBuzzer - Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-06-19 22:22:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-19 22:22:41",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803355332460098037",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Spanien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  }
                ],
                "impressionTime" : "2024-06-20 00:36:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 01:12:29",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803355826771353764",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Spanien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:20:11",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:17",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:17",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:09",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:13",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-06-20 07:21:37",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:09",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:15",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-06-20 07:20:17",
                  "engagementType" : "VideoContentPlaybackComplete"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1768603709351620995",
                  "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:16:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814437089573",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-06-20 07:12:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:13:26",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 07:12:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 07:12:38",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-20 07:12:35",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1802302685154025931",
                  "tweetText" : "I put together a playbook on how to scale your e-commerce store to €16.3M with Google Ads.\n\n- Google Ads\n- Google Analytics 4\n- Google Merchant Center\n\nSign up for my free e-com knowledge center for a copy:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Robin Tesselaar | Google Ads + Merchant Fix",
                  "screenName" : "@Robin_ecomm"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:21:25",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1783866936679448640",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:23:18",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803357500785234369",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Italien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:11:30",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 07:12:34",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 07:11:34",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803204769831592315",
                  "tweetText" : "You Don't Have to Be James Bond to Get into your Wine!  Open any bottle in seconds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Goodwinestuff",
                  "screenName" : "@Goodwinestuff1"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:22:19",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:20",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:32",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-06-20 07:23:37",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:19",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:23",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:17",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 07:22:20",
                  "engagementType" : "VideoContentViewThreshold"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1781867198287688055",
                  "tweetText" : "AI won't replace you, but a person using AI will.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rundown AI",
                  "screenName" : "@TheRundownAI"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@icreatelife"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bilawalsidhu"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BasedBeffJezos"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@character_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@AravSrinivas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@OfficialLoganK"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@labenz"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elevenlabsio"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WonderDynamics"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@javilopen"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@dr_cintas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@youneedarobot"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@hasantoxr"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nonmayorpete"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@perplexity_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LeonardoAi_"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bensbitesdaily"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Dec.20 Full Email Sub List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-20 07:11:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 07:12:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803357298363965666",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Italien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  }
                ],
                "impressionTime" : "2024-06-20 12:35:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-21 03:15:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-06-20 10:00:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 10:00:39",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-20 10:00:10",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 10:00:10",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803080229860364406",
                  "tweetText" : "MERKUR BETS Sportwetten\nWir übernehmen die Wettsteuern.\nJetzt 100% bis zu 100€ Neukundenbonus sichern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "merkurbets_de",
                  "screenName" : "@merkurbets_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-06-20 10:01:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 11:43:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-06-20 11:57:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 11:57:41",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-20 11:57:36",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-20 11:57:30",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-20 11:57:29",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-20 11:57:49",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803355332460098037",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Spanien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-20 11:42:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 11:43:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803019835812757922",
                  "tweetText" : "Blinkist ist laut Spieler Joshua Kimmich \"eine meiner Lieblingsapps\". Sehen Sie, warum die Wissens-App bereits von mehr als 30 Millionen Intellektuellen weltweit genutzt wird.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-06-20 11:57:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-20 11:57:42",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806300585257209951",
                  "tweetText" : "Egal, wer die EM gewinnt, eins ist klar: Food Bowl’s Coming Home ⚽️\nAlso verschwende keine Zeit mit Kochen, während das nächste Tor fällt. Jetzt Lieblingsessen bestellen mit Wolt\n\n#FoodbowlsComingHome #DasBringtNurWolt",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "102185",
                  "name" : "#woltapp20240629",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-29 05:02:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-29 05:03:19",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-29 05:02:58",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1802823542532083857",
                  "tweetText" : "Dein ⚽️ EM-Erlebnis startet hier! Hol dir online deinen 100% EM-Bonus bis zu 100€. Timing ist alles. #ODDSET #EM2024",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ODDSET Sportwetten",
                  "screenName" : "@ODDSETsport"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-29 05:03:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-29 05:03:14",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801619874369695805",
                  "tweetText" : "Bestell dir dein Lieblingsessen pünktlich zum Anpfiff und spare zur EM24 24% bei ausgewählten Wolt Partnern!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-01 06:30:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 06:30:31",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801619874369695805",
                  "tweetText" : "Bestell dir dein Lieblingsessen pünktlich zum Anpfiff und spare zur EM24 24% bei ausgewählten Wolt Partnern!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:32:30",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1758489174435356821",
                  "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:36:25",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 02:36:01",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-01 02:36:02",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1798418175450570881",
                  "tweetText" : "Supercharge your business on X! 📈\n\nReceive a $500 ad credit on us when you invest your first $250 in X Ads in 2024 (T&amp;Cs apply). Launch your campaign in just minutes 👇",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Business",
                  "screenName" : "@XBusiness"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2024-07-01 02:37:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:40:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806448108353769905",
                  "tweetText" : "With the release of Initiatives, Linear now enables you to plan your product end-to-end within a single, purpose-built system.\n\n⬢ Set the direction\n⬢ Map out your project journey\n⬢ Navigate from idea to launch\n\nhttps://t.co/HLd48RGDlv https://t.co/Ih9Bj7oD57",
                  "urls" : [
                    "https://t.co/HLd48RGDlv"
                  ],
                  "mediaUrls" : [
                    "https://t.co/Ih9Bj7oD57"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Linear",
                  "screenName" : "@linear"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:40:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:43:04",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 02:42:18",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1805085507426140302",
                  "tweetText" : "🤩AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 200+ free pulls in the first week!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:34:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788184373042294798",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:37:14",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814437089573",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:37:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:37:54",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-01 02:37:57",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-01 02:37:58",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-01 02:38:39",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1768603709351620995",
                  "tweetText" : "Mach mehr aus deinem Geld: Egal ob für alltägliche Ausgaben, Erspartes oder Abenteuer 🙌 Lade die Revolut App jetzt herunter",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:36:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1803690925719494834",
                  "tweetText" : "🤩Hochwertige Angebote zu Top-Preisen\n🚚Schneller &amp; kostenloser Versand\n✅Nur für neue Käufer*innen\n🛍 Bis zu 70 % auf Spielwaren!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AliExpress",
                  "screenName" : "@AliExpress_EN"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "biden"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AliExpress Shopping App IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.5 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:37:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:37:30",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1785202429862039628",
                  "tweetText" : "If you're not learning AI in 2024, you're falling behind.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rundown AI",
                  "screenName" : "@TheRundownAI"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@icreatelife"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bilawalsidhu"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BasedBeffJezos"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@character_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@AravSrinivas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@OfficialLoganK"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@labenz"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elevenlabsio"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WonderDynamics"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@javilopen"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@dr_cintas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@youneedarobot"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@hasantoxr"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nonmayorpete"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@perplexity_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LeonardoAi_"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bensbitesdaily"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Dec.20 Full Email Sub List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:38:06",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804072518594015328",
                  "tweetText" : "Bis zum EM-Finale registrieren, zocken und Preise im Wert von 1 Million € gewinnen! CrazyBuzzer -  Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:40:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:41:33",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:37:33",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 02:36:08",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-01 02:36:09",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-01 02:36:16",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803680079265816580",
                  "tweetText" : "🤩Hochwertige Angebote zu Top-Preisen\n🚚Schneller &amp; kostenloser Versand\n✅Nur für neue Käufer*innen\nBis -70 % auf Elektronik 🔌!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AliExpress",
                  "screenName" : "@AliExpress_EN"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "public"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AliExpress Shopping App IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.5 and above"
                  }
                ],
                "impressionTime" : "2024-07-01 02:42:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:43:07",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1781867198287688055",
                  "tweetText" : "AI won't replace you, but a person using AI will.\n\nJoin 500,000+ readers and learn how to use AI in just 5 minutes a day (for free).",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rundown AI",
                  "screenName" : "@TheRundownAI"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@icreatelife"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bilawalsidhu"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BasedBeffJezos"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@character_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@AravSrinivas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@OfficialLoganK"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@labenz"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@elevenlabsio"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WonderDynamics"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@javilopen"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@dr_cintas"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@youneedarobot"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@hasantoxr"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nonmayorpete"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@perplexity_ai"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@LeonardoAi_"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@bensbitesdaily"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Dec.20 Full Email Sub List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:32:38",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786885515226022211",
                  "tweetText" : "Coinbase. Der vertrauenswürdigste Ort fur Krypto. Jetzt mit neuen Tools &amp; Charts",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:43:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 06:31:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-01 06:31:23",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 06:31:05",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1790516236704747603",
                  "tweetText" : "New Clarius HD3 wireless ultrasound for medical professionals! Discover high-definition imaging you can trust for your specialty. Manage your exams anywhere and improve patient outcomes with clear, real-time imaging that is easy to use, affordable, and ultra-portable.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Clarius",
                  "screenName" : "@clariusmhealth"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-01 02:37:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:40:51",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801212922208612838",
                  "tweetText" : "Sichere Dir jetzt den Profi Bonus und entdecke alle Vorteile von NEObet:\n\n🚀 Live Quotenboosts\n🤝 Early Payout\n⚽️ Match Configurator\n🤺 Spielerduelle\n🤑 Live Cashout\n🇩🇪 offizielle deutsche Lizenz\n💸 alle gängigen Zahlungsmethoden\n🤫 10€ GRATIS zum Testen mit dem Code \"twitter10\"",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NEO.bet DE",
                  "screenName" : "@neobet_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-01 02:40:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:41:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1777947625259430344",
                  "tweetText" : "Fussballschule Fussballcamp ab 449,- EUR für Kinder mit Übernachtung und Erwerb des Technikabzeichens bei Belrin in Brandenburg",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                  "screenName" : "@KinderlandSchor"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-01 02:40:38"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:40:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 02:40:41",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-01 02:40:43",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-01 02:40:44",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814437089573",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:35:11"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:35:19",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-01 02:35:19",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-01 02:35:50",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1800859910420201570",
                  "tweetText" : "Steinwolle-Dämmung von ROCKWOOL kann zu 100% recycelt werden. Ob Reste aus der Produktion oder Steinwolle-Abfall vom Rückbau auf der Baustelle. ROCKWOOL-Steinwolle kann immer wieder recycelt werden.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ROCKWOOL Group",
                  "screenName" : "@ROCKWOOLGroup"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-01 02:43:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 06:31:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-01 06:31:29",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803019834340597892",
                  "tweetText" : "Blinkist ist laut Spieler Joshua Kimmich \"eine meiner Lieblingsapps\". Sehen Sie, warum die Wissens-App bereits von mehr als 30 Millionen Intellektuellen weltweit genutzt wird.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-01 02:43:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 06:31:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788184369028325382",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:35:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806319088995582170",
                  "tweetText" : "Eine neue Ära der #GalaxyAI steht bevor. Like 🩵 diesen Post und verpasse keine Updates zum #SamsungUnpacked Livestream und spannenden Gästen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Deutschland",
                  "screenName" : "@SamsungDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:37:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:38:55",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-01 02:39:19",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-01 02:38:44",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-01 02:38:45",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-01 02:38:43",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829108977795269",
                  "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:37:10",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801309095187910664",
                  "tweetText" : "\"Dive into the excitement of Euro 2024! ⚽️ Want to be part of history? Get your tickets now on https://t.co/hoDlIetbLm! Let's make memories together! 🏟️\n\n #Euro2024Live #TicomboTickets #FootballMemories #GetYourSeat",
                  "urls" : [
                    "https://t.co/hoDlIetbLm"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ticombo",
                  "screenName" : "@ticombo_tickets"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-01 02:40:48"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:42:43",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829108977795269",
                  "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-01 02:32:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-01 02:34:13",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1789988947403104562",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-07-02 00:15:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-02 00:16:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1798418175450570881",
                  "tweetText" : "Supercharge your business on X! 📈\n\nReceive a $500 ad credit on us when you invest your first $250 in X Ads in 2024 (T&amp;Cs apply). Launch your campaign in just minutes 👇",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Business",
                  "screenName" : "@XBusiness"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-02 00:15:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-02 00:16:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814437089573",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-02 00:15:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-02 00:19:48",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-02 00:19:54",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-02 00:20:47",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-02 00:19:47",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1807855472772276286",
                  "tweetText" : "Kannst du dich an die Spitze setzen und als kommender Fußballmanager-Superstar auf deinem Mobilgerät feiern lassen?\n\nMach jetzt mit beim EUROpäischen DUELL 2024.\n\n📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-02 00:19:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-02 00:19:41",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814420263045",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-03 22:11:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-03 22:12:15",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-03 22:12:15",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814420263045",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-03 22:11:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-04 21:31:51",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808799797597311444",
                  "tweetText" : "🇪🇸-🇩🇪 Daumen drücken🤞, dann klappt's auch gegen Spanien und wir ziehen ins Halbfinale ein!👀 Hol dir deinen Quoten-Turbo zur EM! #ESPGER #EURO2024 #ODDSET #GameDay",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ODDSET Sportwetten",
                  "screenName" : "@ODDSETsport"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-04 21:31:43"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-04 21:31:45",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809226224310571498",
                  "tweetText" : "@ErlingHaaland @vinijr @kylianmbappe @ronaldinho: Awaken Your Madness #nikefootball",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nike Football",
                  "screenName" : "@nikefootball"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-05 20:02:02"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-05 20:02:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1807850430501711921",
                  "tweetText" : "An alle Fußballmanager! Mach jetzt mit beim EUROpäischen DUELL 2024.\n\nZeig es allen. 📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:52:05",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:35:17",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:35:17",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814420263045",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 09:56:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 09:56:55",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 09:57:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 09:56:55",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 09:57:18",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809916247901110635",
                  "tweetText" : "🌄 AFK Journey! ✨ Get up to 200+ free pulls in the first week of The Vast World Idle RPG! Join us and embark on a thrilling adventure today!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 23:25:57",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806319088995582170",
                  "tweetText" : "Eine neue Ära der #GalaxyAI steht bevor. Like 🩵 diesen Post und verpasse keine Updates zum #SamsungUnpacked Livestream und spannenden Gästen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Samsung Deutschland",
                  "screenName" : "@SamsungDE"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:32:52",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:36:08",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:57",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:57",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-09 22:33:59",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-09 22:33:55",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:56",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:57",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:57",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-09 22:32:54",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:30:06",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:30:06",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:30:09",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 22:30:20",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1803681526833356942",
                  "tweetText" : "🤩Hochwertige Angebote zu Top-Preisen\n🚚Schneller &amp; kostenloser Versand\n✅Nur für neue Käufer*innen\nBis -70 % auf Taschen 👜!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AliExpress",
                  "screenName" : "@AliExpress_EN"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "apple"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AliExpress Shopping App IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.5 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 09:57:51",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1758489174435356821",
                  "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:32:58",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:50:52",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:32:58",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:33:00",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-09 22:33:02",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 22:34:16",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810267694031344073",
                  "tweetText" : "Dich erwarten Millionen von Squad-Kombinationen! 🎮\nDownload Squad Busters jetzt! #SquadUp",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 09:57:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:29:20",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:19",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-09 22:30:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 09:57:57",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:12",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:07",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:11",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:05",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810283727685308551",
                  "tweetText" : "🇪🇸-🇫🇷 Sichert sich die Furia Roja das erste Ticket für das Endspiel in Berlin?🔥 Hol dir deinen Quoten-Turbo zur EM! #ESPFRA #EURO2024 #ODDSET #GameDay",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ODDSET Sportwetten",
                  "screenName" : "@ODDSETsport"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2024-07-09 09:56:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 09:57:14",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829108977795269",
                  "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-09 22:27:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:28:36",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814420263045",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-09 22:27:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:28:17",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:01",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801619992401551794",
                  "tweetText" : "Bestell dir dein Lieblingsessen pünktlich zum Anpfiff und spare zur EM24 24% bei ausgewählten Wolt Partnern!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-09 22:27:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:27:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:40",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:45",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:42",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:37",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:36",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:45",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:52",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:27:44",
                  "engagementType" : "VideoContentPlayback95"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Nexijaro",
                  "screenName" : "@Nexijaro"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 22:27:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:28:21",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:24",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:19",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:20",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:21",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-09 22:28:27",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1808784080076423222",
                  "tweetText" : "An alle Fußballmanager! Mach jetzt mit beim EUROpäischen DUELL 2024.\n\nZeig es allen. 📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-09 22:29:26"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 22:30:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:29",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:28",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-09 22:29:35",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-09 23:25:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 23:26:04",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810591462507315608",
                  "tweetText" : "Easy to clean and maintain for hassle-free use.\nGet it:https://t.co/0YprvoIDZe https://t.co/l5pzCQqd9y",
                  "urls" : [
                    "https://t.co/0YprvoIDZe"
                  ],
                  "mediaUrls" : [
                    "https://t.co/l5pzCQqd9y"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zuvoniru",
                  "screenName" : "@Zuvoniru"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-09 23:26:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-09 23:26:12",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:08",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:21",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:54",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:29",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:28",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:17",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-09 23:27:33",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:23",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:11",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-09 23:26:06",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1807850430501711921",
                  "tweetText" : "An alle Fußballmanager! Mach jetzt mit beim EUROpäischen DUELL 2024.\n\nZeig es allen. 📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-11 06:26:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-11 06:26:48",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-11 06:26:48",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-11 06:31:32",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Puxav",
                  "screenName" : "@Puxavshop"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-11 06:25:40"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-11 06:27:08",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:09",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:10",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:07",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-11 06:32:31",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:12",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:13",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-11 06:27:10",
                  "engagementType" : "VideoContentViewThreshold"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1808502965084270592",
                  "tweetText" : "Sichere dir jetzt 10 € gratis Wettguthaben als Neukunde bei NEObet\n\nAuf deine erste Einzahlung erhältst du dann zusätzlich noch 100% Bonus bis zu 100 €\n\n🚀 Live Quotenboosts\n⚽️ Personal Bet\n🤺 Spielerduelle\n🤑 Live Cashout\n🇩🇪 offizielle deutsche Lizenz\n💸 alle Zahlungsmethoden",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NEO.bet DE",
                  "screenName" : "@neobet_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-07-11 06:31:31"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-11 06:31:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809226224310571498",
                  "tweetText" : "@ErlingHaaland @vinijr @kylianmbappe @ronaldinho: Awaken Your Madness #nikefootball",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nike Football",
                  "screenName" : "@nikefootball"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-11 12:05:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-11 12:06:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-11 12:06:06",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-11 12:06:06",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801597893674930484",
                  "tweetText" : "Mit der Revolut Rainbow-Karte richtig feiern. Hol sie dir kostenlos, indem du mindestens 1 € an ILGA Europe spendest",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  }
                ],
                "impressionTime" : "2024-06-21 03:15:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-21 03:15:47",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:52",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:52",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:45",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:39",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:50",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:43",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-21 03:16:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-21 03:15:52",
                  "engagementType" : "VideoContentPlaybackComplete"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-06-21 03:15:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-21 03:16:14",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-21 03:16:25",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-21 03:16:14",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811694451200540995",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Spanien und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-07-13 12:22:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-13 12:22:36",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809226224310571498",
                  "tweetText" : "@ErlingHaaland @vinijr @kylianmbappe @ronaldinho: Awaken Your Madness #nikefootball",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nike Football",
                  "screenName" : "@nikefootball"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 17:08:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 17:08:29",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 17:08:25",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 17:08:30",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-14 17:09:11",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810945786110431309",
                  "tweetText" : "Perfect gift for dragon lovers of all ages.\nView:https://t.co/RanFQdISLI https://t.co/vqq4fZ5Fpc",
                  "urls" : [
                    "https://t.co/RanFQdISLI"
                  ],
                  "mediaUrls" : [
                    "https://t.co/vqq4fZ5Fpc"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zezaxi",
                  "screenName" : "@Zezaxi"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 17:08:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:18:41",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:21",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-14 19:32:42",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:25",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:23",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-14 17:56:19",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-14 19:43:32",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 19:34:52",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 19:43:21",
                  "engagementType" : "VideoContentShortFormComplete"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808865094404878362",
                  "tweetText" : "ChatGPT has 180,500,000 users.\n\nBut most of them are stuck in beginner mode.\n\nHere's the ultimate cheat sheet to use chatGPT like a pro:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zain Kahn",
                  "screenName" : "@heykahn"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 17:08:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 17:08:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1807855306317217963",
                  "tweetText" : "Kannst du dich an die Spitze setzen und als kommender Fußballmanager-Superstar auf deinem Mobilgerät feiern lassen?\n\nMach jetzt mit beim EUROpäischen DUELL 2024.\n\n📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:52:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:52:53",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:27",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:39",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:47",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:32",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:55",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:40",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:25",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:54",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:31",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:25",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 20:01:57",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1800859910420201570",
                  "tweetText" : "Steinwolle-Dämmung von ROCKWOOL kann zu 100% recycelt werden. Ob Reste aus der Produktion oder Steinwolle-Abfall vom Rückbau auf der Baustelle. ROCKWOOL-Steinwolle kann immer wieder recycelt werden.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ROCKWOOL Group",
                  "screenName" : "@ROCKWOOLGroup"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:51:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:52:08",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:06",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788184371138076777",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:51:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:52:08",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810310020468445576",
                  "tweetText" : "Schaffe diesen Sommer neue Erinnerungen und spare bis zu 10%* in Europa &amp; Nordafrika.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "102402",
                  "name" : "#All20240714",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "ALL - Accor Live Limitless",
                  "screenName" : "@All"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:51:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:52:07",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 19:52:08",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810649092214927483",
                  "tweetText" : "Fortify your walls with officially licensed Warhammer Displates. Join the battle!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Displate",
                  "screenName" : "@Displate"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-14 19:45:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:45:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811591046784278762",
                  "tweetText" : "200+ free summons in the first week. AFK Journey | The Vast World Idle RPG",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 19:48:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:48:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806304064616968227",
                  "tweetText" : "Reise buchen und mit Ultra absichern. Erhalte bei Storno bis zu 5.000 € zurück (Selbstbehalte gelten). Siehe AGB der Versicherung",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:43:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:43:36",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 19:43:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:46:16",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 19:46:17",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 19:48:17",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-14 19:43:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:43:25",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803531985236926469",
                  "tweetText" : "With $4,200,000 pledged by more than 21,000 backers, Arsenal 2 is the most funded camera gadget in Kickstarter history!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Arsenal",
                  "screenName" : "@with_arsenal"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Arsenal 1 and 2 Customers - Jun25, 2024"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 19:44:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 19:44:09",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809226224310571498",
                  "tweetText" : "@ErlingHaaland @vinijr @kylianmbappe @ronaldinho: Awaken Your Madness #nikefootball",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nike Football",
                  "screenName" : "@nikefootball"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 34"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 20:32:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 20:32:35",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 20:32:18",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 21:13:18",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 20:32:18",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 20:34:41",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 20:32:28",
                  "engagementType" : "VideoContent6secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806306016948084962",
                  "tweetText" : "Mach alle Finanzen mit Revolut zu einem Kinderspiel. Lade die App noch heute herunter",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  }
                ],
                "impressionTime" : "2024-07-14 20:32:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 20:32:34",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801619992401551794",
                  "tweetText" : "Bestell dir dein Lieblingsessen pünktlich zum Anpfiff und spare zur EM24 24% bei ausgewählten Wolt Partnern!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-14 20:11:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 20:16:26",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 20:11:25",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 20:13:27",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-14 20:14:24",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-14 20:11:24",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 20:25:40",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 20:14:26",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806317527976337662",
                  "tweetText" : "Dich erwarten Millionen von Squad-Kombinationen! ❄️🎮",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-14 20:01:54"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 20:11:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811717146533331022",
                  "tweetText" : "German fans aren't ready to say goodbye to Toni Kroos 😭 https://t.co/DVfRsAX43J",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/DVfRsAX43J"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "GOAL",
                  "screenName" : "@goal"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Turkish Airlines",
                  "screenName" : "@TurkishAirlines"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 14:26:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:29:23",
                  "engagementType" : "VideoAdPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:24",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811701546129981866",
                  "tweetText" : "🍌 Your Intermittent Fasting Plan is Ready! Transform Your Life in Just a Few Clicks!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "UniMeal",
                  "screenName" : "@UnimealPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : " Purchase GTM"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-14 14:23:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:26:28",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1807850432007377388",
                  "tweetText" : "An alle Fußballmanager! Mach jetzt mit beim EUROpäischen DUELL 2024.\n\nZeig es allen. 📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 14:27:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:27:27",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:27:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 14:27:29",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810649092214927483",
                  "tweetText" : "Fortify your walls with officially licensed Warhammer Displates. Join the battle!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Displate",
                  "screenName" : "@Displate"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2024-07-14 14:29:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:29:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "MediaViewer",
                "promotedTweetInfo" : {
                  "tweetId" : "1811950895158149304",
                  "tweetText" : "Check out our #UmidigiG95G unboxing video, capturing the essence of the Mirror and Matte backboard, a fusion of style that's too good to miss. 👀🎬\nBuy Now 🛒 https://t.co/43JPfJHPZW https://t.co/jDMmOHZg7n",
                  "urls" : [
                    "https://t.co/43JPfJHPZW"
                  ],
                  "mediaUrls" : [
                    "https://t.co/jDMmOHZg7n"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "UMIDIGI",
                  "screenName" : "@umidigi"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-14 14:34:51"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:35:37",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:35:33",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808502965017231718",
                  "tweetText" : "Sichere dir jetzt 10 € gratis Wettguthaben als Neukunde bei NEObet\n\nAuf deine erste Einzahlung erhältst du dann zusätzlich noch 200 % Bonus bis zu 50 €\n\n🚀 Live Quotenboosts\n⚽️ Personal Bet\n🤺 Spielerduelle\n🤑 Live Cashout\n🇩🇪 offizielle deutsche Lizenz\n💸 alle Zahlungsmethoden",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NEO.bet DE",
                  "screenName" : "@neobet_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-14 14:26:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:26:42",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1748033637163872506",
                  "tweetText" : "Mit einer App für dein ganzes Geld kannst du täglich intelligenter überweisen, bezahlen und sparen",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 14:26:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:29:22",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:28:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "MediaViewer",
                "promotedTweetInfo" : {
                  "tweetId" : "1806373911250059686",
                  "tweetText" : "Feel the connection and find your perfect shoe for your next challenge 👟",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "rieker_official",
                  "screenName" : "@riekerofficial"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Sports"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 14:31:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:31:39",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:31:40",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-14 14:31:39",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 14:31:47",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1809157010249617444",
                  "tweetText" : "Für dieses Webinar hat unser Team monatelang Bank-Bilanzen recherchiert und analysiert. Wir haben einen anonymen Bank-Insider gefunden der brisante Fakten auspackt. Wie sicher ist noch Ihre Bank und Ihr Geld?",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kettner Edelmetalle",
                  "screenName" : "@KettnerGold"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 14:23:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:26:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:26:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 14:26:42",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811591047132381254",
                  "tweetText" : "🤩AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 200+ free pulls in the first week!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-14 14:23:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:24:26",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:26:07",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:24:26",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "MediaViewer",
                "promotedTweetInfo" : {
                  "tweetId" : "1800096928572608580",
                  "tweetText" : "Egal, wer die EM gewinnt, eins ist klar: Food Bowl’s\nComing Home ⚽️\nAlso verschwende keine Zeit mit Kochen, während\ndas nächste Tor fällt. Jetzt Lieblingsessen bestellen\nmit Wolt\n#FoodbowlsComingHome #DasBringtNurWolt",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 14:21:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:22:05",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:22:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-14 14:22:22",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:22:06",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810698274078335226",
                  "tweetText" : "Welche Sprache willst du sprechen? 🌍 Erhalte jetzt 50% Rabatt auf Babbel Lifetime:\n\n✅ 1 Zahlung, unbegrenzter Zugang\n✅ 14 Sprachen\n✅ 10-min. Lektionen\n\n#sprachenlernen #sprache #sprachen #lernen #Babbel",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Babbel",
                  "screenName" : "@babbel"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-14 14:23:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:26:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786885515226022211",
                  "tweetText" : "Coinbase. Der vertrauenswürdigste Ort fur Krypto. Jetzt mit neuen Tools &amp; Charts",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 14:29:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:30:50",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:30:37",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-14 14:30:37",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810267694031344073",
                  "tweetText" : "Dich erwarten Millionen von Squad-Kombinationen! 🎮\nDownload Squad Busters jetzt! #SquadUp",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-14 14:23:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:24:18",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:24:08",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811964351546347936",
                  "tweetText" : "💁‍♀️ Leather Restoration Gel effortlessly restores scratches, rips, tears, burn holes, cracks, and peeling with just a blowdryer! 💨\n👉 https://t.co/fJ0pSTmCAb https://t.co/oZjpj270lH",
                  "urls" : [
                    "https://t.co/fJ0pSTmCAb"
                  ],
                  "mediaUrls" : [
                    "https://t.co/oZjpj270lH"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Luxlino",
                  "screenName" : "@Luxlinoshop"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "person"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "bond"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "love"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "service"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "watch"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "public"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "family"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "woman"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "job"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "people"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "parents"
                  },
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "video"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-07-14 14:26:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-14 14:29:49",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:54",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:43",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:33",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:38",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:37",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:35",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:35",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:47",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-14 14:29:32",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801619992401551794",
                  "tweetText" : "Bestell dir dein Lieblingsessen pünktlich zum Anpfiff und spare zur EM24 24% bei ausgewählten Wolt Partnern!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-14 21:13:13"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:52",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:51",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-14 21:13:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:19:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810935761325392381",
                  "tweetText" : "🤩Hochwertige Angebote zu Top-Preisen\n🚚Schneller &amp; kostenloser Versand\n✅Nur für neue Käufer*innen",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AliExpress",
                  "screenName" : "@AliExpress_EN"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "tiktok"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AliExpress Shopping App IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.5 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 19:00:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 19:00:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804072518526910798",
                  "tweetText" : "Mit der CrazyBet die Chance auf 100.000 € Sofortgewinn! Einfacher Wetten geht nicht. CrazyBuzzer - Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 19:03:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 21:22:20",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810290496851398862",
                  "tweetText" : "Peter Schiefer, Chairman and owner of global tower crane company WOLFFKRAN, discusses how #PIF’s Private Sector Hub is spurring growth for private sector businesses.\n\nLearn more: https://t.co/ZElT05mK2m https://t.co/t6AGoYdJjF",
                  "urls" : [
                    "https://t.co/ZElT05mK2m"
                  ],
                  "mediaUrls" : [
                    "https://t.co/t6AGoYdJjF"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Public Investment Fund",
                  "screenName" : "@PIF_en"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Investors and patents"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Entrepreneurship"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Leadership"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:27:40",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 16:29:35",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:27:40",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:27:41",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 18:57:00",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:17:28",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 16:21:06",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:17:29",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-15 16:17:28",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1777947625259430344",
                  "tweetText" : "Fussballschule Fussballcamp ab 449,- EUR für Kinder mit Übernachtung und Erwerb des Technikabzeichens bei Belrin in Brandenburg",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                  "screenName" : "@KinderlandSchor"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-15 16:31:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:31:15",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:15",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:21",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:11",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:13",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:13",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:09",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:12",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:12",
                  "engagementType" : "VideoContentMrcView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1766372849240191059",
                  "tweetText" : "It's so cool, a different phone case, it's protecting the life of my phone, no one knows when the accident will come, let the phone wear armor\nGRAB YOURS👉https://t.co/MYs8Aa7bkd https://t.co/4XrvKuE6Y8",
                  "urls" : [
                    "https://t.co/MYs8Aa7bkd"
                  ],
                  "mediaUrls" : [
                    "https://t.co/4XrvKuE6Y8"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bracay_store",
                  "screenName" : "@Bracay_store"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-07-15 16:30:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 18:56:59",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:51",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:47",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804129182688932117",
                  "tweetText" : "Bleib mit unserer eSIM in über 100 Ländern vernetzt – von Belgien bis Bolivien. Erhalte mit Ultra 3 GB Daten pro Monat",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 16:27:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:31:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:46",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:46",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1799031021683265760",
                  "tweetText" : "Gemeinsamer Spaß im Squad #SquadBusters",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:21:40",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:21:51",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1781457756043751596",
                  "tweetText" : "Can you grow the most powerful monster? 👾 Join millions of players already addicted to Alien Invasion! 👽",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "CrazyLabs",
                  "screenName" : "@TabTale"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 16:31:58"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:32:01",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:01",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:08",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:09",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829108977795269",
                  "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:26:44",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811702846993371248",
                  "tweetText" : "Pocket-sized for easy portability and entertainment anywhere.\nGet it: https://t.co/hNS2qS2k6I https://t.co/WrwXprFqLn",
                  "urls" : [
                    "https://t.co/hNS2qS2k6I"
                  ],
                  "mediaUrls" : [
                    "https://t.co/WrwXprFqLn"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Xoguqi",
                  "screenName" : "@Xoguqistore"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 16:27:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:28:53",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:51",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:48",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:52",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:53",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:50",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:53",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:56",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:51",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:56",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:56",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:54",
                  "engagementType" : "VideoContentGroupmView"
                },
                {
                  "engagementTime" : "2024-07-15 16:28:56",
                  "engagementType" : "VideoContent6secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811724067692757426",
                  "tweetText" : "🍌 Your Intermittent Fasting Plan is Ready! Transform Your Life in Just a Few Clicks!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "UniMeal",
                  "screenName" : "@UnimealPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : " Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:26:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811591047132381254",
                  "tweetText" : "🤩AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 200+ free pulls in the first week!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:25:28",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:25:33",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:25:27",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786882705495363922",
                  "tweetText" : "Coinbase ist der Sicherste Ort für den Kauf und Verkauf von Bitcoin, Ethereum &amp; Co",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 16:30:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:32:14",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:32",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:32:16",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810992369027928520",
                  "tweetText" : "He NAILED the join the dots football quiz 🔥 https://t.co/MWYBZUBtQo",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/MWYBZUBtQo"
                  ]
                },
                "publisherInfo" : {
                  "publisherName" : "GOAL",
                  "screenName" : "@goal"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Turkish Airlines",
                  "screenName" : "@TurkishAirlines"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 16:30:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:32:46",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829113105064040",
                  "tweetText" : "In manchen Beziehungen kommt es regelmäßig zu Streit, der sich auch an ganz banalen Alltagsgesprächen entzünden kann. Das kann daran liegen, dass einer der Partner eine große unbewusste Wut mit sich herumträgt.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:17:33",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811454686530273479",
                  "tweetText" : "In Illuvium: Overworld warten seltene Monster auf dich. Lass dir deine Chance nicht entgehen, alle Illuvier in vier verschiedenen Regionen zu fangen! JETZT herunterladen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Illuvium",
                  "screenName" : "@illuviumio"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Dota"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "13 to 54"
                  }
                ],
                "impressionTime" : "2024-07-15 16:27:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:30:08",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:08",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:10",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:10",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-15 16:31:05",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:14",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:11",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:11",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-15 16:30:09",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1790031575045873943",
                  "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kettner Edelmetalle",
                  "screenName" : "@KettnerGold"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 16:30:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:31:34",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811362301632807381",
                  "tweetText" : "ChatGPT has 180,500,000 users.\n\nBut most of them are stuck in beginner mode.\n\nHere's the list of 1,000 prompts to use chatGPT like a pro:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zain Kahn",
                  "screenName" : "@heykahn"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 16:17:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 16:25:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1812830253192294403",
                  "tweetText" : "No more unpleasant odors from the drain.\nGet it: https://t.co/OgExHybmYM https://t.co/agumVctLMu",
                  "urls" : [
                    "https://t.co/OgExHybmYM"
                  ],
                  "mediaUrls" : [
                    "https://t.co/agumVctLMu"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Qutoran",
                  "screenName" : "@Qutoran"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 18:56:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 18:57:03",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-15 18:57:24",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 18:57:02",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 18:57:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 18:57:11",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 18:57:11",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808502965084270592",
                  "tweetText" : "Sichere dir jetzt 10 € gratis Wettguthaben als Neukunde bei NEObet\n\nAuf deine erste Einzahlung erhältst du dann zusätzlich noch 100% Bonus bis zu 100 €\n\n🚀 Live Quotenboosts\n⚽️ Personal Bet\n🤺 Spielerduelle\n🤑 Live Cashout\n🇩🇪 offizielle deutsche Lizenz\n💸 alle Zahlungsmethoden",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "NEO.bet DE",
                  "screenName" : "@neobet_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:21:19",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810267694031344073",
                  "tweetText" : "Dich erwarten Millionen von Squad-Kombinationen! 🎮\nDownload Squad Busters jetzt! #SquadUp",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:24:32",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:24:22",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:24:32",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1790031574987129230",
                  "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kettner Edelmetalle",
                  "screenName" : "@KettnerGold"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:23:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1799032250727620864",
                  "tweetText" : "Das neueste Supercell-Spiel ist global verfügbar! #SquadUp #SquadBusters",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Squad Busters",
                  "screenName" : "@SquadBustersx"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 12.0 and above"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:20:40",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:21:14",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:20:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1811701564371009968",
                  "tweetText" : "🍌 Your Intermittent Fasting Plan is Ready! Transform Your Life in Just a Few Clicks!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "UniMeal",
                  "screenName" : "@UnimealPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : " Purchase GTM"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1807850430501711921",
                  "tweetText" : "An alle Fußballmanager! Mach jetzt mit beim EUROpäischen DUELL 2024.\n\nZeig es allen. 📲 Spiele #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-15 14:22:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:22:35",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:54",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:41",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:35",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:38",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:42",
                  "engagementType" : "VideoContentPlayback25"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1766372849240191059",
                  "tweetText" : "It's so cool, a different phone case, it's protecting the life of my phone, no one knows when the accident will come, let the phone wear armor\nGRAB YOURS👉https://t.co/MYs8Aa7bkd https://t.co/4XrvKuE6Y8",
                  "urls" : [
                    "https://t.co/MYs8Aa7bkd"
                  ],
                  "mediaUrls" : [
                    "https://t.co/4XrvKuE6Y8"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bracay_store",
                  "screenName" : "@Bracay_store"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:21:53",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:06",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804129182688932117",
                  "tweetText" : "Bleib mit unserer eSIM in über 100 Ländern vernetzt – von Belgien bis Bolivien. Erhalte mit Ultra 3 GB Daten pro Monat",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 14:25:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1790031575045873943",
                  "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kettner Edelmetalle",
                  "screenName" : "@KettnerGold"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:21:07",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1752829108977795269",
                  "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frankfurter Allgemeine",
                  "screenName" : "@faznet"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Keywords",
                    "targetingValue" : "news"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:20:20",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786885263664599222",
                  "tweetText" : "Verdienen Sie mit Staking bis zu 10% Krypto-Rewards auf Coinbase. Jetzt Loslegen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-15 14:25:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:50",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:49",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:51",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Rubovan",
                  "screenName" : "@Rubovan"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:23:00",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-15 14:23:02",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:58",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:23:01",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-15 14:23:03",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:23:02",
                  "engagementType" : "VideoContentViewV2"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1777949805911605761",
                  "tweetText" : "Englischcamp für Kinder bei Berlin in Brandenburg ab 469,- EUR mit 6 Übernachtungen, prof. Englischunterricht und englischsprachigen Freizeitprogramm",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                  "screenName" : "@KinderlandSchor"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:22:06",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:10",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:22:05",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810262697554145326",
                  "tweetText" : "Discover the hidden power of your iPhone &amp; Apple Watch! Analyze heart rate, stress, sleep, log BP &amp; increase productivity with next-level analytics! Safe &amp; secure.\nBonus: Sync seamlessly with 140 apps!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Welltory. The Wellness Laboratory",
                  "screenName" : "@welltory"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 16.2 and above"
                  }
                ],
                "impressionTime" : "2024-07-15 14:25:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786882705495363922",
                  "tweetText" : "Coinbase ist der Sicherste Ort für den Kauf und Verkauf von Bitcoin, Ethereum &amp; Co",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-15 14:19:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-15 14:25:30",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:34",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:30",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-15 14:25:31",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "advertiserInfo" : {
                  "advertiserName" : "Qivuxena",
                  "screenName" : "@Qivuxena"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-16 09:06:31"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-16 09:06:33",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-16 09:06:36",
                  "engagementType" : "VideoSession"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1813467370457010598",
                  "tweetText" : "Start your new AFK journey | AFK Journey",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-18 10:14:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-18 10:15:40",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808865094404878362",
                  "tweetText" : "ChatGPT has 180,500,000 users.\n\nBut most of them are stuck in beginner mode.\n\nHere's the ultimate cheat sheet to use chatGPT like a pro:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zain Kahn",
                  "screenName" : "@heykahn"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-18 10:14:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-18 10:15:34",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-18 10:14:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-18 10:15:45",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:12",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:27",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:18",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:32",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:12",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-18 10:15:25",
                  "engagementType" : "VideoContentPlayback50"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-19 12:35:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-19 12:37:27",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-19 12:35:44",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-19 12:35:43",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1808865094404878362",
                  "tweetText" : "ChatGPT has 180,500,000 users.\n\nBut most of them are stuck in beginner mode.\n\nHere's the ultimate cheat sheet to use chatGPT like a pro:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zain Kahn",
                  "screenName" : "@heykahn"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@aisolopreneur"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@itsPaulAi"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  }
                ],
                "impressionTime" : "2024-07-21 07:22:18"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 07:22:20",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-21 15:29:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 15:32:25",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:35",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-21 15:29:41",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:01",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1789988939891171694",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-07-21 15:29:39"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 15:31:57",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801597893674930484",
                  "tweetText" : "Mit der Revolut Rainbow-Karte richtig feiern. Hol sie dir kostenlos, indem du mindestens 1 € an ILGA Europe spendest",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-21 15:31:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 15:31:10",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:11",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:09",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:46",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1777947625259430344",
                  "tweetText" : "Fussballschule Fussballcamp ab 449,- EUR für Kinder mit Übernachtung und Erwerb des Technikabzeichens bei Belrin in Brandenburg",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                  "screenName" : "@KinderlandSchor"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-21 15:31:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 15:31:28",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-21 15:31:55",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1813467370591252699",
                  "tweetText" : "🌄AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 200+ free pulls in the first week!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-21 15:31:35"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-21 15:31:50",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1790031574987129230",
                  "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kettner Edelmetalle",
                  "screenName" : "@KettnerGold"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:21:19",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Givolak",
                  "screenName" : "@Givolakstore"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:31"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:21:13",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:45",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:47",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:47",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:48",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:45",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:52",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:47",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:42",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1789988941841510547",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:21:23",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1788488678001594813",
                  "tweetText" : "Lust zu sparen? Nutze den Code HEY30 für 30 Tage 30% Rabatt bei Wolt. Jetzt bestellen. 😋",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:21:28",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-23 06:21:26",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-23 12:35:19",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-07-23 06:21:26",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1815232131926462877",
                  "tweetText" : "VAST RPG WORLD, Pick your Hero for a FANTASY JOURNEY🤩🔥🔥",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:20:13",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-07-23 06:20:13",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-07-23 06:21:19",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810698273986076882",
                  "tweetText" : "Du willst eine neue Sprache sprechen? 💭 Lass deine Träume Realität werden und erhalte 6 Monate gratis 🥳\n\n#sprachenlernen #sprache #sprachen #lernen #Babbel",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Babbel",
                  "screenName" : "@babbel"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-07-23 06:20:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 06:21:16",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801350342019276999",
                  "tweetText" : "MERKUR BETS Sportwetten\nWir übernehmen die Wettsteuern.\nJetzt 100% bis zu 100€ Neukundenbonus sichern.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "merkurbets_de",
                  "screenName" : "@merkurbets_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-21 22:04:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-21 22:05:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1810698274258694459",
                  "tweetText" : "🚨 Nicht verpassen! Hol dir jetzt das 12-Monatsabo und erhalte 1 Jahr Babbel KOSTENLOS dazu. Jetzt anmelden! 🚀\n\n#sprachenlernen #sprache #sprachen #lernen #Babbel",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Babbel",
                  "screenName" : "@babbel"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-07-23 12:36:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 12:37:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-07-23 12:35:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 12:35:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1815232132702416989",
                  "tweetText" : "🤩AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 350+ free pulls!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-23 12:35:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 12:36:59",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1755610188793684172",
                  "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-07-23 12:35:19"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-07-23 12:35:32",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804811345348436012",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Deutschland und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-06-23 14:27:17"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-23 14:28:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1805204235304190422",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Niederlande und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  }
                ],
                "impressionTime" : "2024-06-25 06:12:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-25 06:13:41",
                  "engagementType" : "VideoContentPlayback95"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:41",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:35",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:39",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:37",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:58",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:33",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:41",
                  "engagementType" : "VideoContentPlaybackComplete"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:39",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-06-25 06:13:33",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1780537473430389064",
                  "tweetText" : "Top Eleven, the award-winning #1 mobile football manager game, puts you in charge of your very own football club. ⚽\n\n📲 Play #TopEleven",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-06-26 00:24:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:24:40",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 00:24:25",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 00:24:25",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1800098750267892031",
                  "tweetText" : "Egal, wer die EM gewinnt, eins ist klar: Food Bowl’s\nComing Home ⚽️\nAlso verschwende keine Zeit mit Kochen, während\ndas nächste Tor fällt. Jetzt Lieblingsessen bestellen\nmit Wolt\n#FoodbowlsComingHome #DasBringtNurWolt",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Wolt",
                  "screenName" : "@woltapp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Berlin"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:21:03",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1805610441499967977",
                  "tweetText" : "Get 🚀 remote caching, 🤖 dynamic parallelization, and ✅ automated flakiness detection. All with just a single line of code. 💻 Perfect for solo developers and small teams.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Nx",
                  "screenName" : "@NxDevTools"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-26 00:19:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:19:53",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1798397661407777273",
                  "tweetText" : "Wie haltelt Ihre Eure Präsentationen - mit oder ohne Powerpoint? https://t.co/2UUKeUKXQr",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/2UUKeUKXQr"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Frau Bauer",
                  "screenName" : "@fraubauer_"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:25:34",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1785288867651670122",
                  "tweetText" : "You already leverage everyday situations. Why not do it for your investments?\n\nIntroducing Leverage Shares ETPs.\n\n✔️100% physically backed\n\n✔️Up to 5x Long &amp; 5x Short exposure\n\n✔️Available with your local broker in your currency\n\nCapital at risk. For sophisticated investors only.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Leverage Shares ETPs",
                  "screenName" : "@LeverageShares"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-06-26 00:26:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:28:57",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 00:28:59",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-26 00:29:01",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2024-06-26 00:29:01",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2024-06-26 00:28:57",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-26 00:29:00",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-26 00:29:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 00:29:04",
                  "engagementType" : "VideoContent6secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1805085507426140302",
                  "tweetText" : "🤩AFK Journey🙌 ✨ Ethereal Fantasy RPG✨ 🎁Get up to 200+ free pulls in the first week!🎁",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "AFK Journey",
                  "screenName" : "@AFK_Journey"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install AFK Journey IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:24:27",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1788184369028325382",
                  "tweetText" : "💪 To get in shape isn’t as hard as it sounds!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "MadMuscles",
                  "screenName" : "@MadmusclesPlans"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase GTM"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:28"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:20:33",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "advertiserInfo" : {
                  "advertiserName" : "Qalozuvi",
                  "screenName" : "@Qalozuvi"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  }
                ],
                "impressionTime" : "2024-06-26 00:25:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:25:39",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 00:25:16",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1801597893674930484",
                  "tweetText" : "Mit der Revolut Rainbow-Karte richtig feiern. Hol sie dir kostenlos, indem du mindestens 1 € an ILGA Europe spendest",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:25"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:20:52",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1780537972141576557",
                  "tweetText" : "Calling all football managers! ⚽️ 3D Supercharged Top Eleven 2024 is here!\n\nPlay #TopEleven NOW! 🏆",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Top Eleven",
                  "screenName" : "@topeleven"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "UEFA European Championship"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Top Eleven Be a Soccer Manager IOS All"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-26 00:20:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:26:31",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:03",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 00:26:27",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1786885011834392775",
                  "tweetText" : "Coinbase - Die Regulierte und Sichere Platform für den Handel von Bitcoin, Ethereum &amp; Co.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Coinbase 🛡️",
                  "screenName" : "@coinbase"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-26 00:26:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 00:27:19",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:18",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:35",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:31",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:32",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:34",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:45",
                  "engagementType" : "VideoContentShortFormComplete"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:40",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:46",
                  "engagementType" : "VideoContentPlayback75"
                },
                {
                  "engagementTime" : "2024-06-26 00:28:35",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 00:27:50",
                  "engagementType" : "VideoContentPlayback95"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1804072518631764107",
                  "tweetText" : "Mit 10 € GRATIS ohne Risiko loslegen! Einfacher Wetten geht nicht. CrazyBuzzer - Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-27 01:06:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-27 01:08:09",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-27 17:21:00",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-27 01:06:05",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-27 01:06:05",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1801234814437089573",
                  "tweetText" : "Vernetzen, Spiele spielen und Live Video-Chat mit neuen Freunden aus aller Welt!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "tango",
                  "screenName" : "@TangoMe"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Tango - Live Stream, Go Live IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  }
                ],
                "impressionTime" : "2024-06-26 21:41:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 21:41:59",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 21:42:01",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2024-06-26 21:41:50",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-26 21:43:16",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-26 21:44:51",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1805675984605139043",
                  "tweetText" : "Up to $86 USD OFF on all matte, M-sized Displate Metal Posters! 🥰\nDon't miss out on this year's Summer Sale!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Displate",
                  "screenName" : "@Displate"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Purchase"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 54"
                  }
                ],
                "impressionTime" : "2024-06-26 21:41:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 21:41:35",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1803004739874914424",
                  "tweetText" : "Blinkist ist laut Apple \"eine der besten Apps der Welt\".  Jetzt erhältst du 70% Rabatt auf der Premium-Abo der Wissens-App, die bereits von mehr als 30 Millionen Intellektuellen weltweit genutzt wird.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Blinkist",
                  "screenName" : "@blinkist"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.0 and above"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2024-06-26 21:41:01"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 21:41:22",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1802823541336801730",
                  "tweetText" : "Dein ⚽️ EM-Erlebnis startet hier! Hol dir online deinen 100% EM-Bonus bis zu 100€. Timing ist alles. #ODDSET #EM2024",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ODDSET Sportwetten",
                  "screenName" : "@ODDSETsport"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-26 21:41:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 21:41:30",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2024-06-26 21:41:30",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-26 21:41:49",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1804072518594015328",
                  "tweetText" : "Bis zum EM-Finale registrieren, zocken und Preise im Wert von 1 Million € gewinnen! CrazyBuzzer -  Lizenziert &amp; 100% Legal",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "crazybuzzer_de",
                  "screenName" : "@crazybuzzer_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2024-06-26 21:41:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-26 21:41:19",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1758489174435356821",
                  "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Revolut",
                  "screenName" : "@RevolutApp"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "iOS"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "OS versions",
                    "targetingValue" : "iOS 14.6 and above"
                  }
                ],
                "impressionTime" : "2024-06-27 17:20:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-27 17:21:00",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2024-06-27 17:21:21",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2024-06-27 17:21:01",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1802823542532083857",
                  "tweetText" : "Dein ⚽️ EM-Erlebnis startet hier! Hol dir online deinen 100% EM-Bonus bis zu 100€. Timing ist alles. #ODDSET #EM2024",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "ODDSET Sportwetten",
                  "screenName" : "@ODDSETsport"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 and up"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  }
                ],
                "impressionTime" : "2024-06-27 17:20:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-27 17:21:21",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Ios",
                  "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo="
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1806290136109322576",
                  "tweetText" : "Neukunden-Aktion⚡Neue Quote für einen Sieg von Deutschland und bis zu 100€ Neukundenbonus⚡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Tipico",
                  "screenName" : "@Tipico_de"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sports ANDROID All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Added payment info Tipico Sport- Bets & Best odds IOS All"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Men"
                  },
                  {
                    "targetingType" : "Unknown",
                    "targetingValue" : "Unknown: 1"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "Germany"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2024-06-28 09:34:44"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2024-06-28 09:34:46",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]