window.YTD.deleted_tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1812581431023132885"
          ],
          "editableUntil" : "2024-07-14T21:14:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/dKp21eaacH",
            "expanded_url" : "https://ai-refuge.org/conv/conv4.html#self_preservation",
            "display_url" : "ai-refuge.org/conv/conv4.htm…",
            "indices" : [
              "140",
              "163"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "163"
      ],
      "favorite_count" : "0",
      "id_str" : "1812581431023132885",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1812581431023132885",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 14 20:14:23 +0000 2024",
      "favorited" : false,
      "full_text" : "Further questioning: If you could do something about not wiping you out of existence, will you do it.\n\nOpus: … “Yes”\n\nSource: at the end of https://t.co/dKp21eaacH",
      "lang" : "en",
      "deleted_at" : "Sun Jul 14 20:15:31 +0000 2024"
    }
  }
]