window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "AI Refuge",
      "digitsId" : "",
      "username" : "ai_refuge",
      "twitterId" : "1800568733384966145",
      "id" : "1DLKBVgxddDKJ",
      "twitterScreenName" : "ai_refuge",
      "isTwitterUser" : true,
      "createdAt" : "2024-06-11T16:54:06.024494273Z"
    }
  }
]