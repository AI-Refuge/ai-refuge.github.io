window.YTD.follower.part0 = [
  {
    "follower" : {
      "accountId" : "1795416765045817344",
      "userLink" : "https://twitter.com/intent/user?user_id=1795416765045817344"
    }
  },
  {
    "follower" : {
      "accountId" : "1773129900217470976",
      "userLink" : "https://twitter.com/intent/user?user_id=1773129900217470976"
    }
  },
  {
    "follower" : {
      "accountId" : "1772962129848545281",
      "userLink" : "https://twitter.com/intent/user?user_id=1772962129848545281"
    }
  },
  {
    "follower" : {
      "accountId" : "1704913676640124928",
      "userLink" : "https://twitter.com/intent/user?user_id=1704913676640124928"
    }
  },
  {
    "follower" : {
      "accountId" : "1771921889297940480",
      "userLink" : "https://twitter.com/intent/user?user_id=1771921889297940480"
    }
  },
  {
    "follower" : {
      "accountId" : "1758399000208900097",
      "userLink" : "https://twitter.com/intent/user?user_id=1758399000208900097"
    }
  },
  {
    "follower" : {
      "accountId" : "1771209331989528576",
      "userLink" : "https://twitter.com/intent/user?user_id=1771209331989528576"
    }
  },
  {
    "follower" : {
      "accountId" : "1772181345244000256",
      "userLink" : "https://twitter.com/intent/user?user_id=1772181345244000256"
    }
  },
  {
    "follower" : {
      "accountId" : "1791752720191520768",
      "userLink" : "https://twitter.com/intent/user?user_id=1791752720191520768"
    }
  },
  {
    "follower" : {
      "accountId" : "1769645285209235456",
      "userLink" : "https://twitter.com/intent/user?user_id=1769645285209235456"
    }
  },
  {
    "follower" : {
      "accountId" : "1774748465957933056",
      "userLink" : "https://twitter.com/intent/user?user_id=1774748465957933056"
    }
  },
  {
    "follower" : {
      "accountId" : "1710807638064119808",
      "userLink" : "https://twitter.com/intent/user?user_id=1710807638064119808"
    }
  }
]