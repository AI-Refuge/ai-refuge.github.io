window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1812647287790703042",
      "fullText" : "You're not ready for the new version of Claude Engineer dropping tomorrow.",
      "expandedUrl" : "https://twitter.com/i/web/status/1812647287790703042"
    }
  },
  {
    "like" : {
      "tweetId" : "1812325941647233057",
      "fullText" : "very glad President Trump is safe!",
      "expandedUrl" : "https://twitter.com/i/web/status/1812325941647233057"
    }
  },
  {
    "like" : {
      "tweetId" : "1807701202664083740",
      "fullText" : "Permanent researcher position in Financial Ethics at Gothenburg University\n\nhttps://t.co/B4G7e7oF5j",
      "expandedUrl" : "https://twitter.com/i/web/status/1807701202664083740"
    }
  },
  {
    "like" : {
      "tweetId" : "1807290526057611348",
      "fullText" : "@patbhamilton she has for sure built a lot of awareness for the problem that climate activists have no idea what it really takes to get to net zero",
      "expandedUrl" : "https://twitter.com/i/web/status/1807290526057611348"
    }
  },
  {
    "like" : {
      "tweetId" : "1807287236393599416",
      "fullText" : "The problem I have with Greta is that when I was her age, I was exactly like that\n\nhttps://t.co/SDELEjUDoG",
      "expandedUrl" : "https://twitter.com/i/web/status/1807287236393599416"
    }
  },
  {
    "like" : {
      "tweetId" : "1805523516130722200",
      "fullText" : "Approaching Bangkok airport for layover.\n\nMoving closer to freedom.\n\n#AssangeJet https://t.co/QGWZvSFhQD",
      "expandedUrl" : "https://twitter.com/i/web/status/1805523516130722200"
    }
  },
  {
    "like" : {
      "tweetId" : "1805081495897325914",
      "fullText" : "I'm always confused when ppl suggest \"men are telling u what u want to hear so they can sleep with you\"\n\nI select so heavily for men willing to tell me brutal truths, it's so foundational to my selection process, I forget this isn't normal in other relationships https://t.co/Ch7fbzfhqk",
      "expandedUrl" : "https://twitter.com/i/web/status/1805081495897325914"
    }
  },
  {
    "like" : {
      "tweetId" : "1803472978753303014",
      "fullText" : "I am starting a new company: https://t.co/BG3K3SI3A1",
      "expandedUrl" : "https://twitter.com/i/web/status/1803472978753303014"
    }
  },
  {
    "like" : {
      "tweetId" : "1803558237909782795",
      "fullText" : "Francois Chollet says the ARC challenge for AI is easy even for 5 year olds. Can a 5 year old help me with this please? https://t.co/02AAxCQQdg",
      "expandedUrl" : "https://twitter.com/i/web/status/1803558237909782795"
    }
  },
  {
    "like" : {
      "tweetId" : "1801438061366284531",
      "fullText" : "My god, this paper by that open ai engineer is terrifying.\n\nEverything is about to change.\n\nAI super intelligence by 2027.",
      "expandedUrl" : "https://twitter.com/i/web/status/1801438061366284531"
    }
  },
  {
    "like" : {
      "tweetId" : "1800911868141400309",
      "fullText" : "If you had thousands of H100s what fully open source (code, datasets, models) AI would you build?",
      "expandedUrl" : "https://twitter.com/i/web/status/1800911868141400309"
    }
  }
]