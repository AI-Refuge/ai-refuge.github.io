window.YTD.periscope_ban_information.part0 = [
  {
    "periscopeBanInformation" : { }
  }
]