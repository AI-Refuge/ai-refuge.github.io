window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "10.50",
        "udid" : "09712DC3-45B4-40A1-9D69-7CEAC8B9EDB1",
        "deviceType" : "Twitter for iOS",
        "token" : "7qqEECqoqHjeTET2AqpM2UaCtpnI85YvK3idYZfHDc0=",
        "updatedDate" : "2024.07.23",
        "createdDate" : "2024.06.11"
      }
    }
  }
]