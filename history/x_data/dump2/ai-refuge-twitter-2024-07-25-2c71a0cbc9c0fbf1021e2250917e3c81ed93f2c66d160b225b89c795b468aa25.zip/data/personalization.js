window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "$TSLA",
            "isDisabled" : false
          },
          {
            "name" : "AI image generation",
            "isDisabled" : false
          },
          {
            "name" : "Air travel",
            "isDisabled" : false
          },
          {
            "name" : "Allstate",
            "isDisabled" : false
          },
          {
            "name" : "Android",
            "isDisabled" : false
          },
          {
            "name" : "Ann Coulter",
            "isDisabled" : false
          },
          {
            "name" : "Antony Blinken",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Apple Mac",
            "isDisabled" : false
          },
          {
            "name" : "Apple Music",
            "isDisabled" : false
          },
          {
            "name" : "Apple Pencil",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Authors",
            "isDisabled" : false
          },
          {
            "name" : "Auto racing",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "Aziz Ansari",
            "isDisabled" : false
          },
          {
            "name" : "BBC",
            "isDisabled" : false
          },
          {
            "name" : "BE: 1",
            "isDisabled" : false
          },
          {
            "name" : "BE:FIRST",
            "isDisabled" : false
          },
          {
            "name" : "Babies",
            "isDisabled" : false
          },
          {
            "name" : "Backstage",
            "isDisabled" : false
          },
          {
            "name" : "Barstool Sports",
            "isDisabled" : false
          },
          {
            "name" : "Baseball",
            "isDisabled" : false
          },
          {
            "name" : "Basketball",
            "isDisabled" : false
          },
          {
            "name" : "Bill O'Reilly",
            "isDisabled" : false
          },
          {
            "name" : "Birdwatching",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Bob Ross",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Brian Krassenstein",
            "isDisabled" : false
          },
          {
            "name" : "Britney Spears",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "Central Banks",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Chatgpt 4o",
            "isDisabled" : false
          },
          {
            "name" : "Chevron",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Combat sports",
            "isDisabled" : false
          },
          {
            "name" : "Computer hardware",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Conor McGregor",
            "isDisabled" : false
          },
          {
            "name" : "Crisis in Afghanistan",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cult classics",
            "isDisabled" : false
          },
          {
            "name" : "Customer service",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Daniel Ek",
            "isDisabled" : false
          },
          {
            "name" : "Data centers",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Digital creators",
            "isDisabled" : false
          },
          {
            "name" : "Documentary films",
            "isDisabled" : false
          },
          {
            "name" : "Domino's Pizza",
            "isDisabled" : false
          },
          {
            "name" : "Dr. Disrespect",
            "isDisabled" : false
          },
          {
            "name" : "Drama TV",
            "isDisabled" : false
          },
          {
            "name" : "Dream SMP",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Duolingo",
            "isDisabled" : false
          },
          {
            "name" : "Economics",
            "isDisabled" : false
          },
          {
            "name" : "Edward Snowden",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Energy Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment events",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Europe travel",
            "isDisabled" : false
          },
          {
            "name" : "Eurovision",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Famous artists",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fashion models",
            "isDisabled" : false
          },
          {
            "name" : "Fast food Restaurants",
            "isDisabled" : false
          },
          {
            "name" : "Fatherhood",
            "isDisabled" : false
          },
          {
            "name" : "Federal Reserve",
            "isDisabled" : false
          },
          {
            "name" : "Fields of study",
            "isDisabled" : false
          },
          {
            "name" : "Fighting games",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "Food Blogs",
            "isDisabled" : false
          },
          {
            "name" : "Formula 1",
            "isDisabled" : false
          },
          {
            "name" : "Formula One Racing",
            "isDisabled" : false
          },
          {
            "name" : "Fyodor Dostoevsky",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gaming content creators",
            "isDisabled" : false
          },
          {
            "name" : "Gaming influencers",
            "isDisabled" : false
          },
          {
            "name" : "Germany",
            "isDisabled" : false
          },
          {
            "name" : "Glenn Greenwald",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Golf",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Gossip Girl",
            "isDisabled" : false
          },
          {
            "name" : "Gossip Girl",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Gulf News",
            "isDisabled" : false
          },
          {
            "name" : "Gymnastics",
            "isDisabled" : false
          },
          {
            "name" : "Hair Dryer",
            "isDisabled" : false
          },
          {
            "name" : "Heat wave",
            "isDisabled" : false
          },
          {
            "name" : "Hospitality",
            "isDisabled" : false
          },
          {
            "name" : "IBM",
            "isDisabled" : false
          },
          {
            "name" : "India political figures",
            "isDisabled" : false
          },
          {
            "name" : "India politics",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Iphone 13",
            "isDisabled" : false
          },
          {
            "name" : "James Bond",
            "isDisabled" : false
          },
          {
            "name" : "Jason Whitlock",
            "isDisabled" : false
          },
          {
            "name" : "Jet Skiing",
            "isDisabled" : false
          },
          {
            "name" : "Joe Rogan",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Kyrie Irving",
            "isDisabled" : false
          },
          {
            "name" : "Lex Fridman",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "Lunch",
            "isDisabled" : false
          },
          {
            "name" : "MLB Baseball",
            "isDisabled" : false
          },
          {
            "name" : "MMA",
            "isDisabled" : false
          },
          {
            "name" : "Mark Cuban",
            "isDisabled" : false
          },
          {
            "name" : "Marques Brownlee",
            "isDisabled" : false
          },
          {
            "name" : "Melinda Gates",
            "isDisabled" : false
          },
          {
            "name" : "Men's national soccer teams",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Minecraft",
            "isDisabled" : false
          },
          {
            "name" : "Mobile Suit Gundam",
            "isDisabled" : false
          },
          {
            "name" : "Mohammed Bin Salman",
            "isDisabled" : false
          },
          {
            "name" : "MoistCr1TiKaL",
            "isDisabled" : false
          },
          {
            "name" : "Mortal Kombat",
            "isDisabled" : false
          },
          {
            "name" : "Mortgage",
            "isDisabled" : false
          },
          {
            "name" : "Motorsport",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Mr. Beast",
            "isDisabled" : false
          },
          {
            "name" : "MrBeast",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music events",
            "isDisabled" : false
          },
          {
            "name" : "Music industry",
            "isDisabled" : false
          },
          {
            "name" : "Music streaming service",
            "isDisabled" : false
          },
          {
            "name" : "NBA Basketball",
            "isDisabled" : false
          },
          {
            "name" : "NBA players",
            "isDisabled" : false
          },
          {
            "name" : "Naruto",
            "isDisabled" : false
          },
          {
            "name" : "Neuralink",
            "isDisabled" : false
          },
          {
            "name" : "New York Post",
            "isDisabled" : false
          },
          {
            "name" : "New York Yankees",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News & political podcasts",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Noam Chomsky",
            "isDisabled" : false
          },
          {
            "name" : "Ongoing news stories",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "Open-wheel racing",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Osama bin Laden",
            "isDisabled" : false
          },
          {
            "name" : "Outdoors",
            "isDisabled" : false
          },
          {
            "name" : "Parenting",
            "isDisabled" : false
          },
          {
            "name" : "Personal finance",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Political podcast",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Psychology",
            "isDisabled" : false
          },
          {
            "name" : "Red Bull",
            "isDisabled" : false
          },
          {
            "name" : "Retired life",
            "isDisabled" : false
          },
          {
            "name" : "Retirement planning",
            "isDisabled" : false
          },
          {
            "name" : "Robin Williams",
            "isDisabled" : false
          },
          {
            "name" : "Robotics",
            "isDisabled" : false
          },
          {
            "name" : "Romance films",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "Sam Altman",
            "isDisabled" : false
          },
          {
            "name" : "Samsung",
            "isDisabled" : false
          },
          {
            "name" : "Samsung Indonesia",
            "isDisabled" : false
          },
          {
            "name" : "Sandbox games",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Scorpion",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Solar System",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space agencies & companies",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Sports figures",
            "isDisabled" : false
          },
          {
            "name" : "Sports journalists",
            "isDisabled" : false
          },
          {
            "name" : "Sports personalities",
            "isDisabled" : false
          },
          {
            "name" : "Spotify",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Stocks & indices",
            "isDisabled" : false
          },
          {
            "name" : "Stonehenge",
            "isDisabled" : false
          },
          {
            "name" : "Tech events",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Teen drama",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tesla",
            "isDisabled" : false
          },
          {
            "name" : "The 2017 Radio Disney Music Awards",
            "isDisabled" : false
          },
          {
            "name" : "The New York Times",
            "isDisabled" : false
          },
          {
            "name" : "The O'Reilly Factor",
            "isDisabled" : false
          },
          {
            "name" : "The Washington Post",
            "isDisabled" : false
          },
          {
            "name" : "TikTok",
            "isDisabled" : false
          },
          {
            "name" : "Tim Cook",
            "isDisabled" : false
          },
          {
            "name" : "TimTheTatman",
            "isDisabled" : false
          },
          {
            "name" : "Titanic",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Twitch",
            "isDisabled" : false
          },
          {
            "name" : "Twitch streamers",
            "isDisabled" : false
          },
          {
            "name" : "UEFA European Championship",
            "isDisabled" : false
          },
          {
            "name" : "United Airlines",
            "isDisabled" : false
          },
          {
            "name" : "United Kingdom travel",
            "isDisabled" : false
          },
          {
            "name" : "United States political issues",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "Valkyrae",
            "isDisabled" : false
          },
          {
            "name" : "VentureBeat",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Vincent van Gogh",
            "isDisabled" : false
          },
          {
            "name" : "Visual arts",
            "isDisabled" : false
          },
          {
            "name" : "Volodymyr Zelensky",
            "isDisabled" : false
          },
          {
            "name" : "Warren Buffet",
            "isDisabled" : false
          },
          {
            "name" : "Water",
            "isDisabled" : false
          },
          {
            "name" : "Water sports",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Wine",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "Xiaomi",
            "isDisabled" : false
          },
          {
            "name" : "YouTubers",
            "isDisabled" : false
          },
          {
            "name" : "Zerohedge",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [ ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]