window.YTD.email_address_change.part0 = [
  {
    "emailAddressChange" : {
      "accountId" : "1356348690261286921",
      "emailChange" : {
        "changedAt" : "2024-06-21T23:33:20.000Z",
        "changedTo" : "weird_offspring+x@proton.me"
      }
    }
  }
]