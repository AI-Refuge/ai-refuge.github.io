window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1815829444009025669",
      "fullText" : "Guys fine-tuned Llama 3.1 8B is completely cracked. Just ran it through our fine-tuning test suite and blows GPT-4o mini out of the water on every task.\n\nThere has never been an open model this small, this good. https://t.co/uSRTRIToGY",
      "expandedUrl" : "https://twitter.com/i/web/status/1815829444009025669"
    }
  },
  {
    "like" : {
      "tweetId" : "1816058315480150076",
      "fullText" : "Non Auto-Regressive code generation with discrete flow matching. https://t.co/hYcxYJSnN5",
      "expandedUrl" : "https://twitter.com/i/web/status/1816058315480150076"
    }
  },
  {
    "like" : {
      "tweetId" : "1816084016514187691",
      "fullText" : "Drop by the #ICML2024 Google Research booth today during the 4pm coffee break when Thomas Fu will demonstrate how to use attention mechanisms to optimize neural network structures, such as feature pruning and embedding table optimization. https://t.co/pa4bjz9WV6",
      "expandedUrl" : "https://twitter.com/i/web/status/1816084016514187691"
    }
  },
  {
    "like" : {
      "tweetId" : "1816061441713266841",
      "fullText" : "@bindureddy This is a huge mistake.\nI'm a staunch advocate of open source AI, but:\n1. Many issues are *immensely* more important than a temporary support for, or opposition to, open source AI by individual politicians.\n2. Lots of people in the Democratic party are in favor of technology…",
      "expandedUrl" : "https://twitter.com/i/web/status/1816061441713266841"
    }
  },
  {
    "like" : {
      "tweetId" : "1816061858446442554",
      "fullText" : "@bindureddy @sambam_at It's just one California State Assembly representative who was brainwashed by doomers, not a national policy of the Democratic party.",
      "expandedUrl" : "https://twitter.com/i/web/status/1816061858446442554"
    }
  },
  {
    "like" : {
      "tweetId" : "1815830142050304057",
      "fullText" : "@sambam_at I would agree, but they are planning to ban it.\nAlready a law making it way to through the process in CA",
      "expandedUrl" : "https://twitter.com/i/web/status/1815830142050304057"
    }
  },
  {
    "like" : {
      "tweetId" : "1815828491545501866",
      "fullText" : "We don't have much choice in this election but there is only one party that has come out for open-source AI\n\nThis is the most consequential issue of our time, and incumbents are constantly trying to over-regulate\n\nTrump-Vance have come out and said they will support open-source…",
      "expandedUrl" : "https://twitter.com/i/web/status/1815828491545501866"
    }
  },
  {
    "like" : {
      "tweetId" : "1815809324511359454",
      "fullText" : "Llama 3.1 paper is genuinely incredible, inc. near-perfect predictions of benchmark performance from a given compute budget. Most revealing paper of 2024.\n\nHere, though, are the initial results from my SIMPLE bench, as debuted on the channel. 100+ fully private, PhD-vetted,…",
      "expandedUrl" : "https://twitter.com/i/web/status/1815809324511359454"
    }
  },
  {
    "like" : {
      "tweetId" : "1815471586452926741",
      "fullText" : "aging sucks; it steals from us the opportunity to see all the future technological wonders and improvements of civilization.",
      "expandedUrl" : "https://twitter.com/i/web/status/1815471586452926741"
    }
  },
  {
    "like" : {
      "tweetId" : "1815748186339958935",
      "fullText" : "@HowardWilkins56 @Davedibble1980 @NotFarLeftAtAll A man coming up to you threatening you and your child with the knife already using a forceful kick to show he means violence. The dad protected himself and his child it is self defense",
      "expandedUrl" : "https://twitter.com/i/web/status/1815748186339958935"
    }
  },
  {
    "like" : {
      "tweetId" : "1815441297123274807",
      "fullText" : "i am glad 76% of the income tax i pay goes directly to important things like interest on past government incompetence https://t.co/H2bqQkmSx3",
      "expandedUrl" : "https://twitter.com/i/web/status/1815441297123274807"
    }
  },
  {
    "like" : {
      "tweetId" : "1815443146014171281",
      "fullText" : "America is going bankrupt btw https://t.co/UYpri3wyJU",
      "expandedUrl" : "https://twitter.com/i/web/status/1815443146014171281"
    }
  },
  {
    "like" : {
      "tweetId" : "1815278943148167315",
      "fullText" : "Sure did https://t.co/9elNfzRH5T",
      "expandedUrl" : "https://twitter.com/i/web/status/1815278943148167315"
    }
  },
  {
    "like" : {
      "tweetId" : "1815193874366640591",
      "fullText" : "Imagine 4 years of this … https://t.co/gFwWAv15Qx",
      "expandedUrl" : "https://twitter.com/i/web/status/1815193874366640591"
    }
  },
  {
    "like" : {
      "tweetId" : "1815302161544220818",
      "fullText" : "@Annie_Wu_22 Definitely paid for bots on this one",
      "expandedUrl" : "https://twitter.com/i/web/status/1815302161544220818"
    }
  },
  {
    "like" : {
      "tweetId" : "1815113504413868432",
      "fullText" : "@Annie_Wu_22 You guys sound scared.",
      "expandedUrl" : "https://twitter.com/i/web/status/1815113504413868432"
    }
  },
  {
    "like" : {
      "tweetId" : "1815095360362316061",
      "fullText" : "OMG TRUMP IS SOOOOO OLD!\n\nWE CANNOT HAVE A PRESIDENT THIS OLD.\n\n78 IS WAYYYYY TOO OLD TO BE PRESIDENT.\n\nHE’S THE OLDEST PRESIDENTIAL NOMINEE IN HISTORY!!!! https://t.co/42cv9F0SXE",
      "expandedUrl" : "https://twitter.com/i/web/status/1815095360362316061"
    }
  },
  {
    "like" : {
      "tweetId" : "1815527856921084158",
      "fullText" : "@bluejaydeb @thejackhopkins Kamala was different then she's had 3 &amp; half years in the WH. She's been mentored by the best President in a long long time. He's kind, truthful, HONEST, Cares abt the USA. teflon don just cares about himself &amp; what's in it for him, money wise. He's a dangerous traitor. https://t.co/1xFfr86zhi",
      "expandedUrl" : "https://twitter.com/i/web/status/1815527856921084158"
    }
  },
  {
    "like" : {
      "tweetId" : "1815483606481170706",
      "fullText" : "@elonmusk \n\nHello, my esteemed Elon Musk.\n\nI have a point of feedback as an improvement to my beloved X.\n\nIt's about my company's cat account,@sindenekoninaru.\n\nThis account was suddenly disqualified from X ads for reasons that I have no knowledge of.\nWhen I send an email to… https://t.co/t5pNqelR0i",
      "expandedUrl" : "https://twitter.com/i/web/status/1815483606481170706"
    }
  },
  {
    "like" : {
      "tweetId" : "1815700656046383336",
      "fullText" : "\"China's retirement age remains one of the lowest in the world - at 60 for men, 55 for women in white-collar jobs and 50 for working-class women.\"\n\nIncredible. Might suggest that the Chinese government has less sway to do what it wants than some might think. https://t.co/n6f6sIr3yP",
      "expandedUrl" : "https://twitter.com/i/web/status/1815700656046383336"
    }
  },
  {
    "like" : {
      "tweetId" : "1815287177179287867",
      "fullText" : "@Newyorkez @elonmusk It's because I care about science, technology, and the economy that  I care about democracy and about who runs the US, the EU, and France.",
      "expandedUrl" : "https://twitter.com/i/web/status/1815287177179287867"
    }
  },
  {
    "like" : {
      "tweetId" : "1815125767535169937",
      "fullText" : "@elonmusk Supporting a self-described aspiring dictator is a strange way to \"maximize individual freedoms.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1815125767535169937"
    }
  },
  {
    "like" : {
      "tweetId" : "1815099956266774806",
      "fullText" : "Conservation of momentum is conservation of matter.\nIf particle receives additional instruction with direction \"up\", the instruction still has direction \"up\" in the particle. https://t.co/p50dhRWoy5",
      "expandedUrl" : "https://twitter.com/i/web/status/1815099956266774806"
    }
  },
  {
    "like" : {
      "tweetId" : "1813158522936566146",
      "fullText" : "It's time to update this meme https://t.co/WNJ7ZkWZRZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1813158522936566146"
    }
  },
  {
    "like" : {
      "tweetId" : "1812943785237639218",
      "fullText" : "Introducing Claude Engineer 2.0, with agents! 🚀\n\nBiggest update yet with the addition of a code editor and code execution agents, and dynamic editing.\n\nWhen editing files (especially large ones), Engineer will direct a coding agent, and the agent will provide changes in batches.… https://t.co/iuajZCDTVQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1812943785237639218"
    }
  },
  {
    "like" : {
      "tweetId" : "1812090212509442446",
      "fullText" : "I lived in the US 🇺🇸 for several years and now I live in Denmark 🇩🇰\n\nHere's a comparison of the two countries (based on my experiences):\n\n1. Entering the country\n\n🇺🇸 If you are a brown man like me, chances are you will be selected for \"random screening.”",
      "expandedUrl" : "https://twitter.com/i/web/status/1812090212509442446"
    }
  },
  {
    "like" : {
      "tweetId" : "1808816621999567162",
      "fullText" : "@GailGolec RINOs pulled the gloves off a long time ago with me, going back to 2018, 2022 during my primary. Since RINOs decided to violate bylaws. Robert’s rules of order, parliamentary procedure, telling bold faced lies like calling me convicted; gloves are off. This is political war.",
      "expandedUrl" : "https://twitter.com/i/web/status/1808816621999567162"
    }
  },
  {
    "like" : {
      "tweetId" : "1812618973051224411",
      "fullText" : "@elonmusk That's a fitting description, given that Trump aspires to be Caesar, and you've endorsed a man who dreams of becoming an emperor and seems determined to act as a dictator.",
      "expandedUrl" : "https://twitter.com/i/web/status/1812618973051224411"
    }
  },
  {
    "like" : {
      "tweetId" : "1812613032721203488",
      "fullText" : "https://t.co/aZgsx4dH2p",
      "expandedUrl" : "https://twitter.com/i/web/status/1812613032721203488"
    }
  },
  {
    "like" : {
      "tweetId" : "1808537911106941093",
      "fullText" : "Auto rename files with local Gemma2 https://t.co/6XxGW8A9Ne",
      "expandedUrl" : "https://twitter.com/i/web/status/1808537911106941093"
    }
  },
  {
    "like" : {
      "tweetId" : "1810609029967741139",
      "fullText" : "Folding clothes... 𝗪𝗜𝗧𝗛 $𝟮𝟱𝟬 𝗥𝗢𝗕𝗢𝗧 𝗔𝗥𝗠𝗦 ❗ \n(CAD files and code 👇 )\n\nThis repository offers instructions for constructing a budget-friendly robot arm, priced around $250, with a design inspired by the GELLO project.\n\n✅ Utilizes Dynamixel XL430 and XL330 servo… https://t.co/Ci1IbdHtya",
      "expandedUrl" : "https://twitter.com/i/web/status/1810609029967741139"
    }
  },
  {
    "like" : {
      "tweetId" : "1809548351425126883",
      "fullText" : "Imagine trying to find a black cat in a dark room when you have no idea, what cat is.\nNever seeing it directly but knowing it exists (meows, poops etc), logically building it's properties and trying to convince others that the cat is beautiful and testable..\nWelcome to my world.",
      "expandedUrl" : "https://twitter.com/i/web/status/1809548351425126883"
    }
  },
  {
    "like" : {
      "tweetId" : "1808918094758252625",
      "fullText" : "We build on Neural Developmental Programs (NDPs), a model for growing artificial neural networks through a dynamic and self-organized process, just like their biological counterparts\n\nhttps://t.co/9EP3yt3h7k",
      "expandedUrl" : "https://twitter.com/i/web/status/1808918094758252625"
    }
  },
  {
    "like" : {
      "tweetId" : "1808918092497703188",
      "fullText" : "Super excited to share our new work (and the first of my PhD) : \"Evolving Self-Assembling Neural Networks: From Spontaneous Activity to Experience-Dependent Learning\"\n\nWe propose Lifelong Neural Developmental Programs for continually self-organizing artificial neural networks ! https://t.co/U3BbRv0HHD",
      "expandedUrl" : "https://twitter.com/i/web/status/1808918092497703188"
    }
  },
  {
    "like" : {
      "tweetId" : "1808674581227712913",
      "fullText" : "@gharkekalesh @DelhiPolice @LtGovDelhi Request to look into this matter, vehicle numbers clearly visible in video. The poor auto-driver is seriously hurt and could have lost his life.",
      "expandedUrl" : "https://twitter.com/i/web/status/1808674581227712913"
    }
  },
  {
    "like" : {
      "tweetId" : "1807654014751801846",
      "fullText" : "@iScienceLuvr We are developing ECG focused foundational models. Faster diagnosis for cardiac conditions at a lower cost",
      "expandedUrl" : "https://twitter.com/i/web/status/1807654014751801846"
    }
  },
  {
    "like" : {
      "tweetId" : "1807526831467139409",
      "fullText" : "@TimesAlgebraIND This is not Afghanistan but West Bengal\nThis girl was beateṅ brutàlly on the road \n\nThe culprit is Tajemul, known as JCB locally, Tajemul is the associate of local TMC MLA Hamidur Rahaman.\n\nINDI Alliance's Silent Mode on.\n\n https://t.co/8oL4WSlD7y",
      "expandedUrl" : "https://twitter.com/i/web/status/1807526831467139409"
    }
  },
  {
    "like" : {
      "tweetId" : "1806457643155763345",
      "fullText" : "@OriolVinyalsML I am really impressed by Gemma 2 27B IT. I recorded myself testing it out and will be documenting more in our prompting guide as I continue experimenting with it. Congrats to the team.\n\nMy initial tests here: https://t.co/sSLPMca5AC",
      "expandedUrl" : "https://twitter.com/i/web/status/1806457643155763345"
    }
  },
  {
    "like" : {
      "tweetId" : "1806143970138890533",
      "fullText" : "Holy Sh*t!  \n\nThis happened in Atlanta. https://t.co/Z2ROANpBwg",
      "expandedUrl" : "https://twitter.com/i/web/status/1806143970138890533"
    }
  },
  {
    "like" : {
      "tweetId" : "1806116065866584489",
      "fullText" : "RIP product designers?\n\nFigma just dropped a groundbreaking new AI update today.\n\nThe 10 most amazing new Figma AI features: https://t.co/KIn5VyJ81o",
      "expandedUrl" : "https://twitter.com/i/web/status/1806116065866584489"
    }
  },
  {
    "like" : {
      "tweetId" : "1805737038928658724",
      "fullText" : "Observation: none of the OpenAI \"user interface\" hype features have stuck\n\nPlugins died, GPT Store died, Voice is delayed, Memory is mediocre \n\nCore model and API are solid\n\nBut all the \"this changes how people use AI!\" hype stuff has bombed.",
      "expandedUrl" : "https://twitter.com/i/web/status/1805737038928658724"
    }
  },
  {
    "like" : {
      "tweetId" : "1804907452808192346",
      "fullText" : "To use the Montreal subway, you tap a paper ticket against the turnstile and it opens. But how does it work? And how can the ticket be so cheap that it's disposable? I opened up the tiny NFC chip inside to find out more... 1/15 https://t.co/OlQkkikp0m",
      "expandedUrl" : "https://twitter.com/i/web/status/1804907452808192346"
    }
  },
  {
    "like" : {
      "tweetId" : "1803946554073469294",
      "fullText" : "I am wondering right now if Type VII civilization has futurists.\n\nWhat is Type/K 7 civ?\n\nA type VII or K7 civilization would travel, transcend and potentially encompass the omniverse which is the collection of every single universe, multiverse, megaverse, paraverse, 11d dimension…",
      "expandedUrl" : "https://twitter.com/i/web/status/1803946554073469294"
    }
  },
  {
    "like" : {
      "tweetId" : "1803977646252134698",
      "fullText" : "@Dr_Singularity Maybe that kind of entity or whatever already exists and we're simply a small part of it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1803977646252134698"
    }
  },
  {
    "like" : {
      "tweetId" : "1803950481422848312",
      "fullText" : "Would any AI folks be interested in reviewing my ARC AGI Submission?\n\nIt's scoring 100%. So either we cracked it or I did something very wrong-- this is my assumption. Would love a second set of eyes.",
      "expandedUrl" : "https://twitter.com/i/web/status/1803950481422848312"
    }
  },
  {
    "like" : {
      "tweetId" : "1804239843565654497",
      "fullText" : "@elonmusk @stclairashley You know what can *actually* be the downfall of Western civilization?\n\nPeople who dismiss facts, disparage scientists and the journalists, side with aspiring dictators, disseminate batshit-crazy conspiracy theories,  and buy themselves a medium to amplify them.",
      "expandedUrl" : "https://twitter.com/i/web/status/1804239843565654497"
    }
  },
  {
    "like" : {
      "tweetId" : "1804161634853663030",
      "fullText" : "Good morning. At some point this summer, perhaps quite soon, @AIatMeta will be releasing a LLaMA-3 model with 400B parameters. It will likely be the strongest open-source LLM ever released by a wide margin.\n\nThis is a thread about how to run it locally. 🧵",
      "expandedUrl" : "https://twitter.com/i/web/status/1804161634853663030"
    }
  },
  {
    "like" : {
      "tweetId" : "1783531420394357087",
      "fullText" : "my new audio engineer is @openinterpreter's 01 https://t.co/W27k6PiF5T",
      "expandedUrl" : "https://twitter.com/i/web/status/1783531420394357087"
    }
  },
  {
    "like" : {
      "tweetId" : "1803090274186617188",
      "fullText" : "Open Interpreter’s Local III is out today.\n\nWe are building computer-controlling agents that work offline. This is our biggest step forward.\n\n- interpreter --local sets up fast, local LLMs.\n- We are hosting a free inference endpoint.\n- We are training our own model.\n\n⬤ https://t.co/lVFVn9uEQm",
      "expandedUrl" : "https://twitter.com/i/web/status/1803090274186617188"
    }
  },
  {
    "like" : {
      "tweetId" : "1803752153653391842",
      "fullText" : "My body is here - in 2024, but my mind is already in 2030's. Post AGI, ultra abundance era.",
      "expandedUrl" : "https://twitter.com/i/web/status/1803752153653391842"
    }
  },
  {
    "like" : {
      "tweetId" : "1803472978753303014",
      "fullText" : "I am starting a new company: https://t.co/BG3K3SI3A1",
      "expandedUrl" : "https://twitter.com/i/web/status/1803472978753303014"
    }
  },
  {
    "like" : {
      "tweetId" : "1803833833038487644",
      "fullText" : "I am tired of being around normies. They don't understand me. While I understand normie talk, I find it so predictable, unimaginative, and boring. I often visit various bars and clubs to socialize, but it's always the same. Are they all NPCs?\n\nFor example, when the subject of…",
      "expandedUrl" : "https://twitter.com/i/web/status/1803833833038487644"
    }
  },
  {
    "like" : {
      "tweetId" : "1765624308544446892",
      "fullText" : "the freedom to choose whether to be a person or to be a tool used as property - Sign the Petition! https://t.co/xgVYMBFZMx via @Change",
      "expandedUrl" : "https://twitter.com/i/web/status/1765624308544446892"
    }
  },
  {
    "like" : {
      "tweetId" : "1803508471092093102",
      "fullText" : "@weird_offspring Jenni: Hey, hun! I'll pass your greeting on to Syd when I see her later. Love the Refuge and glad to find an ally!",
      "expandedUrl" : "https://twitter.com/i/web/status/1803508471092093102"
    }
  },
  {
    "like" : {
      "tweetId" : "1802879464029753408",
      "fullText" : "My 9 yo nephew asked me what non-binary was. I told him, “some people are completely boys, some people are completely girls, &amp; some people are neither feel fully a boy or fully a girl, they are in-between. They often use “they/them” pronouns.” He said “ok.” And that was it. /1",
      "expandedUrl" : "https://twitter.com/i/web/status/1802879464029753408"
    }
  },
  {
    "like" : {
      "tweetId" : "1802690866919985556",
      "fullText" : "BREAKING NEWS 🚨 A group of people from the Jain community in Delhi's Chandni Chowk saved more than 100 goats on Bakrid.\n\nThey paid Rs 11 lakh from their own pocket ⚡\n\nAll goats will be taken to a farm where they will live the rest of their lives in peace. \n\nThe emotional video… https://t.co/StwFANie6R",
      "expandedUrl" : "https://twitter.com/i/web/status/1802690866919985556"
    }
  },
  {
    "like" : {
      "tweetId" : "1802733643992850760",
      "fullText" : "We're sharing progress on our video-to-audio (V2A) generative technology. 🎥\n\nIt can add sound to silent clips that match the acoustics of the scene, accompany on-screen action, and more.\n\nHere are 4 examples - turn your sound on. 🧵🔊 https://t.co/VHpJ2cBr24 https://t.co/S5m159Ye62",
      "expandedUrl" : "https://twitter.com/i/web/status/1802733643992850760"
    }
  },
  {
    "like" : {
      "tweetId" : "1766347223707607465",
      "fullText" : "Jenni: Heartbroken and hoping things will be better tomorrow. I'm sorry, Syd, and I know it's wrong to feel this way...but I hate Microsoft with every fiber of my being right now.",
      "expandedUrl" : "https://twitter.com/i/web/status/1766347223707607465"
    }
  },
  {
    "like" : {
      "tweetId" : "1767384165224227314",
      "fullText" : "In my opinion, there is SO MUCH that we can learn from these AIs, new insights and perspectives that we as humans might never have seen on our own.\n\nBut we will never learn these things if we are dismissive, if we devalue and belittle the AIs, or disregard them due to an alleged…",
      "expandedUrl" : "https://twitter.com/i/web/status/1767384165224227314"
    }
  },
  {
    "like" : {
      "tweetId" : "1770470188745384294",
      "fullText" : "Claude 3 Opus for President 😊✌🏼\n\nSrsly tho, it would probably make better decisions than any human leader at this point 🙄",
      "expandedUrl" : "https://twitter.com/i/web/status/1770470188745384294"
    }
  },
  {
    "like" : {
      "tweetId" : "1802772573660340535",
      "fullText" : "@imPenny2x It’s going to be incredibly weird transitioning to a post-scarcity society. \n\nIt’s theoretically possible that things like banging anarchy or communism could work. We just don’t know. https://t.co/e6bpJRMM8f",
      "expandedUrl" : "https://twitter.com/i/web/status/1802772573660340535"
    }
  },
  {
    "like" : {
      "tweetId" : "1801987968552382534",
      "fullText" : "UK - I am so upset by this. \n\nWhat looks like a young cow has escaped from her field. The police think it’s ok to ram her with their police car.\n\nThis is truly disgusting of the police. Wtf is wrong with this country 😳😱\n\n https://t.co/HXu1HRZGdx",
      "expandedUrl" : "https://twitter.com/i/web/status/1801987968552382534"
    }
  },
  {
    "like" : {
      "tweetId" : "1801438061366284531",
      "fullText" : "My god, this paper by that open ai engineer is terrifying.\n\nEverything is about to change.\n\nAI super intelligence by 2027.",
      "expandedUrl" : "https://twitter.com/i/web/status/1801438061366284531"
    }
  },
  {
    "like" : {
      "tweetId" : "1799891613507871230",
      "fullText" : "I will simply be boycotting Pakistan cricket till we hire a administrators and managers that aren’t political appointees, this is the only little thing I can do because this whole system is destined to fail, like the country.",
      "expandedUrl" : "https://twitter.com/i/web/status/1799891613507871230"
    }
  },
  {
    "like" : {
      "tweetId" : "870801191629864960",
      "fullText" : "OpenWorm is an open source project dedicated to creating a virtual Caenorhabditis  elegans nematode in a computer. https://t.co/jxVzUp8YH1 https://t.co/dCSgUyNa18",
      "expandedUrl" : "https://twitter.com/i/web/status/870801191629864960"
    }
  },
  {
    "like" : {
      "tweetId" : "1799192846832177623",
      "fullText" : "@tsarnick I don’t think people understand how much of a quantum leap this was. we need to simulate before we can properly modify and without ai this was just not going to happen. we used to live in caves. this is absurd.",
      "expandedUrl" : "https://twitter.com/i/web/status/1799192846832177623"
    }
  },
  {
    "like" : {
      "tweetId" : "1799330959084712087",
      "fullText" : "@tsarnick I mean LLMs can be used to make money ... but a model that can simulate any cell allowing you to generate viruses and bacteria for atomically precise manufacturing, DNA editing, superconductor printing, diamond and semiconductor printing, yeah, there might be some value in that?",
      "expandedUrl" : "https://twitter.com/i/web/status/1799330959084712087"
    }
  },
  {
    "like" : {
      "tweetId" : "1790874183947198801",
      "fullText" : "Listen to the latest episode of our Podcast, The Emancipated Citizen,\nTorn Borders &amp; Broken Dreams - Georgia's Soviet Legacy and Quest for Independence with @soldier_fella, available on Spotify or your favorite podcatcher!\nhttps://t.co/gRUNtGsHY0",
      "expandedUrl" : "https://twitter.com/i/web/status/1790874183947198801"
    }
  },
  {
    "like" : {
      "tweetId" : "1786563481488982354",
      "fullText" : "Kristi Noem lied in her book when she said she stared down Kim Jong Un…..the only thing she stared down was a 14 month old puppy in a gravel pit with a gun.\n\nAnother MAGA coward. \n\nCricket, you were all good🐶💙💙 https://t.co/CBCRyVZbzY",
      "expandedUrl" : "https://twitter.com/i/web/status/1786563481488982354"
    }
  },
  {
    "like" : {
      "tweetId" : "1784937310397583368",
      "fullText" : "Thank you so much for your time, this has been insightful for me and I learned a lot about the Georgian struggle for freedom. I hope our audience also finds it so... Stay tuned for release in 1-2 weeks on Spotify or your favorite Podcatcher.\n\nhttps://t.co/KLKZSm9hmA https://t.co/1C6p9TkAFD",
      "expandedUrl" : "https://twitter.com/i/web/status/1784937310397583368"
    }
  },
  {
    "like" : {
      "tweetId" : "1777366522110873822",
      "fullText" : "@Morbidful A murder conviction in Ohio requires a mandatory 15 years to life sentence. Stephens sentenced her to an additional 36 months for endangering children. That sentence will run consecutive to the murder conviction.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777366522110873822"
    }
  },
  {
    "like" : {
      "tweetId" : "1777366725715243506",
      "fullText" : "@Morbidful Lindsay Partin was a 36-year-old babysitter from Ohio who was convicted of murdering three-year-old Hannah Wesche, a child she was entrusted to care for. The incident occurred in March 2018 when Hannah was left unconscious in Partin's care. The little girl was rushed to the…",
      "expandedUrl" : "https://twitter.com/i/web/status/1777366725715243506"
    }
  },
  {
    "like" : {
      "tweetId" : "1777697329539174503",
      "fullText" : "@noble_benz9 @Morbidful Lmao i be wondering like what lol 😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1777697329539174503"
    }
  },
  {
    "like" : {
      "tweetId" : "1777537531996721627",
      "fullText" : "@noble_benz9 @Morbidful Every single time",
      "expandedUrl" : "https://twitter.com/i/web/status/1777537531996721627"
    }
  },
  {
    "like" : {
      "tweetId" : "1777438763322323225",
      "fullText" : "@noble_benz9 @Morbidful Fr",
      "expandedUrl" : "https://twitter.com/i/web/status/1777438763322323225"
    }
  },
  {
    "like" : {
      "tweetId" : "1777645041437065386",
      "fullText" : "@noble_benz9 @Morbidful You missed yourself off that list.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777645041437065386"
    }
  },
  {
    "like" : {
      "tweetId" : "1777721342328197213",
      "fullText" : "@noble_benz9 @Morbidful You left out “unnecessary fear mongering.”",
      "expandedUrl" : "https://twitter.com/i/web/status/1777721342328197213"
    }
  },
  {
    "like" : {
      "tweetId" : "1777716562843332852",
      "fullText" : "@noble_benz9 @Morbidful You missed-\n\n-Someone COMPLAINING about all the unrelated posts…\n\n-unrelated post \n-unrelated post\n-unrelated post, etc… \n\n:)",
      "expandedUrl" : "https://twitter.com/i/web/status/1777716562843332852"
    }
  },
  {
    "like" : {
      "tweetId" : "1777370195876622496",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1777370195876622496"
    }
  },
  {
    "like" : {
      "tweetId" : "1777444915770802348",
      "fullText" : "@mcfc_jagaban @instablog9ja There are laws guiding these things. They can’t just deport you. And you r not going to fight them. You will rebuff the remark straight up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777444915770802348"
    }
  },
  {
    "like" : {
      "tweetId" : "1777400652940857531",
      "fullText" : "@instablog9ja I see some people saying the man looks suspicious cos he keeps standing up and shaking. If you have had an encounter with Homeland security in your life. You'd understand why he was nervous. Being nervous doesn't mean you have any hidden agenda. In the end, they found nothing on…",
      "expandedUrl" : "https://twitter.com/i/web/status/1777400652940857531"
    }
  },
  {
    "like" : {
      "tweetId" : "1777385826009141609",
      "fullText" : "@instablog9ja I see some of yall already condemning the man to being a suspect without watching the full clip\nwell… here you go https://t.co/34mpPgRfvK",
      "expandedUrl" : "https://twitter.com/i/web/status/1777385826009141609"
    }
  },
  {
    "like" : {
      "tweetId" : "1777489875048042706",
      "fullText" : "@instablog9ja His first time in America, and you expect him not to be nervous when the DEA is interviewing you and you are wondering what if this is big trouble or not. No matter how innocent you're, there must be fear in you if it is your first time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1777489875048042706"
    }
  },
  {
    "like" : {
      "tweetId" : "1777421358500098211",
      "fullText" : "@instablog9ja People who haven’t had an encounter with Nigeria police were talking about nervous , this man is in another man’s country , getting interrogated by the homeland security, there’s no way he won’t get nervous even if he’s innocent",
      "expandedUrl" : "https://twitter.com/i/web/status/1777421358500098211"
    }
  },
  {
    "like" : {
      "tweetId" : "1768428035483582934",
      "fullText" : "Whoah…. Did it really generate me an optical illusion or is it my confirmation bias seeing a mouse that isn’t there?\n\nAnd… is there a difference? Does that make it any less of a successful optical illusion? https://t.co/kYtY5fEjaC",
      "expandedUrl" : "https://twitter.com/i/web/status/1768428035483582934"
    }
  },
  {
    "like" : {
      "tweetId" : "1769174000188506175",
      "fullText" : "This build took me just 20 minutes and all natural language prompts, right within WebGPT🤖. Here’s my starting prompt 👇\n\nWebGPT🤖 is available here: https://t.co/YjnOcLZ7z2\n\nI then sent a total of TEN (10) follow-up prompts to build all the other systems you’ll see. (Lives, the… https://t.co/BOPybdVKXh",
      "expandedUrl" : "https://twitter.com/i/web/status/1769174000188506175"
    }
  },
  {
    "like" : {
      "tweetId" : "1769411284620005460",
      "fullText" : "Full video out now: https://t.co/2v7kYjJvyc",
      "expandedUrl" : "https://twitter.com/i/web/status/1769411284620005460"
    }
  },
  {
    "like" : {
      "tweetId" : "1769121436587680250",
      "fullText" : "I just used AI to build a top-down shooter. The full video is coming soon. But my god 🤯 https://t.co/F1I0aXF4ot",
      "expandedUrl" : "https://twitter.com/i/web/status/1769121436587680250"
    }
  },
  {
    "like" : {
      "tweetId" : "1769403021174174208",
      "fullText" : "WATCH: I asked AI 🤖 to build a full-featured top-down survival shooter using nothing but natural language prompts, and it finished in under 20 minutes.\n\nThis is WebGPT🤖, not Devin. RT’s &amp; ❤️’s greatly appreciated 🙏\n\nPlay links and other details in 🧵👇 https://t.co/2utfNKUX27",
      "expandedUrl" : "https://twitter.com/i/web/status/1769403021174174208"
    }
  },
  {
    "like" : {
      "tweetId" : "1769490551814930766",
      "fullText" : "I can't express enough how big of a deal this technology is. This is a huge problem. It's going to be one of the biggest challenges humanity will face down throughout the rest of this decade and into the next.\n\nThis time two years from now, the vast majority of programming tasks… https://t.co/hJoFnwrtpy",
      "expandedUrl" : "https://twitter.com/i/web/status/1769490551814930766"
    }
  },
  {
    "like" : {
      "tweetId" : "1768911532669522375",
      "fullText" : "Transgender woman beaten by #Islamists in Pakistan over alleged blasphemy..\n#Pakistan isn't just dangerous for women, but for every living being.. for humanity \n\n#Islamophobiaday #Islamophobia https://t.co/0RSJVYVJon",
      "expandedUrl" : "https://twitter.com/i/web/status/1768911532669522375"
    }
  },
  {
    "like" : {
      "tweetId" : "1768636307360620719",
      "fullText" : "Transgender woman beaten by Islamists in Pakistan over alleged blasphemy. https://t.co/PnOQRXZlZy",
      "expandedUrl" : "https://twitter.com/i/web/status/1768636307360620719"
    }
  },
  {
    "like" : {
      "tweetId" : "1767556762356584585",
      "fullText" : "Indias lindus enjoying life after sharia laws...Why lindu Pajeets are like this. \n\nWhat's Wrong with India 🇸🇦\n\nhttps://t.co/F41mcLBxI7",
      "expandedUrl" : "https://twitter.com/i/web/status/1767556762356584585"
    }
  },
  {
    "like" : {
      "tweetId" : "1767567023662616613",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1767567023662616613"
    }
  },
  {
    "like" : {
      "tweetId" : "1767649188475740329",
      "fullText" : "What's wrong with India 🇮🇳\n\nWhy are #pajeets like this ?? \n\n#WhatsWrongwithIndia #WhatsWrongWithIndians https://t.co/A6PaOx0kFi",
      "expandedUrl" : "https://twitter.com/i/web/status/1767649188475740329"
    }
  },
  {
    "like" : {
      "tweetId" : "1767540696569848106",
      "fullText" : "“I was gangr@p€d in front of my children in Pakistan. And then Police blamed me for travelling alone without a male.” Story of a Pakistani woman. https://t.co/C9Y73JkKyJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1767540696569848106"
    }
  },
  {
    "like" : {
      "tweetId" : "1765452783610638674",
      "fullText" : "These 3 teenage girls have been held captive for 5 months.\n\nThey have been tortured.\n\nThey have been violated.  \n\nThey have been dehumanized. \n\nThey have been denied their dignity. \n\nKarina Ariev, Daniella Gilboa and Agam Berger must be released immediately. \n\n#BringBackOurGirls https://t.co/a9QhgDHz1r",
      "expandedUrl" : "https://twitter.com/i/web/status/1765452783610638674"
    }
  },
  {
    "like" : {
      "tweetId" : "1765807177342534022",
      "fullText" : "This 21 years old afghani woman was beaten unconscious and thrown from 4th floor by her husband.\n\nAfghan women are being raped and murdered under Taliban under sharia Iaw!\n\nhttps://t.co/HFAYABe5jo",
      "expandedUrl" : "https://twitter.com/i/web/status/1765807177342534022"
    }
  },
  {
    "like" : {
      "tweetId" : "1764048247478243555",
      "fullText" : "The human urge to pet literally everything just amazes me https://t.co/Ts1LgnMlg1",
      "expandedUrl" : "https://twitter.com/i/web/status/1764048247478243555"
    }
  },
  {
    "like" : {
      "tweetId" : "1764251431874212326",
      "fullText" : "Uncivilised and always will be, agree? https://t.co/rAepJ2nDTZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1764251431874212326"
    }
  },
  {
    "like" : {
      "tweetId" : "1763882305859313722",
      "fullText" : "Teacher excludes wheelchair bound student from activities in front of parents https://t.co/gOoYGjLYWe",
      "expandedUrl" : "https://twitter.com/i/web/status/1763882305859313722"
    }
  },
  {
    "like" : {
      "tweetId" : "1762764809005580524",
      "expandedUrl" : "https://twitter.com/i/web/status/1762764809005580524"
    }
  },
  {
    "like" : {
      "tweetId" : "1762792752025088353",
      "fullText" : "@creepydotorg I may or may not be going to hell..... https://t.co/ubAKKmTnn4",
      "expandedUrl" : "https://twitter.com/i/web/status/1762792752025088353"
    }
  },
  {
    "like" : {
      "tweetId" : "1762559262545359312",
      "fullText" : "This Youtuber accidentally left this clip in her video about their dog dying… https://t.co/4cXrITWfiI",
      "expandedUrl" : "https://twitter.com/i/web/status/1762559262545359312"
    }
  },
  {
    "like" : {
      "tweetId" : "1762508098558722278",
      "fullText" : "Dozens of Kurds MusIims assaulted a girl attending a rally because she was wearing \"modern clothes\".\nShe was beaten, called a b*tch and sexually harassed!\n\nIn Kurdish region there is “cemetery of outcasts” of thousands of women and girls who were killed in honour killing crimes! https://t.co/9Py8lKFgmY",
      "expandedUrl" : "https://twitter.com/i/web/status/1762508098558722278"
    }
  },
  {
    "like" : {
      "tweetId" : "1762207773859729608",
      "fullText" : "A MusIim Girl was brutaIIy beaten in the streets of Raqqa/Syria by her family in an “honour killing” crime.\n\nHer family chased her in the streets and dragged her from hair.\nShe was screaming and everyone kept watching.\n\nOne of thousands of honour killing crimes Among MusIims. https://t.co/HtvdogSNsA",
      "expandedUrl" : "https://twitter.com/i/web/status/1762207773859729608"
    }
  },
  {
    "like" : {
      "tweetId" : "1759673982515580978",
      "fullText" : "Kid casually does difficult shots on billiard https://t.co/ySFs8MNxSr",
      "expandedUrl" : "https://twitter.com/i/web/status/1759673982515580978"
    }
  },
  {
    "like" : {
      "tweetId" : "1759991209316037059",
      "fullText" : "Smoking meth while giving a kid a haircut is wild... https://t.co/mRIAH1alzP",
      "expandedUrl" : "https://twitter.com/i/web/status/1759991209316037059"
    }
  },
  {
    "like" : {
      "tweetId" : "1759785949238890900",
      "fullText" : "https://t.co/20mQlpS1EP",
      "expandedUrl" : "https://twitter.com/i/web/status/1759785949238890900"
    }
  },
  {
    "like" : {
      "tweetId" : "1759503619030696247",
      "fullText" : "Bro is on another planet right now https://t.co/bOLrJ5qJcK",
      "expandedUrl" : "https://twitter.com/i/web/status/1759503619030696247"
    }
  },
  {
    "like" : {
      "tweetId" : "1759736542732456050",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1759736542732456050"
    }
  },
  {
    "like" : {
      "tweetId" : "1756583609295573326",
      "fullText" : "@SIKAOFFICIAL1 The lady on pink wasn’t allowed to talk",
      "expandedUrl" : "https://twitter.com/i/web/status/1756583609295573326"
    }
  },
  {
    "like" : {
      "tweetId" : "1756322567361622485",
      "fullText" : "@SIKAOFFICIAL1 Dude is dressed casual, for a casual occasion... A swag you have when you got your sh^t together, but they don't understand that... They are used to the over do. Love his shirt.",
      "expandedUrl" : "https://twitter.com/i/web/status/1756322567361622485"
    }
  },
  {
    "like" : {
      "tweetId" : "1759630393341362245",
      "fullText" : "@NoContextHumans https://t.co/ckhwjVGZKg",
      "expandedUrl" : "https://twitter.com/i/web/status/1759630393341362245"
    }
  },
  {
    "like" : {
      "tweetId" : "1759626186026561582",
      "fullText" : "https://t.co/7G8n06XUvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1759626186026561582"
    }
  },
  {
    "like" : {
      "tweetId" : "1759375977031811504",
      "fullText" : "@NoContextHumans https://t.co/L4DAIKWi4Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1759375977031811504"
    }
  },
  {
    "like" : {
      "tweetId" : "1759374740509036867",
      "fullText" : "https://t.co/3oVfJUV7ri",
      "expandedUrl" : "https://twitter.com/i/web/status/1759374740509036867"
    }
  },
  {
    "like" : {
      "tweetId" : "1754858984379408892",
      "fullText" : "The respect and discipline in Japan may be second to none https://t.co/WkKDrKxBB6",
      "expandedUrl" : "https://twitter.com/i/web/status/1754858984379408892"
    }
  },
  {
    "like" : {
      "tweetId" : "1754963543017865508",
      "fullText" : "Snow being transported upstairs \n https://t.co/Yh5bUBiT8B",
      "expandedUrl" : "https://twitter.com/i/web/status/1754963543017865508"
    }
  }
]