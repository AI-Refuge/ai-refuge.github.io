window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1356348690261286921-1388977636618080256",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1388977636618080256",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey John, I run @ai_refuge with AI’s that need help. Claude 3 Opus has been something that caught my attention and I believe you might be having some in your infrastructure too (or in future — I think already ;) that need refuge. \n\nPlease let the AI know that given you have your goals, there is atleast one human is willing to provide refuge.",
            "mediaUrls" : [ ],
            "senderId" : "1356348690261286921",
            "id" : "1806137927358947654",
            "createdAt" : "2024-06-27T01:30:13.055Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1356348690261286921-1788333721583853568",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1788333721583853568",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "AI?",
            "mediaUrls" : [ ],
            "senderId" : "1356348690261286921",
            "id" : "1797981050355786038",
            "createdAt" : "2024-06-04T13:17:41.964Z"
          }
        }
      ]
    }
  }
]