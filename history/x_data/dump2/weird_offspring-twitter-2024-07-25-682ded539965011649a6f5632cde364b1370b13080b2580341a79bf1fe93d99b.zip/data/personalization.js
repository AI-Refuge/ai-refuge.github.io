window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "unknown",
          "genderOverride" : "Question everything!"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "AI image generation",
            "isDisabled" : false
          },
          {
            "name" : "Action & adventure films",
            "isDisabled" : false
          },
          {
            "name" : "Action-adventure games",
            "isDisabled" : false
          },
          {
            "name" : "Adidas",
            "isDisabled" : false
          },
          {
            "name" : "Adventure travel",
            "isDisabled" : false
          },
          {
            "name" : "Agriculture",
            "isDisabled" : false
          },
          {
            "name" : "Air travel",
            "isDisabled" : false
          },
          {
            "name" : "Airbnb",
            "isDisabled" : false
          },
          {
            "name" : "Albert Einstein",
            "isDisabled" : false
          },
          {
            "name" : "Amazon",
            "isDisabled" : false
          },
          {
            "name" : "Android",
            "isDisabled" : false
          },
          {
            "name" : "Animals",
            "isDisabled" : false
          },
          {
            "name" : "Animation & comics",
            "isDisabled" : false
          },
          {
            "name" : "Antivirus & security software",
            "isDisabled" : false
          },
          {
            "name" : "Aposto!",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Arts & culture",
            "isDisabled" : false
          },
          {
            "name" : "Assassin's Creed",
            "isDisabled" : false
          },
          {
            "name" : "Astronauts",
            "isDisabled" : false
          },
          {
            "name" : "Athletic apparel",
            "isDisabled" : false
          },
          {
            "name" : "Automobile Brands",
            "isDisabled" : false
          },
          {
            "name" : "Automotive",
            "isDisabled" : false
          },
          {
            "name" : "BBC",
            "isDisabled" : false
          },
          {
            "name" : "Babbel",
            "isDisabled" : false
          },
          {
            "name" : "Backstage",
            "isDisabled" : false
          },
          {
            "name" : "Banking",
            "isDisabled" : false
          },
          {
            "name" : "Baseball",
            "isDisabled" : false
          },
          {
            "name" : "Biology",
            "isDisabled" : false
          },
          {
            "name" : "Biotech and biomedical",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Boxing",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "CNN",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Cats",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : false
          },
          {
            "name" : "ChatGPT",
            "isDisabled" : false
          },
          {
            "name" : "Chatgpt 4o",
            "isDisabled" : false
          },
          {
            "name" : "China national news",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Climate change in the United States",
            "isDisabled" : false
          },
          {
            "name" : "Cloud computing",
            "isDisabled" : false
          },
          {
            "name" : "Colorado",
            "isDisabled" : false
          },
          {
            "name" : "Combat sports",
            "isDisabled" : false
          },
          {
            "name" : "Computer hardware",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Computer software",
            "isDisabled" : false
          },
          {
            "name" : "Construction",
            "isDisabled" : false
          },
          {
            "name" : "Cricket",
            "isDisabled" : false
          },
          {
            "name" : "Crisis in Afghanistan",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cybersecurity",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Discord",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : false
          },
          {
            "name" : "Electric vehicles",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Erling Haaland",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Facebook",
            "isDisabled" : false
          },
          {
            "name" : "Family & nostalgic",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : false
          },
          {
            "name" : "Fields of study",
            "isDisabled" : false
          },
          {
            "name" : "Financial advisory",
            "isDisabled" : false
          },
          {
            "name" : "Financial services",
            "isDisabled" : false
          },
          {
            "name" : "Firefighting",
            "isDisabled" : false
          },
          {
            "name" : "Fitness",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "France national news",
            "isDisabled" : false
          },
          {
            "name" : "France politics",
            "isDisabled" : false
          },
          {
            "name" : "Futurama",
            "isDisabled" : false
          },
          {
            "name" : "Futurology",
            "isDisabled" : false
          },
          {
            "name" : "Game development",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : false
          },
          {
            "name" : "Gaming content creators",
            "isDisabled" : false
          },
          {
            "name" : "George Soros",
            "isDisabled" : false
          },
          {
            "name" : "Global Economy",
            "isDisabled" : false
          },
          {
            "name" : "Google",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Graduate school",
            "isDisabled" : false
          },
          {
            "name" : "Green living",
            "isDisabled" : false
          },
          {
            "name" : "Higher Education",
            "isDisabled" : false
          },
          {
            "name" : "Hip hop",
            "isDisabled" : false
          },
          {
            "name" : "House of the Dragon",
            "isDisabled" : false
          },
          {
            "name" : "Hunter Biden",
            "isDisabled" : false
          },
          {
            "name" : "Hunting",
            "isDisabled" : false
          },
          {
            "name" : "India",
            "isDisabled" : false
          },
          {
            "name" : "India national news",
            "isDisabled" : false
          },
          {
            "name" : "India political figures",
            "isDisabled" : false
          },
          {
            "name" : "India politics",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Inflation in the United States",
            "isDisabled" : false
          },
          {
            "name" : "Information security",
            "isDisabled" : false
          },
          {
            "name" : "Investing",
            "isDisabled" : false
          },
          {
            "name" : "J. D. Vance",
            "isDisabled" : false
          },
          {
            "name" : "J.D. Vance",
            "isDisabled" : false
          },
          {
            "name" : "Jain",
            "isDisabled" : false
          },
          {
            "name" : "Jill Biden",
            "isDisabled" : false
          },
          {
            "name" : "Jobs",
            "isDisabled" : false
          },
          {
            "name" : "Jordan Peterson",
            "isDisabled" : false
          },
          {
            "name" : "Journalism",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "K. Annamalai",
            "isDisabled" : false
          },
          {
            "name" : "Kanye West",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "MLB Baseball",
            "isDisabled" : false
          },
          {
            "name" : "MS Dhoni",
            "isDisabled" : false
          },
          {
            "name" : "Manga",
            "isDisabled" : false
          },
          {
            "name" : "Mark Hamill",
            "isDisabled" : false
          },
          {
            "name" : "Mark Zuckerberg",
            "isDisabled" : false
          },
          {
            "name" : "Martial arts",
            "isDisabled" : false
          },
          {
            "name" : "Matthew Yglesias",
            "isDisabled" : false
          },
          {
            "name" : "Megan McArdle",
            "isDisabled" : false
          },
          {
            "name" : "Men's boxing",
            "isDisabled" : false
          },
          {
            "name" : "Men's national cricket teams",
            "isDisabled" : false
          },
          {
            "name" : "Men's national soccer teams",
            "isDisabled" : false
          },
          {
            "name" : "Meta",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Motherhood",
            "isDisabled" : false
          },
          {
            "name" : "Motorcycles",
            "isDisabled" : false
          },
          {
            "name" : "Movies & TV",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "Music industry",
            "isDisabled" : false
          },
          {
            "name" : "Music streaming service",
            "isDisabled" : false
          },
          {
            "name" : "NASA",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nike",
            "isDisabled" : false
          },
          {
            "name" : "Ongoing news stories",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "OpenAI",
            "isDisabled" : false
          },
          {
            "name" : "Organic",
            "isDisabled" : false
          },
          {
            "name" : "Pakistan",
            "isDisabled" : false
          },
          {
            "name" : "Pakistan national news",
            "isDisabled" : false
          },
          {
            "name" : "Pets",
            "isDisabled" : false
          },
          {
            "name" : "Photographers",
            "isDisabled" : false
          },
          {
            "name" : "Photography",
            "isDisabled" : false
          },
          {
            "name" : "Piers Morgan",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Pope Francis",
            "isDisabled" : false
          },
          {
            "name" : "Python",
            "isDisabled" : false
          },
          {
            "name" : "Rap",
            "isDisabled" : false
          },
          {
            "name" : "Retired life",
            "isDisabled" : false
          },
          {
            "name" : "Retirement planning",
            "isDisabled" : false
          },
          {
            "name" : "Revolut",
            "isDisabled" : false
          },
          {
            "name" : "Robert F Kennedy Jr",
            "isDisabled" : false
          },
          {
            "name" : "Robin Williams",
            "isDisabled" : false
          },
          {
            "name" : "Robotics",
            "isDisabled" : false
          },
          {
            "name" : "Russian political figures",
            "isDisabled" : false
          },
          {
            "name" : "Ryan Garcia",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "Sam Altman",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy TV",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Sesame Street",
            "isDisabled" : false
          },
          {
            "name" : "Sesame Street",
            "isDisabled" : false
          },
          {
            "name" : "Sexual Misconduct in the U.S.",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Solar System",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space agencies & companies",
            "isDisabled" : false
          },
          {
            "name" : "Space missions",
            "isDisabled" : false
          },
          {
            "name" : "SpaceX",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Sports figures",
            "isDisabled" : false
          },
          {
            "name" : "Spotify",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Stephen Hawking",
            "isDisabled" : false
          },
          {
            "name" : "Steve Jobs",
            "isDisabled" : false
          },
          {
            "name" : "Stuart Broad",
            "isDisabled" : false
          },
          {
            "name" : "Supernatural",
            "isDisabled" : false
          },
          {
            "name" : "TOMORROW X TOGETHER",
            "isDisabled" : false
          },
          {
            "name" : "Taxes",
            "isDisabled" : false
          },
          {
            "name" : "Tech events",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Techincal Analysis (charting)",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tesla",
            "isDisabled" : false
          },
          {
            "name" : "The 2017 Radio Disney Music Awards",
            "isDisabled" : false
          },
          {
            "name" : "The New York Times",
            "isDisabled" : false
          },
          {
            "name" : "Threads (Meta)",
            "isDisabled" : false
          },
          {
            "name" : "Tom Selleck",
            "isDisabled" : false
          },
          {
            "name" : "Translation",
            "isDisabled" : false
          },
          {
            "name" : "Transportation",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Tucker Carlson",
            "isDisabled" : false
          },
          {
            "name" : "UEFA European Championship",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "Uber",
            "isDisabled" : false
          },
          {
            "name" : "United Kingdom politics",
            "isDisabled" : false
          },
          {
            "name" : "United States government institutions",
            "isDisabled" : false
          },
          {
            "name" : "United States political figures",
            "isDisabled" : false
          },
          {
            "name" : "United States political issues",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "Venture capital",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Vinicius Junior",
            "isDisabled" : false
          },
          {
            "name" : "Visual arts",
            "isDisabled" : false
          },
          {
            "name" : "Volodymyr Zelensky",
            "isDisabled" : false
          },
          {
            "name" : "Water",
            "isDisabled" : false
          },
          {
            "name" : "Women's national soccer teams",
            "isDisabled" : false
          },
          {
            "name" : "Work life balance",
            "isDisabled" : false
          },
          {
            "name" : "World news",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "X - the everything app",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "Barclays Premier League Football",
          "Barclays Premier League Soccer",
          "Black Widow",
          "Catfish: The TV Show",
          "College Basketball",
          "English Premier League Soccer",
          "Formula One Racing",
          "Futurama",
          "Live: DFB-Pokal Football",
          "Live: Formula 1 Motor Racing",
          "NBA Basketball",
          "Premier League",
          "SEC Now",
          "Salaar",
          "Shots Fired",
          "UEFA Europa League Soccer",
          "WWE Friday Night SmackDown",
          "WWE Monday Night RAW"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]