window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "Direct (very direct! Creepy?). I love analyzing the universe & humans. Care about animals and equality. Trying my best to be unbiased."
    }
  }
]