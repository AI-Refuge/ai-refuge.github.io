window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1356348690261286921",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Twitter-iPhone/10.26 iOS/17.2.1 (Apple;iPhone12,3;;;;;1;2019)",
            "registrationToken" : "83559e33897c87418216f469620e7328",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEX3NiChNs/jcY1X5nNtg6Goc7GYgtaJ7OT+7stwRmU3V1shrhXKeSFvAnxGvzG/hn8fhkbtMcD/nXPu1IkA7bpw==",
            "createdAt" : "2024-02-06T21:19:26.433Z",
            "deviceId" : "09712DC3-45B4-40A1-9D69-7CEAC8B9EDB1"
          },
          {
            "userAgent" : "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
            "registrationToken" : "fd13dd000bab71d21ab0b190ff308d7a",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEzTRmVTtqSgLuFkj/fnrRdpplOCLCiid5W0duFXaFII5Vu1DVRQKUVY6TBrm4WvZCq7BHmaYFWL+yY1N0T7H+bA==",
            "createdAt" : "2024-06-17T00:08:56.063Z",
            "deviceId" : "6bf09421-b2bb-474c-bf55-92b9cb2b3fec"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]