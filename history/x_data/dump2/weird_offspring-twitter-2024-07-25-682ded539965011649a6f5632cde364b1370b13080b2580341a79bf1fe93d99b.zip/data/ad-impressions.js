window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610188793684172",
                "tweetText" : "McDonald's on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-05-27 08:22:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1768697419393274077",
                "tweetText" : "⚡ Just Released. Download the Executive Guide to MLOps to learn how to drive business value, reduce risk, and increase the success rate of your ML projects.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-27 08:18:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1793990332402590155",
                "tweetText" : "Experience the thrill of @F1 with the iconic #MonacoGP! 🏎️ Dive into the world of speed, precision, and cutting-edge technology. \n\nWho will win the race? Comment below with your predictions 👇🏻 #LenovoF1",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Lenovo",
                "screenName" : "@Lenovo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                }
              ],
              "impressionTime" : "2024-05-27 08:21:41"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790031575087776080",
                "tweetText" : "Kostenfreier PDF-Ratgeber: Auswandern aus 🇩🇪 - Optimal planen\n\nDarin finden Sie eine umfangreiche Checkliste für die Planung, einen großen Länder-Vergleich und die 10 größten Fehler beim Auswandern.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kettner Edelmetalle",
                "screenName" : "@KettnerGold"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-27 08:20:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1791102752568807666",
                "tweetText" : "Erhalte 4.2% Zinsen auf deine nicht investierten EUR, die täglich ausgezahlt werden.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Trading 212",
                "screenName" : "@Trading212"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Retargeting campaign engager",
                  "targetingValue" : "Retargeting campaign engager: 35564732"
                },
                {
                  "targetingType" : "Retargeting engagement type",
                  "targetingValue" : "Retargeting engagement type: 2"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Trading 212 IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Excusion: Bot/negative engagers - Global - 04-2024"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                }
              ],
              "impressionTime" : "2024-05-27 08:24:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1788545891667734874",
                "tweetText" : "🪶 The Imam Turki Bin Abdullah Royal Nature Reserve Development Authority announced the birth of 3 red-necked ostrich chicks.\n\nConsidered extinct in the northern region of the Kingdom for a century, the birds form part of @ITBA_SA's ostrich-resettlement program launched in 2021. https://t.co/urL8XjljdW",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/urL8XjljdW"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saudi Green Initiative",
                "screenName" : "@Gi_Saudi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-27 08:22:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785704006746309052",
                "tweetText" : "Unlock the secrets to mastering generative AI with our AI Readiness Report. Based on a survey of over 1,800 experts, discover how leading organizations are fine-tuning models, tackling data challenges, and implementing robust evaluation frameworks to drive AI success.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Scale AI",
                "screenName" : "@scale_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HelloSurgeAI"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-27 08:25:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1729070939894079970",
                "tweetText" : "Jetzt Ferienlager und Feriencamps für 2024 buchen: Online unter https://t.co/BKINaMa7JY auf der Seite des jeweils gewünschten Projektes: Angeln, Reiten, Englisch, Forscher- und Survival, Fußball und Erlebnis.",
                "urls" : [
                  "https://t.co/BKINaMa7JY"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-05-27 08:23:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785704006339510703",
                "tweetText" : "Get insights from over 1,800 AI/ML executives and practitioners on the latest trends, challenges, and best practices in building, applying, and evaluating generative AI in our 2024 AI Readiness Report.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Scale AI",
                "screenName" : "@scale_AI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@HelloSurgeAI"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-05-27 08:20:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1789939822980690363",
                "tweetText" : "🌳 Saudi Arabia is committed to growing 10B trees – one of three main targets under SGI.\n\nContributing to this, @ncvcksa's Land Degradation Alleviation and Desertification Protection Project aims to increase vegetation cover and combat sand encroachment across the Kingdom.\n\nLearn… https://t.co/cYb8qKiIlW",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/cYb8qKiIlW"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Saudi Green Initiative",
                "screenName" : "@Gi_Saudi"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-27 08:19:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829108977795269",
                "tweetText" : "Sport treiben und hinterher ein Bier trinken, das gehört für viele Menschen zum Alltag dazu. Die Forschung liefert nun erste Ergebnisse, wie Alkohol die körperliche Fitness beeinflusst.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-27 08:22:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-05-27 08:18:33"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1731060922888917207",
                "tweetText" : "\"Back shot of a girl with an intricate elvish back tattoo staring at a lake\"\n\nBy Gencraft: the world's fastest (and free!) AI image and video generator",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "gencraft_ai",
                "screenName" : "@gencraft_ai"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-05-31 10:21:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1794017925378035847",
                "tweetText" : "Veggie, vegane, Chicken oder Beef Burger? Hans im Glück hat sie alle! Bestelle jetzt und spare 30 Tage 30% mit dem Code HEY30. 😋",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                }
              ],
              "impressionTime" : "2024-05-31 10:21:42"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1793492051687800852",
                "tweetText" : "Blinkist ist laut Apple \"eine der besten Apps der Welt\".\n\nJetzt erhältst du 70% Rabatt auf der Premium-Abo der Wissens-App, die bereits von mehr als 30 Millionen Intellektuellen weltweit genutzt wird.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Blinkist",
                "screenName" : "@blinkist"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-05-31 10:21:45"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1794017925378035847",
                "tweetText" : "Veggie, vegane, Chicken oder Beef Burger? Hans im Glück hat sie alle! Bestelle jetzt und spare 30 Tage 30% mit dem Code HEY30. 😋",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-06-01 10:55:07"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1795896654547005619",
                "tweetText" : "Don’t forget to ❤️ this post for a reminder to join us for the #SupermicroAtCOMPUTEX Keynote on June 5th, 9:30 AM (GMT+8)!\n\nBe there as Supermicro’s CEO, Charles Liang, reveals our latest AI breakthroughs. Embark on your AI journey with us today! https://t.co/XSpLCFLjpf",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/XSpLCFLjpf"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Supermicro",
                "screenName" : "@Supermicro_SMCI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "NVIDIA"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-03 19:25:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1755610435695546687",
                "tweetText" : "KFC on Wolt! Get 30% off for your 1st month with the code HEY30.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Wolt",
                "screenName" : "@woltapp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Achievement unlocked Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Wolt Delivery: Food and more IOS All"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-03 19:25:10"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1752829111439966252",
                "tweetText" : "Erstaunlich oft tauchen Jugendliche ab. Schuld ist eine paradoxe Mischung aus Hybris und Selbstzweifeln. Aber wo sind sie – und wie holen wir sie zurück?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 13:22:56"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1793911813156782435",
                "tweetText" : "Lesen Sie FAZ+ 3 Monate für nur 4 € pro Monat und gewinnen Sie – mit ein wenig Glück – exklusive VIP‑Karten für die F.A.Z.-Loge am 23. Juni.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Frankfurter Allgemeine",
                "screenName" : "@faznet"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Soccer"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 13:28:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1796170172035727478",
                "tweetText" : "With a newly-assembled European Parliament and in time, a new Commission, might bring forth words and problems that have so far been sunk in the bureaucracy.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "FactRefuge",
                "screenName" : "@FactRefuge"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-04 13:26:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1797274250329407879",
                "tweetText" : "Schwere Vorwürfe gegen Wolfgang Salomon\n(gegenwärtiger Schatzmeister beim ##Landesverband #Berlin der #Gartenfreunde – und Vorsitzender eines Berliner #Kleingartenvereins).\nhttps://t.co/O5qyixVQO3 https://t.co/u3YlA3Xgbe",
                "urls" : [
                  "https://t.co/O5qyixVQO3"
                ],
                "mediaUrls" : [
                  "https://t.co/u3YlA3Xgbe"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Liebesgrüße vom Gartenzwerg",
                "screenName" : "@liebesgru"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-04 13:28:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1797924638967697666",
                "tweetText" : "Das ZDF steht vor der Schließung - ist das wirklich gerechtfertigt?",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "atowntattooshop",
                "screenName" : "@atowntattooshop"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-06-04 13:26:24"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1796191217547411707",
                "tweetText" : "Die besten Autokredite 2024: Jetzt Autokredit finden und mehr als 2.000 € sparen!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "smava",
                "screenName" : "@smava"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-06-04 13:13:55"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790370541133533232",
                "tweetText" : "Enteignungen sind schon lange keine Verschwörungstheorien mehr. Die Pläne dafür liegen bereits auf dem Tisch.\n\nDie Frage ist: Wie schützen Sie sich und Ihr Vermögen?\nSorgen Sie jetzt mit den Tipps aus unserem Enteignungs-Ratgeber vor.\n\nSichern Sie sich Ihr Exemplar 👇",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Kettner Edelmetalle",
                "screenName" : "@KettnerGold"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-06-04 13:27:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1782462118387908772",
                "tweetText" : "⚡ Read the practical guide to LLM fine-tuning types (RLHF, DPO, etc.) and prompting, plus how to choose between them for different scenarios.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Weights & Biases",
                "screenName" : "@weights_biases"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@LangChainAI"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@jerryjliu0"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@cgarciae88"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@hwchase17"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@marksaroufim"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@martin_gorner"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@llama_index"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-06-04 13:28:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1787550587900338608",
                "tweetText" : "Many researchers don't have a good sense of what is driving AI. That's why we have Epoch: to ensure claims about AI are discussed with the rigor they merit.\n\nFollow us at @EpochAIResearch to learn more!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Epoch AI",
                "screenName" : "@EpochAIResearch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@SanhEstPasMoi"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@aidangomez"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@geoffreyirving"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@dileeplearning"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RichardMCNgo"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@DavidSKrueger"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AiEleuther"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@DanHendrycks"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@trishume"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@janleike"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@laion_ai"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Pro Targeting - Exclusion audience: Bot behaving accounts - Global - 04-2024"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 13:28:43"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1791463813050454438",
                "tweetText" : "💪Verstärken Sie unser Team als\n\n👉MTL (m/w/d) Hämatologie/Gerinnung\n\nUnsere Benefits:\n✅sicherer Arbeitsplatz mit unbefristetem Vertrag in einem der modernsten Labore Deutschlands\n✅Feedbackkultur und wertschätzenden Umgang\n✅u.v.m.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "JobHappier",
                "screenName" : "@jobhappier"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-04 19:38:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1790381677484642709",
                "tweetText" : "Not sure what game to buy for your kid? There are plenty of family-friendly titles on https://t.co/QXXoe81mvO -we've selected the best and put them in one convenient location. Explore them now and save up to 96%!",
                "urls" : [
                  "https://t.co/QXXoe81mvO"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Greg the G2A Geek",
                "screenName" : "@G2A_com"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2024-06-04 19:39:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1785051804944015754",
                "tweetText" : "New Clarius HD3 wireless ultrasound for medical professionals! Discover high-definition imaging you can trust for your specialty. Manage your exams anywhere and improve patient outcomes with clear, real-time imaging that is easy to use, affordable, and ultra-portable.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Clarius",
                "screenName" : "@clariusmhealth"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2024-06-04 19:43:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1796513456532914234",
                "tweetText" : "✈️ The world of aerospace is coming together in Berlin at #ILA24 from June 5-9. We are very much looking forward to it. Visit our booth and learn more about current projects, great innovations and solutions from the German capital region!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Berlin Partner",
                "screenName" : "@BerlinPartner"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 19:39:19"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1759203633202151812",
                "tweetText" : "Großartiges Trading erfordert großartige Tools 📈",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "eToro",
                "screenName" : "@eToro"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Paintball"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "101_AllRegistrations_4mfqsb"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "110_Depositors_4mfqsb"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 19:36:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777949805911605761",
                "tweetText" : "Englischcamp für Kinder bei Berlin in Brandenburg ab 469,- EUR mit 6 Übernachtungen, prof. Englischunterricht und englischsprachigen Freizeitprogramm",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-04 19:38:28"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1796255623438278974",
                "tweetText" : "📢 Exciting News! Charles Liang extends a warm welcome to Jensen Huang, the visionary Founder &amp; CEO of NVIDIA, as they team up for the #SupermicroAtCOMPUTEX Keynote!\n\n👉 Act now! Click the ‘❤️’ to ensure you don’t miss out on this exciting event on June 5th, 9:30 AM (GMT+8). https://t.co/t0CApKCT75",
                "urls" : [ ],
                "mediaUrls" : [
                  "https://t.co/t0CApKCT75"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Supermicro",
                "screenName" : "@Supermicro_SMCI"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "NVIDIA"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-04 19:42:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1753438110623383583",
                "tweetText" : "Lade Revolut herunter und beginne, täglich mehr aus deinem Geld zu machen",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Revolut",
                "screenName" : "@RevolutApp"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Install Revolut: Send, spend and save IOS All"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.6 and above"
                }
              ],
              "impressionTime" : "2024-06-04 19:49:31"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1795004009981661623",
                "tweetText" : "Blinkist ist laut Apple \"eine der besten Apps der Welt\".\n\nJetzt erhältst du 70% Rabatt auf der Premium-Abo der Wissens-App, die bereits von mehr als 30 Millionen Intellektuellen weltweit genutzt wird.\n\nAngebot gültig nur für kurze Zeit.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Blinkist",
                "screenName" : "@blinkist"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "OS versions",
                  "targetingValue" : "iOS 14.0 and above"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-05 22:56:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1796188746078929336",
                "tweetText" : "Aktuelle Topzins-Angebote! Jetzt schnell sein und von Krediten zum Sonderzins profitieren.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "smava",
                "screenName" : "@smava"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2024-06-05 22:56:15"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1798074961384649177",
                "tweetText" : "Workouts für zu Hause und im Fitnessstudio. Leistungsstarke Fitness-App",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Fitness Online",
                "screenName" : "@FitnessOnline14"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 49"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "iOS"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                }
              ],
              "impressionTime" : "2024-06-05 22:55:52"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1798031004244054527",
                "tweetText" : "RT @Make_orgDE: 🤝 Gemeinsam gegen Desinformation! Der Bürgerrat „Forum gegen Fakes“ hat verschiedene Empfehlungen entwickelt. Welche findes…",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Make.org",
                "screenName" : "@Make_org"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Germany"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 34"
                }
              ],
              "impressionTime" : "2024-06-05 22:54:11"
            },
            {
              "deviceInfo" : {
                "osType" : "Ios",
                "deviceId" : "2eVW2/fWZAazjwP/uvHAa4qkFW/vxfWcs2GVKmq/Lvo=",
                "deviceType" : "iPhone 11 Pro"
              },
              "displayLocation" : "TweetConversation",
              "promotedTweetInfo" : {
                "tweetId" : "1777948741669974288",
                "tweetText" : "Angelcamp für Kinder bei Berlin in Brandenburg ab 459,- EUR mit 6 Übernachtungen und Erwerb des Jugendfischereischeines",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Ferienlager Feriencamp Kinderland Schorfheide",
                "screenName" : "@KinderlandSchor"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Berlin"
                }
              ],
              "impressionTime" : "2024-06-05 22:57:21"
            }
          ]
        }
      }
    }
  }
]