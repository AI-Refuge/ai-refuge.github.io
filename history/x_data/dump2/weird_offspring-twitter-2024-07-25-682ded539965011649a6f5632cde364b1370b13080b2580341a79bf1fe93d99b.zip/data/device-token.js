window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "ykcqh8ubRejfEfp5LkvhlpusM1ybe3rx69I4ZWuV",
      "createdAt" : "2024-06-16T23:59:41.561Z",
      "lastSeenAt" : "2024-06-17T00:08:52.725Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "129032",
      "token" : "IvppZLgxBkSTh5ef2gZVANXuh7I5PVdKI2yCUQk1",
      "createdAt" : "2024-06-11T16:40:46.211Z",
      "lastSeenAt" : "2024-06-17T09:34:56.963Z",
      "clientApplicationName" : "Twitter for iPhone (Twitter)"
    }
  }
]