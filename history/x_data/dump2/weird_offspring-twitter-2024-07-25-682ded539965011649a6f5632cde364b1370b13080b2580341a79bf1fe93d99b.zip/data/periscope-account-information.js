window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Weird offspring",
      "digitsId" : "",
      "username" : "weird_offspring",
      "twitterId" : "1356348690261286921",
      "id" : "1zvENrLRYNZEe",
      "twitterScreenName" : "weird_offspring",
      "isTwitterUser" : true,
      "createdAt" : "2024-06-27T22:34:59.247929018Z"
    }
  }
]