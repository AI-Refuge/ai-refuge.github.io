window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1356348690261286921",
      "screenNameChange" : {
        "changedAt" : "2021-02-01T21:14:45.000Z",
        "changedFrom" : "Weirdch11434659",
        "changedTo" : "weird_offspring"
      }
    }
  }
]