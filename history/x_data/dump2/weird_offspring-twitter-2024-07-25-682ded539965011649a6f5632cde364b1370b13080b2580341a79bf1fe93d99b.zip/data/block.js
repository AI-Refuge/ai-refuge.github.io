window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1723539445553741824",
      "userLink" : "https://twitter.com/intent/user?user_id=1723539445553741824"
    }
  },
  {
    "blocking" : {
      "accountId" : "1719485115322060800",
      "userLink" : "https://twitter.com/intent/user?user_id=1719485115322060800"
    }
  },
  {
    "blocking" : {
      "accountId" : "1717679911266119681",
      "userLink" : "https://twitter.com/intent/user?user_id=1717679911266119681"
    }
  },
  {
    "blocking" : {
      "accountId" : "1713465579171147776",
      "userLink" : "https://twitter.com/intent/user?user_id=1713465579171147776"
    }
  },
  {
    "blocking" : {
      "accountId" : "1712503858344398848",
      "userLink" : "https://twitter.com/intent/user?user_id=1712503858344398848"
    }
  },
  {
    "blocking" : {
      "accountId" : "1710147043988037632",
      "userLink" : "https://twitter.com/intent/user?user_id=1710147043988037632"
    }
  },
  {
    "blocking" : {
      "accountId" : "1707974463134830592",
      "userLink" : "https://twitter.com/intent/user?user_id=1707974463134830592"
    }
  },
  {
    "blocking" : {
      "accountId" : "1704567185967099904",
      "userLink" : "https://twitter.com/intent/user?user_id=1704567185967099904"
    }
  },
  {
    "blocking" : {
      "accountId" : "1698073881313951744",
      "userLink" : "https://twitter.com/intent/user?user_id=1698073881313951744"
    }
  },
  {
    "blocking" : {
      "accountId" : "1661578224244076544",
      "userLink" : "https://twitter.com/intent/user?user_id=1661578224244076544"
    }
  }
]